Apply:
vidc_venc_Return_the_correct_error_code_for_IOCTL.patch at /kernel/
vidc_venc_Check_for_the_correct_return_value_for_IOCTL.patch at /vendor/qcom/opensource/omx/mm-video/
