Steps to apply the patch
========================
1) Copy dualmic.patch to <root>/android/.
2) cd <root>/android
3) patch -p1 < dualmic.patch

The patch modifies the following files,

android/hardware/msm7k/libaudio-qsd8k/AudioHardware.cpp
android/hardware/msm7k/libaudio-qsd8k/AudioHardware.h


Note : If you see any issue while applying the patch, please manualy apply the changes.
