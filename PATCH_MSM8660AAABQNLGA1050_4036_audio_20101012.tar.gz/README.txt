Apply patches in order:

system/core: 36806.patch
kernel: 36875.patch
kernel: 36877.patch
bionic: 32399.patch
bionic: 37380.patch
hardware/msm7k: 32397.patch
hardware/msm7k: 37371.patch

