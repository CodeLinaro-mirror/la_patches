#Init
unzip HY11_2056_msm7630_1x.zip
tar -xzvf PATCH_MSM7x30_2056Release_Fluid_open_source_patches_20110218.tar.gz

export PATCH_MAINLINED_PATH=PATCH_MSM7x30_2056Release_Fluid_open_source_patches_20110218/patches_mainlined
export PROPRIETARY_FOLDER_PATH=HY11_2056_msm7630_1x/

#gather non-proprietary patches to one folder
mkdir patches
cp -r ${PATCH_MAINLINED_PATH}/* patches

#Define base directory
export CAF_BASE=`pwd`

mkdir 2056_caf
cd 2056_caf
export CAF_BUILD_BASE=`pwd`
repo init -u git://codeaurora.org/platform/manifest.git -b froyo_pumpkin -m M7630AABBQMLZA203011.xml
repo sync

source build/envsetup.sh

choosecombo 1 1 msm7630_1x eng

repo start work --all

#Start applying patches
croot
cd kernel
git am --ignore-whitespace $CAF_BASE/patches/kernel/*.patch

croot
cd external/dhcpcd
git am --ignore-whitespace $CAF_BASE/patches/external/dhcpcd/*.patch


#Apply proprietary folder
croot
mkdir vendor/qcom/proprietary
mv $CAF_BASE/${PROPRIETARY_FOLDER_PATH}/* vendor/qcom/proprietary

#Cleanup created folders
rm -rf $CAF_BASE/patches
rm -rf $CAF_BASE/${PATCH_MAINLINED_PATH}
rm -rf $CAF_BASE/${PROPRIETARY_FOLDER_PATH}

#Change file props to run build scrips
chmod 755 vendor/qcom/proprietary/common/scripts/*

make -j4
