The patch files should be applied from
system/core