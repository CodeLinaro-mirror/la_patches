The patch files should be applied from
frameworks\base