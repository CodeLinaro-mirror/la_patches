The patch files should be applied from
vendor/qcom-opensource/omx/mm-core