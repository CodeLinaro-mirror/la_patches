The patch files should be applied from
\kernel\ path and in sequence indicated
by prefix number.

e.g 
1 crypto add Qualcomm crypto drivers
2 msm crypto add qcrypto and qcedev devices
...

