/* Copyright (c) 2008-2009, Code Aurora Forum. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of Code Aurora Forum nor
 *       the names of its contributors may be used to endorse or promote
 *       products derived from this software without specific prior written
 *       permission.
 *
 * Alternatively, provided that this notice is retained in full, this software
 * may be relicensed by the recipient under the terms of the GNU General Public
 * License version 2 ("GPL") and only version 2, in which case the provisions of
 * the GPL apply INSTEAD OF those given above.  If the recipient relicenses the
 * software under the GPL, then the identification text in the MODULE_LICENSE
 * macro must be changed to reflect "GPLv2" instead of "Dual BSD/GPL".  Once a
 * recipient changes the license terms to the GPL, subsequent recipients shall
 * not relicense under alternate licensing terms, including the BSD or dual
 * BSD/GPL terms.  In addition, the following license statement immediately
 * below and between the words START and END shall also then apply when this
 * software is relicensed under the GPL:
 *
 * START
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 2 and only version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
 * END
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include <linux/delay.h>
#include <linux/types.h>
#include <linux/i2c.h>
#include <linux/uaccess.h>
#include <linux/miscdevice.h>
#include <media/msm_camera.h>
#include <mach/gpio.h>
#include <mach/camera.h>
#include "mt9p012.h"

/*=============================================================
    SENSOR REGISTER DEFINES
==============================================================*/
#define MT9P012_REG_MODEL_ID         0x0000
#define MT9P012_MODEL_ID             0x2801
#define MT9P012_MODEL_ID_5131	       0x2803
#define REG_GROUPED_PARAMETER_HOLD   0x0104
#define GROUPED_PARAMETER_HOLD       0x0100
#define GROUPED_PARAMETER_UPDATE     0x0000
#define REG_COARSE_INT_TIME          0x3012
#define REG_VT_PIX_CLK_DIV           0x0300
#define REG_VT_SYS_CLK_DIV           0x0302
#define REG_PRE_PLL_CLK_DIV          0x0304
#define REG_PLL_MULTIPLIER           0x0306
#define REG_OP_PIX_CLK_DIV           0x0308
#define REG_OP_SYS_CLK_DIV           0x030A
#define REG_SCALE_M                  0x0404
#define REG_FRAME_LENGTH_LINES       0x300A
#define REG_LINE_LENGTH_PCK          0x300C
#define REG_X_ADDR_START             0x3004
#define REG_Y_ADDR_START             0x3002
#define REG_X_ADDR_END               0x3008
#define REG_Y_ADDR_END               0x3006
#define REG_X_OUTPUT_SIZE            0x034C
#define REG_Y_OUTPUT_SIZE            0x034E
#define REG_FINE_INTEGRATION_TIME    0x3014
#define REG_ROW_SPEED                0x3016
#define MT9P012_REG_RESET_REGISTER   0x301A
#define MT9P012_RESET_REGISTER_PWON  0x10CC
#define MT9P012_RESET_REGISTER_PWOFF 0x10C8
#define REG_READ_MODE                0x3040
#define REG_GLOBAL_GAIN              0x305E
#define REG_TEST_PATTERN_MODE        0x3070

#define MT9P012_REV_7
#define MT9P012_5131

#ifndef DIFF
#define DIFF(a,b) ( ((a) > (b)) ? ((a) - (b)) : ((b) - (a)) )
#endif


enum mt9p012_test_mode_t {
	TEST_OFF,
	TEST_1,
	TEST_2,
	TEST_3
};

enum mt9p012_resolution_t {
	QTR_SIZE,
	FULL_SIZE,
	INVALID_SIZE
};

enum mt9p012_reg_update_t {
	/* Sensor egisters that need to be updated during initialization */
	REG_INIT,
	/* Sensor egisters that needs periodic I2C writes */
	UPDATE_PERIODIC,
	/* All the sensor Registers will be updated */
	UPDATE_ALL,
	/* Not valid update */
	UPDATE_INVALID
};

enum mt9p012_setting_t {
	RES_PREVIEW,
	RES_CAPTURE
};

/* actuator's Slave Address */
#define MT9P012_AF_I2C_ADDR   0x8A

/* AF Total steps parameters */
#define MT9P012_STEPS_NEAR_TO_CLOSEST_INF  20
#define MT9P012_TOTAL_STEPS_NEAR_TO_FAR    20

#define MT9P012_MU5M0_PREVIEW_DUMMY_PIXELS 0
#define MT9P012_MU5M0_PREVIEW_DUMMY_LINES  0

/* Time in milisecs for waiting for the sensor to reset.*/
#define MT9P012_RESET_DELAY_MSECS   66

/* for 20 fps preview */
#define MT9P012_DEFAULT_CLOCK_RATE  24000000
#define MT9P012_DEFAULT_MAX_FPS     26 /* ???? */

struct mt9p012_work_t {
	struct work_struct work;
};
static struct mt9p012_work_t *mt9p012_sensorw;
static struct i2c_client *mt9p012_client;

struct mt9p012_ctrl_t {
	struct  msm_camera_sensor_info *sensordata;

	enum sensor_mode_t sensormode;
	uint32_t fps_divider; /* init to 1 * 0x00000400 */
	uint32_t pict_fps_divider; /* init to 1 * 0x00000400 */

	uint16_t curr_lens_pos;
	uint16_t init_curr_lens_pos;
	uint16_t my_reg_gain;
	uint32_t my_reg_line_count;

	enum mt9p012_resolution_t prev_res;
	enum mt9p012_resolution_t pict_res;
	enum mt9p012_resolution_t curr_res;
	enum mt9p012_test_mode_t  set_test;
};

static uint16_t bam_macro, bam_infinite;
static uint16_t bam_step_lookup_table[MT9P012_TOTAL_STEPS_NEAR_TO_FAR + 1];
static uint8_t ic_cont_1 = 0x34;
static uint8_t ic_cont_7 = 0x44;
static uint16_t mt9p012_current_lens_position;

static struct mt9p012_ctrl_t *mt9p012_ctrl;
static DECLARE_WAIT_QUEUE_HEAD(mt9p012_wait_queue);
DECLARE_MUTEX(mt9p012_sem);

/*=============================================================*/

static int mt9p012_i2c_rxdata(unsigned short saddr, int slength,
			      unsigned char *rxdata, int rxlength)
{
  struct i2c_msg msgs[] = {
	{   .addr   = saddr,
		.flags = 0,
		.len   = slength,
		.buf   = rxdata,
	},
	{   .addr   = saddr,
		.flags = I2C_M_RD,
		.len   = rxlength,
		.buf   = rxdata,
	},
    };

	if (i2c_transfer(mt9p012_client->adapter, msgs, 2) < 0) {
		CDBG("mt9p012_i2c_rxdata failed!\n");
		return -EIO;
	}

	return 0;
}

static int32_t mt9p012_i2c_read_b(unsigned short saddr, uint8_t raddr,
	uint8_t *rdata)
{
	int32_t rc = 0;
	unsigned char buf[2];

	if (!rdata)
		return -EIO;

	buf[0] = raddr;

	rc = mt9p012_i2c_rxdata(saddr, 1, buf, 1);
	if (rc < 0) {
		CDBG("%s: failed! saddr = 0x%x, raddr = %d\n",
			__func__, saddr, raddr);

    return rc;
  }

	*rdata = buf[0];

	CDBG("%s: successed! saddr = 0x%x, raddr = %d, rdata = %d\n",
		__func__, saddr, raddr, *rdata);

	return rc;
}

static int32_t mt9p012_i2c_read_w(unsigned short saddr, unsigned short raddr,
	unsigned short *rdata)
{
	int32_t rc = 0;
	unsigned char buf[4];

	if (!rdata)
		return -EIO;

	memset(buf, 0, sizeof(buf));

	buf[0] = (raddr & 0xFF00)>>8;
	buf[1] = (raddr & 0x00FF);

	rc = mt9p012_i2c_rxdata(saddr, 2, buf, 2);
	if (rc < 0)
		return rc;

	*rdata = buf[0] << 8 | buf[1];

	if (rc < 0)
		CDBG("mt9p012_i2c_read_w failed!\n");

	return rc;
}

static int32_t mt9p012_i2c_txdata(unsigned short saddr,	unsigned char *txdata,
	int length)
{
	struct i2c_msg msg[] = {
		{
		.addr  = saddr,
		.flags = 0,
		.len = length,
		.buf = txdata,
		},
	};

	if (i2c_transfer(mt9p012_client->adapter, msg, 1) < 0) {
		CDBG("mt9p012_i2c_txdata failed\n");
		return -EIO;
	}

	return 0;
}

static int32_t mt9p012_i2c_write_b(unsigned short saddr, unsigned short baddr,
	unsigned short bdata)
{
	int32_t rc = -EFAULT;
	unsigned char buf[2];

	CDBG("%s: IN \n", __func__);	
    memset(buf, 0, sizeof(buf));
    CDBG("%s:baddr=%d bdata=%d\n", __func__, baddr, bdata);
	buf[0] = baddr;
	buf[1] = bdata;
	rc = mt9p012_i2c_txdata(saddr, buf, 2);

	if (rc < 0)
		CDBG("i2c_write failed, saddr = 0x%x addr = 0x%x, val =0x%x!\n",
		saddr, baddr, bdata);

	CDBG("%s: OUT \n", __func__);
	return rc;
}

static int32_t mt9p012_i2c_write_w(unsigned short saddr, unsigned short waddr,
	unsigned short wdata)
{
	int32_t rc = -EFAULT;
	unsigned char buf[4];

	memset(buf, 0, sizeof(buf));
    CDBG("%s:waddr=%d wdata=%d\n", __func__, waddr, wdata);
	buf[0] = (waddr & 0xFF00)>>8;
	buf[1] = (waddr & 0x00FF);
	buf[2] = (wdata & 0xFF00)>>8;
	buf[3] = (wdata & 0x00FF);

	rc = mt9p012_i2c_txdata(saddr, buf, 4);

	if (rc < 0)
		CDBG("i2c_write_w failed, addr = 0x%x, val = 0x%x!\n",
			waddr, wdata);

	return rc;
}

static int32_t mt9p012_i2c_write_w_table(
	struct mt9p012_i2c_reg_conf const *reg_conf_tbl, int num)
{
	int i;
	int32_t rc = -EFAULT;

	for (i = 0; i < num; i++) {
		rc = mt9p012_i2c_write_w(mt9p012_client->addr,
			reg_conf_tbl->waddr, reg_conf_tbl->wdata);
		if (rc < 0)
			break;
		reg_conf_tbl++;
	}

	return rc;
}

static uint8_t move(uint16_t Target, uint8_t Time)
{
	uint8_t reg_1 = 0, reg_7 = 0, reg_2 = 0;
	uint8_t temp_pos;
	uint8_t elasped_time;
	uint8_t status = 0;

	if (mt9p012_i2c_read_b(MT9P012_AF_I2C_ADDR >> 1, 0x01, &reg_1) < 0)
		CDBG("%s: i2c read to 0x01 is failed\n", __func__);

	reg_1 = (ic_cont_1 | 0x10);
	if (mt9p012_i2c_write_b(MT9P012_AF_I2C_ADDR >> 1, 0x01, reg_1) < 0)
		CDBG("%s: i2c write to 0x01 is failed\n", __func__);

	temp_pos =(uint8_t)(Target >> 8) & 0x03;
	if (mt9p012_i2c_write_b(MT9P012_AF_I2C_ADDR >> 1, 0x05, temp_pos) < 0)
		CDBG("%s: i2c write to 0x05 is failed\n", __func__);

	temp_pos = (uint8_t)(Target & 0x00FF);
	if (mt9p012_i2c_write_b(MT9P012_AF_I2C_ADDR >> 1, 0x06, temp_pos) < 0)
		CDBG("%s: i2c write to 0x06 is failed\n", __func__);

	if (mt9p012_i2c_write_b(MT9P012_AF_I2C_ADDR >> 1, 0x0B, Time) < 0)
		CDBG("%s: i2c read to 0x01 is failed\n", __func__);

	if (mt9p012_i2c_read_b(MT9P012_AF_I2C_ADDR >> 1, 0x07, &reg_7) < 0)
		CDBG("%s: i2c read to 0x07 is failed\n", __func__);

	reg_7 = ic_cont_7 | (0x01);
	if (mt9p012_i2c_write_b(MT9P012_AF_I2C_ADDR >> 1, 0x07, reg_7) < 0)
		CDBG("%s: i2c write to 0x01 is failed\n", __func__);

	mdelay(5);
	for (elasped_time = 0; elasped_time < (Time * 3)/2; elasped_time++) {
		mt9p012_i2c_read_b(MT9P012_AF_I2C_ADDR >> 1, 0x02, &reg_2);
		CDBG("%s: reg_2=%d\n", __func__, reg_2);
		status = reg_2 & 0x0C;
		if ((status == 0x04) || (status == 0x08)) {
			CDBG("%s: Status %d is not valid.\n", __func__, status);
			break;
		}
		mdelay(5);
	}

	return status;
}

static uint16_t read_position(void)
{
	uint8_t reg_1 = 0;
	uint8_t reg_3 = 0, reg_4 = 0;
	uint16_t ret_val = 0;

	reg_1 = (ic_cont_1 | 0x03);
	if (mt9p012_i2c_write_b(MT9P012_AF_I2C_ADDR >> 1, 0x01, reg_1) < 0)
		CDBG("%s: i2c write to 0x01 is failed", __func__);

	if (mt9p012_i2c_read_b(MT9P012_AF_I2C_ADDR >> 1, 0x03, &reg_3) < 0)
		CDBG("%s: i2c read to 0x03 is failed", __func__);

	if (mt9p012_i2c_read_b(MT9P012_AF_I2C_ADDR >> 1, 0x04, &reg_4) < 0)
		CDBG("%s: i2c read to 0x04 is failed", __func__);

	ret_val = (reg_3 << 8) | reg_4;

	return ret_val;
}

static uint8_t chkF (uint8_t Act_freq)
{
	uint16_t first_position = 0;
	uint16_t second_position = 0;

	mt9p012_i2c_write_b(MT9P012_AF_I2C_ADDR >> 1, 0x08, Act_freq);
	move(bam_macro, 40);
	move(bam_infinite,40);
	move(bam_macro, 40);
	first_position = read_position();
	move(bam_infinite, 40);
	second_position = read_position();
	if (second_position > first_position + ((bam_infinite - bam_macro)/2)) {
		return 1;
	} else {
		return 0;
	}
}

static void Init_freq(void)
{
	uint8_t reg_8 = 0;
	uint8_t mid_freq, low_freq, high_freq;

	if (mt9p012_i2c_read_b(MT9P012_AF_I2C_ADDR >> 1, 0x08, &reg_8) < 0)
		CDBG("%s: i2c read to 0x08 is failed", __func__);
	mid_freq = reg_8;

	if( (mid_freq < 64) || (mid_freq > 127) )
		return;
	if (chkF(mid_freq) == 1)
		return;

	low_freq = (mid_freq > 67 ? (mid_freq - 3) : 64);
	if (chkF(low_freq) == 1)
		return;

	high_freq = ( mid_freq < 124 ? (mid_freq + 3) : 127);
	if (chkF(high_freq) == 1)
		return;

	reg_8 = mid_freq;
    if (mt9p012_i2c_write_b(MT9P012_AF_I2C_ADDR >> 1, 0x08,reg_8) < 0)
		CDBG("%s: i2c write to 0x08 is failed", __func__);
}


static int32_t mt9p012_test(enum mt9p012_test_mode_t mo)
{
	int32_t rc = 0;

	rc = mt9p012_i2c_write_w(mt9p012_client->addr,
		REG_GROUPED_PARAMETER_HOLD,
		GROUPED_PARAMETER_HOLD);
	if (rc < 0)
		return rc;

	if (mo == TEST_OFF)
		return 0;
	else {
		rc = mt9p012_i2c_write_w_table(mt9p012_regs.ttbl,
					       mt9p012_regs.ttbl_size);
		if (rc < 0)
			return rc;

		rc = mt9p012_i2c_write_w(mt9p012_client->addr,
			REG_TEST_PATTERN_MODE, (uint16_t)mo);
		if (rc < 0)
			return rc;
	}

	rc = mt9p012_i2c_write_w(mt9p012_client->addr,
		REG_GROUPED_PARAMETER_HOLD,
		GROUPED_PARAMETER_UPDATE);
	if (rc < 0)
		return rc;

	return rc;
}

static int32_t mt9p012_lens_shading_enable(uint8_t is_enable)
{
	int32_t rc = 0;

	CDBG("%s: entered. enable = %d\n", __func__, is_enable);

	rc = mt9p012_i2c_write_w(mt9p012_client->addr,
		REG_GROUPED_PARAMETER_HOLD, GROUPED_PARAMETER_HOLD);
	if (rc < 0)
		return rc;

	rc = mt9p012_i2c_write_w(mt9p012_client->addr, 0x3780,
		((uint16_t) is_enable) << 15);
	if (rc < 0)
		return rc;

	rc = mt9p012_i2c_write_w(mt9p012_client->addr,
		REG_GROUPED_PARAMETER_HOLD, GROUPED_PARAMETER_UPDATE);

	CDBG("%s: exiting. rc = %d\n", __func__, rc);

	return rc;
}

static int32_t mt9p012_set_lc(void)
{
	int32_t rc;

	rc = mt9p012_i2c_write_w_table(mt9p012_regs.lctbl,
			mt9p012_regs.lctbl_size);

#if 0 /* Jignesh */
	if (rc < 0)
		return rc;
	rc = mt9p012_i2c_write_w_table(mt9p012_regs.rftbl,
			mt9p012_regs.rftbl_size);
#endif /* #if 0 */
	return rc;
}

static void mt9p012_get_pict_fps(uint16_t fps, uint16_t *pfps)
{
	/* input fps is preview fps in Q8 format */
	uint32_t divider;   /*Q10 */
	uint32_t pclk_mult; /*Q10 */
    uint32_t d1, d2;

	d1 = (uint32_t) ((mt9p012_regs.reg_pat[RES_PREVIEW].frame_length_lines *
      0x00000400) / mt9p012_regs.reg_pat[RES_CAPTURE].frame_length_lines);

	d2 = (uint32_t) ((mt9p012_regs.reg_pat[RES_PREVIEW].line_length_pck * 
      0x00000400) / mt9p012_regs.reg_pat[RES_CAPTURE].line_length_pck);

    divider = (uint32_t)(d1 * d2) / 0x00000400;

    /* Verify PCLK settings and frame sizes. */
	*pfps = (uint16_t) (fps * divider / 0x00000400);
 }

static uint16_t mt9p012_get_prev_lines_pf(void)
{
	if (mt9p012_ctrl->prev_res == QTR_SIZE)
		return mt9p012_regs.reg_pat[RES_PREVIEW].frame_length_lines;
	else
		return mt9p012_regs.reg_pat[RES_CAPTURE].frame_length_lines;
}

static uint16_t mt9p012_get_prev_pixels_pl(void)
{
	if (mt9p012_ctrl->prev_res == QTR_SIZE)
		return mt9p012_regs.reg_pat[RES_PREVIEW].line_length_pck;
	else
		return mt9p012_regs.reg_pat[RES_CAPTURE].line_length_pck;
}

static uint16_t mt9p012_get_pict_lines_pf(void)
{
	return mt9p012_regs.reg_pat[RES_CAPTURE].frame_length_lines;
}

static uint16_t mt9p012_get_pict_pixels_pl(void)
{
	return mt9p012_regs.reg_pat[RES_CAPTURE].line_length_pck;
}

static uint32_t mt9p012_get_pict_max_exp_lc(void)
{
	uint16_t snapshot_lines_per_frame;

	if (mt9p012_ctrl->pict_res == QTR_SIZE)
		snapshot_lines_per_frame =
		mt9p012_regs.reg_pat[RES_PREVIEW].frame_length_lines - 1;
	else
		snapshot_lines_per_frame =
		mt9p012_regs.reg_pat[RES_CAPTURE].frame_length_lines - 1;

	return snapshot_lines_per_frame * 24;
}

static int32_t mt9p012_set_fps(struct fps_cfg *fps)
{
	/* input is new fps in Q10 format */
	int32_t rc = 0;

	mt9p012_ctrl->fps_divider = fps->fps_div;
	mt9p012_ctrl->pict_fps_divider = fps->pict_fps_div;

	rc =
		mt9p012_i2c_write_w(mt9p012_client->addr,
			REG_GROUPED_PARAMETER_HOLD,
			GROUPED_PARAMETER_HOLD);
	if (rc < 0)
		return -EBUSY;

	rc =
		mt9p012_i2c_write_w(mt9p012_client->addr,
			REG_LINE_LENGTH_PCK,
			(mt9p012_regs.reg_pat[RES_PREVIEW].line_length_pck *
			fps->f_mult / 0x00000400));
	if (rc < 0)
		return rc;

	rc =
		mt9p012_i2c_write_w(mt9p012_client->addr,
			REG_GROUPED_PARAMETER_HOLD,
			GROUPED_PARAMETER_UPDATE);

	return rc;
}

static int32_t mt9p012_write_exp_gain(uint16_t gain, uint32_t line)
{
	uint16_t max_legal_gain = 0x01FF;
	uint32_t line_length_ratio = 0x00000400;
	enum mt9p012_setting_t setting;
	int32_t rc = 0;

	CDBG("Line:%d mt9p012_write_exp_gain \n", __LINE__);

	if (mt9p012_ctrl->sensormode == SENSOR_PREVIEW_MODE) {
		mt9p012_ctrl->my_reg_gain = gain;
		mt9p012_ctrl->my_reg_line_count = (uint16_t)line;
	}

	if (gain > max_legal_gain)
		gain = max_legal_gain;

	/* Verify no overflow */
	if (mt9p012_ctrl->sensormode != SENSOR_SNAPSHOT_MODE) {
		line = (uint32_t)(line * mt9p012_ctrl->fps_divider /
			0x00000400);
		setting = RES_PREVIEW;
	} else {
		line = (uint32_t)(line * mt9p012_ctrl->pict_fps_divider /
			0x00000400);
		setting = RES_CAPTURE;
	}

	/* Set digital gain to 1 */
#ifdef MT9P012_REV_7
	gain |= 0x1000;
#else
	gain |= 0x0200;
#endif

	if ((mt9p012_regs.reg_pat[setting].frame_length_lines - 1) < line) {
		line_length_ratio = (uint32_t) (line * 0x00000400) /
		(mt9p012_regs.reg_pat[setting].frame_length_lines - 1);
	} else
		line_length_ratio = 0x00000400;

#if 0
	rc =
		mt9p012_i2c_write_w(mt9p012_client->addr,
			REG_GROUPED_PARAMETER_HOLD, GROUPED_PARAMETER_HOLD);
	if (rc < 0) {
		CDBG("mt9p012_i2c_write_w failed... Line:%d \n", __LINE__);
		return rc;
	}
#endif

	rc =
		mt9p012_i2c_write_w(mt9p012_client->addr,
			REG_GLOBAL_GAIN, gain);
	if (rc < 0) {
		CDBG("mt9p012_i2c_write_w failed... Line:%d \n", __LINE__);
		return rc;
	}

#if 0
	rc =
		mt9p012_i2c_write_w(mt9p012_client->addr,
			REG_COARSE_INT_TIME,
			line);
#endif
	rc =
		mt9p012_i2c_write_w(mt9p012_client->addr,
			REG_COARSE_INT_TIME,
			(uint16_t)((uint32_t) line * 0x00000400 /
			line_length_ratio));
	if (rc < 0) {
		CDBG("mt9p012_i2c_write_w failed... Line:%d \n", __LINE__);
		return rc;
	}

	CDBG("mt9p012_write_exp_gain: gain = %d, line = %d\n", gain, line);

#if 0
	rc =
		mt9p012_i2c_write_w(mt9p012_client->addr,
			REG_GROUPED_PARAMETER_HOLD,
			GROUPED_PARAMETER_UPDATE);
	if (rc < 0)
		CDBG("mt9p012_i2c_write_w failed... Line:%d \n", __LINE__);
#endif

	return rc;
}

static int32_t mt9p012_set_pict_exp_gain(uint16_t gain, uint32_t line)
{
	int32_t rc = 0;

	CDBG("Line:%d mt9p012_set_pict_exp_gain \n", __LINE__);

	rc =
		mt9p012_write_exp_gain(gain, line);
	if (rc < 0) {
		CDBG("Line:%d mt9p012_set_pict_exp_gain failed... \n",
			__LINE__);
		return rc;
	}

	rc =
	mt9p012_i2c_write_w(mt9p012_client->addr,
		MT9P012_REG_RESET_REGISTER,
		0x10CC | 0x0002);
	if (rc < 0) {
		CDBG("mt9p012_i2c_write_w failed... Line:%d \n", __LINE__);
		return rc;
	}

	mdelay(5);

	return rc;
}

static int32_t mt9p012_setting(enum mt9p012_reg_update_t rupdate,
	enum mt9p012_setting_t rt)
{
	int32_t rc = 0;

	switch (rupdate) {
	case UPDATE_PERIODIC: {
	  if (rt == RES_PREVIEW || rt == RES_CAPTURE) {

		struct mt9p012_i2c_reg_conf ppc_tbl[] = {
		{REG_GROUPED_PARAMETER_HOLD, GROUPED_PARAMETER_HOLD},
		{REG_ROW_SPEED, mt9p012_regs.reg_pat[rt].row_speed},
		{REG_X_ADDR_START, mt9p012_regs.reg_pat[rt].x_addr_start},
		{REG_X_ADDR_END, mt9p012_regs.reg_pat[rt].x_addr_end},
		{REG_Y_ADDR_START, mt9p012_regs.reg_pat[rt].y_addr_start},
		{REG_Y_ADDR_END, mt9p012_regs.reg_pat[rt].y_addr_end},
		{REG_READ_MODE, mt9p012_regs.reg_pat[rt].read_mode},
		{REG_SCALE_M, mt9p012_regs.reg_pat[rt].scale_m},
		{REG_X_OUTPUT_SIZE, mt9p012_regs.reg_pat[rt].x_output_size},
		{REG_Y_OUTPUT_SIZE, mt9p012_regs.reg_pat[rt].y_output_size},

		{REG_LINE_LENGTH_PCK, mt9p012_regs.reg_pat[rt].line_length_pck},
		{REG_FRAME_LENGTH_LINES,
			(mt9p012_regs.reg_pat[rt].frame_length_lines *
			mt9p012_ctrl->fps_divider / 0x00000400)},
		{REG_COARSE_INT_TIME, mt9p012_regs.reg_pat[rt].coarse_int_time},
		{REG_FINE_INTEGRATION_TIME,
		  mt9p012_regs.reg_pat[rt].fine_int_time},
		{REG_GROUPED_PARAMETER_HOLD, GROUPED_PARAMETER_UPDATE},
		};

		rc = mt9p012_i2c_write_w_table(&ppc_tbl[0],
			ARRAY_SIZE(ppc_tbl));
		if (rc < 0)
			return rc;

		rc = mt9p012_test(mt9p012_ctrl->set_test);
		if (rc < 0)
			return rc;

		rc =
			mt9p012_i2c_write_w(mt9p012_client->addr,
			MT9P012_REG_RESET_REGISTER,
			MT9P012_RESET_REGISTER_PWON | 0x0002);
		if (rc < 0)
			return rc;

		mdelay(15);

		return rc;
	  }
	}
    break; /* UPDATE_PERIODIC */

	case REG_INIT: {
	    if (rt == RES_PREVIEW || rt == RES_CAPTURE) {
		struct mt9p012_i2c_reg_conf ipc_tbl1[] = {
		{MT9P012_REG_RESET_REGISTER, MT9P012_RESET_REGISTER_PWOFF},
		{REG_VT_PIX_CLK_DIV, mt9p012_regs.reg_pat[rt].vt_pix_clk_div},
		{REG_VT_SYS_CLK_DIV, mt9p012_regs.reg_pat[rt].vt_sys_clk_div},
		{REG_PRE_PLL_CLK_DIV, mt9p012_regs.reg_pat[rt].pre_pll_clk_div},
		{REG_PLL_MULTIPLIER, mt9p012_regs.reg_pat[rt].pll_multiplier},
		{REG_OP_PIX_CLK_DIV, mt9p012_regs.reg_pat[rt].op_pix_clk_div},
		{REG_OP_SYS_CLK_DIV, mt9p012_regs.reg_pat[rt].op_sys_clk_div},
#ifdef MT9P012_REV_7
		{0x30B0, 0x0001},
		/* Jeff: {0x308E, 0xE060},
		{0x3092, 0x0A52}, */
		{0x3094, 0x4656},
		/* Jeff: {0x3096, 0x5652},
		{0x30CA, 0x8006},
		{0x312A, 0xDD02},
		{0x312C, 0x00E4},
		{0x3170, 0x299A}, */
#endif
		/* optimized settings for noise */
#if 0 /* Jeff */
#ifdef MT9P012_5131
		{0x308E, 0xD66A},
		{0x3090, 0x566A},
		/* Reserved Register  (for hot pixel reduction) */
		{0x3088, 0x6FFF},
		/* Reserved Register (work around for dark column defects
		 * on some parts)
		 */
		{0x3086, 0x2468},
#else
		{0x3088, 0x6FF6},
#endif
#endif /* if 0 */

#if 0
		{0x3154, 0x0282},
		{0x3156, 0x0381},
		{0x3162, 0x04CE},
#endif /* if 0 */

		{0x0204, 0x0010},
		{0x0206, 0x0010},
		{0x0208, 0x0010},
		{0x020A, 0x0010},
		{0x020C, 0x0010},

#ifdef MT9P012_5131
		{0x3088, 0x6FFF}, //0x6FF6
		{0x3086, 0x2468},
#endif
		{MT9P012_REG_RESET_REGISTER, MT9P012_RESET_REGISTER_PWON},
		};

		struct mt9p012_i2c_reg_conf ipc_tbl2[] = {
		{MT9P012_REG_RESET_REGISTER, MT9P012_RESET_REGISTER_PWOFF},
		{REG_VT_PIX_CLK_DIV, mt9p012_regs.reg_pat[rt].vt_pix_clk_div},
		{REG_VT_SYS_CLK_DIV, mt9p012_regs.reg_pat[rt].vt_sys_clk_div},
		{REG_PRE_PLL_CLK_DIV, mt9p012_regs.reg_pat[rt].pre_pll_clk_div},
		{REG_PLL_MULTIPLIER, mt9p012_regs.reg_pat[rt].pll_multiplier},
		{REG_OP_PIX_CLK_DIV, mt9p012_regs.reg_pat[rt].op_pix_clk_div},
		{REG_OP_SYS_CLK_DIV, mt9p012_regs.reg_pat[rt].op_sys_clk_div},
#ifdef MT9P012_REV_7
		{0x30B0, 0x0001},
		{0x308E, 0xE060},
		{0x3092, 0x0A52},
		{0x3094, 0x4656},
		{0x3096, 0x5652},
		{0x30CA, 0x8006},
		{0x312A, 0xDD02},
		{0x312C, 0x00E4},
		{0x3170, 0x299A},
#endif
		/* optimized settings for noise */
		{0x3088, 0x6FF6},
		{0x3154, 0x0282},
		{0x3156, 0x0381},
		{0x3162, 0x04CE},
		{0x0204, 0x0010},
#if 0 /* ninad */
		{0x0206, 0x0010},
		{0x0208, 0x0010},
		{0x020A, 0x0010},
		{0x020C, 0x0010},
#endif
		{MT9P012_REG_RESET_REGISTER, MT9P012_RESET_REGISTER_PWON},
		};

		struct mt9p012_i2c_reg_conf ipc_tbl3[] = {
		{REG_GROUPED_PARAMETER_HOLD, GROUPED_PARAMETER_HOLD},
		/* Set preview or snapshot mode */
		{REG_ROW_SPEED, mt9p012_regs.reg_pat[rt].row_speed},
		{REG_X_ADDR_START, mt9p012_regs.reg_pat[rt].x_addr_start},
		{REG_X_ADDR_END, mt9p012_regs.reg_pat[rt].x_addr_end},
		{REG_Y_ADDR_START, mt9p012_regs.reg_pat[rt].y_addr_start},
		{REG_Y_ADDR_END, mt9p012_regs.reg_pat[rt].y_addr_end},
		{REG_READ_MODE, mt9p012_regs.reg_pat[rt].read_mode},
		{REG_SCALE_M, mt9p012_regs.reg_pat[rt].scale_m},
		{REG_X_OUTPUT_SIZE, mt9p012_regs.reg_pat[rt].x_output_size},
		{REG_Y_OUTPUT_SIZE, mt9p012_regs.reg_pat[rt].y_output_size},
		{REG_LINE_LENGTH_PCK, mt9p012_regs.reg_pat[rt].line_length_pck},
		{REG_FRAME_LENGTH_LINES,
			mt9p012_regs.reg_pat[rt].frame_length_lines},
		{REG_COARSE_INT_TIME, mt9p012_regs.reg_pat[rt].coarse_int_time},
		{REG_FINE_INTEGRATION_TIME,
		  mt9p012_regs.reg_pat[rt].fine_int_time},
		{REG_GROUPED_PARAMETER_HOLD, GROUPED_PARAMETER_UPDATE},
		};

		/* reset fps_divider */
		mt9p012_ctrl->fps_divider = 1 * 0x0400;

		rc = mt9p012_i2c_write_w_table(&ipc_tbl1[0],
			ARRAY_SIZE(ipc_tbl1));
		if (rc < 0)
			return rc;
#if 0 /* Jignesh */
		rc = mt9p012_i2c_write_w_table(&ipc_tbl2[0],
			ARRAY_SIZE(ipc_tbl2));
		if (rc < 0)
			return rc;
#endif
		mdelay(5);

		rc = mt9p012_i2c_write_w_table(&ipc_tbl3[0],
			ARRAY_SIZE(ipc_tbl3));
		if (rc < 0)
			return rc;

		/* load lens shading */
		rc = mt9p012_i2c_write_w(mt9p012_client->addr,
			REG_GROUPED_PARAMETER_HOLD, GROUPED_PARAMETER_HOLD);
		if (rc < 0)
			return rc;

		rc = mt9p012_set_lc();
		if (rc < 0)
			return rc;

		rc = mt9p012_i2c_write_w(mt9p012_client->addr,
			REG_GROUPED_PARAMETER_HOLD, GROUPED_PARAMETER_UPDATE);

		if (rc < 0)
			return rc;
		}
	}
		break; /* case REG_INIT: */

	default:
		rc = -EFAULT;
		break;
	} /* switch (rupdate) */

	return rc;
}

static int32_t mt9p012_video_config(enum sensor_mode_t mode,
	enum sensor_resolution_t res)
{
	int32_t rc;

	switch (res) {
	case QTR_SIZE:
		rc = mt9p012_setting(UPDATE_PERIODIC, RES_PREVIEW);
		if (rc < 0)
			return rc;

		CDBG("mt9p012 sensor configuration done!\n");
		break;

	case FULL_SIZE:
		rc =
		mt9p012_setting(UPDATE_PERIODIC, RES_CAPTURE);
		if (rc < 0)
			return rc;

		break;

	default:
		return 0;
	} /* switch */

	mt9p012_ctrl->prev_res = res;
	mt9p012_ctrl->curr_res = res;
	mt9p012_ctrl->sensormode = mode;

	rc =
		mt9p012_write_exp_gain(mt9p012_ctrl->my_reg_gain,
			mt9p012_ctrl->my_reg_line_count);

	rc =
		mt9p012_i2c_write_w(mt9p012_client->addr,
			MT9P012_REG_RESET_REGISTER,
			0x10cc|0x0002);

	return rc;
}

static int32_t mt9p012_snapshot_config(enum sensor_mode_t mode)
{
	int32_t rc = 0;

	rc = mt9p012_setting(UPDATE_PERIODIC, RES_CAPTURE);
	if (rc < 0)
		return rc;

	mt9p012_ctrl->curr_res = mt9p012_ctrl->pict_res;

	mt9p012_ctrl->sensormode = mode;

	return rc;
}

static int32_t mt9p012_raw_snapshot_config(enum sensor_mode_t mode)
{
	int32_t rc = 0;

	rc = mt9p012_setting(UPDATE_PERIODIC, RES_CAPTURE);
	if (rc < 0)
		return rc;

	mt9p012_ctrl->curr_res = mt9p012_ctrl->pict_res;

	mt9p012_ctrl->sensormode = mode;

	return rc;
}

static int32_t mt9p012_power_down(void)
{
	int32_t rc = 0;

	rc = mt9p012_i2c_write_w(mt9p012_client->addr,
		MT9P012_REG_RESET_REGISTER,
		MT9P012_RESET_REGISTER_PWOFF);

	mdelay(5);
	return rc;
}

static int32_t mt9p012_move_focus(enum sensor_move_focus_t direction,
	int32_t num_steps)
{
	int32_t rc = 0;
	int16_t step_direction;
	int16_t actual_step;
	int16_t next_position;
	uint8_t code_val;
	uint8_t time_out;
	uint16_t actual_position_target;
	uint16_t current_position_pi;
	uint16_t pi_gap;
	uint8_t ret_status = 0;

	CDBG("%s: IN \n", __func__);

	if (num_steps > MT9P012_TOTAL_STEPS_NEAR_TO_FAR)
		num_steps = MT9P012_TOTAL_STEPS_NEAR_TO_FAR;
	else if (num_steps == 0) {
		CDBG("mt9p012_move_focus failed at line %d ...\n", __LINE__);
		return -EINVAL;
	}

	if (direction == MOVE_NEAR)
		step_direction = -1;
	else if (direction == MOVE_FAR)
		step_direction = 1;
	else {
		CDBG("mt9p012_move_focus failed at line %d ...\n", __LINE__);
		return -EINVAL;
	}

	if (mt9p012_ctrl->curr_lens_pos < mt9p012_ctrl->init_curr_lens_pos)
		mt9p012_ctrl->curr_lens_pos =
			mt9p012_ctrl->init_curr_lens_pos;

	actual_step = (int16_t)(step_direction * (int16_t)num_steps);
	next_position = (int16_t)(mt9p012_ctrl->curr_lens_pos + actual_step);

	if (next_position > MT9P012_TOTAL_STEPS_NEAR_TO_FAR)
		next_position = MT9P012_TOTAL_STEPS_NEAR_TO_FAR;
	else if (next_position < 0)
		next_position = 0;

	code_val = next_position;
	actual_position_target = bam_step_lookup_table[code_val];
	current_position_pi = bam_step_lookup_table[mt9p012_current_lens_position];
	pi_gap = DIFF(actual_position_target, current_position_pi);
	if (pi_gap < 20) {
	  time_out = 15;
	} else if (pi_gap < 40 ) {
	  time_out = 30;
	} else if (pi_gap < 70)	{
	  time_out = 60;
	} else if (pi_gap < 100) {
	  time_out = 80;
	} else {
	  time_out = 100;
	}

	ret_status = move(actual_position_target, time_out);
	if ((ret_status == 0x04) || (ret_status == 0x08) ) {
		CDBG("%s: failed at line %d ...\n", __func__, __LINE__);
		return -EINVAL;
	}

	/* Storing the current lens Position */
	mt9p012_ctrl->curr_lens_pos = next_position;

	return rc;
}

static int32_t mt9p012_set_default_focus(void)
{
	int32_t rc = 0;

	/* Write the digital code for current to the actuator */
	move(bam_infinite,40);
	mt9p012_ctrl->curr_lens_pos = MT9P012_TOTAL_STEPS_NEAR_TO_FAR;
	return rc;
}

static int mt9p012_probe_init_done(struct msm_camera_sensor_info *data)
{
	gpio_direction_output(data->sensor_reset, 0);
	gpio_free(data->sensor_reset);
	return 0;
}

static int mt9p012_probe_init_sensor(struct msm_camera_sensor_info *data)
{
	int32_t  rc;
	uint16_t chipid;

	rc = gpio_request(data->sensor_reset, "mt9p012");
	if (!rc)
		gpio_direction_output(data->sensor_reset, 1);
	else
		goto init_probe_done;

	mdelay(20);


	/* enable mclk first */
	msm_camio_clk_rate_set(MT9P012_DEFAULT_CLOCK_RATE);

	mdelay(20);
	/* RESET the sensor image part via I2C command */
	rc = mt9p012_i2c_write_w(mt9p012_client->addr,
		MT9P012_REG_RESET_REGISTER, 0x10CC|0x0001);
	if (rc < 0) {
		CDBG("sensor reset failed. rc = %d\n", rc);
		goto init_probe_fail;
	}

	mdelay(MT9P012_RESET_DELAY_MSECS);

	/* 3. Read sensor Model ID: */
	rc = mt9p012_i2c_read_w(mt9p012_client->addr,
		MT9P012_REG_MODEL_ID, &chipid);
	if (rc < 0)
		goto init_probe_fail;

	/* 4. Compare sensor ID to MT9T012VC ID: */
	if (chipid != MT9P012_MODEL_ID) {
		if (chipid != MT9P012_MODEL_ID_5131) {
			rc = -ENODEV;
			goto init_probe_fail;
		}
	}

	rc = mt9p012_i2c_write_w(mt9p012_client->addr, 0x306E, 0x9000);
	if (rc < 0) {
		CDBG("REV_7 write failed. rc = %d\n", rc);
		goto init_probe_fail;
	}

	/* RESET_REGISTER, enable parallel interface and disable serialiser */
	rc = mt9p012_i2c_write_w(mt9p012_client->addr, 0x301A, 0x10CC);
	if (rc < 0) {
		CDBG("enable parallel interface failed. rc = %d\n", rc);
		goto init_probe_fail;
	}

	/* To disable the 2 extra lines */
	rc = mt9p012_i2c_write_w(mt9p012_client->addr,
		0x3064, 0x0805);

	if (rc < 0) {
		CDBG("disable the 2 extra lines failed. rc = %d\n", rc);
		goto init_probe_fail;
	}

	mdelay(MT9P012_RESET_DELAY_MSECS);
	goto init_probe_done;

init_probe_fail:
	mt9p012_probe_init_done(data);
init_probe_done:
	return rc;
}

static int mt9p012_sensor_open_init(struct msm_camera_sensor_info *data)
{
	int32_t  rc;
	uint8_t temp_pos;
	uint8_t i;
	uint16_t temp;

	mt9p012_ctrl = kzalloc(sizeof(struct mt9p012_ctrl_t), GFP_KERNEL);
	if (!mt9p012_ctrl) {
		CDBG("mt9p012_init failed!\n");
		rc = -ENOMEM;
		goto init_done;
	}

	mt9p012_ctrl->fps_divider = 1 * 0x00000400;
	mt9p012_ctrl->pict_fps_divider = 1 * 0x00000400;
	mt9p012_ctrl->set_test = TEST_OFF;
	mt9p012_ctrl->prev_res = QTR_SIZE;
	mt9p012_ctrl->pict_res = FULL_SIZE;

	if (data)
		mt9p012_ctrl->sensordata = data;

	/* enable mclk first */
	msm_camio_clk_rate_set(MT9P012_DEFAULT_CLOCK_RATE);
	mdelay(20);

	msm_camio_camif_pad_reg_reset();
	mdelay(20);

	rc = mt9p012_probe_init_sensor(data);
	if (rc < 0)
		goto init_fail1;

	if (mt9p012_ctrl->prev_res == QTR_SIZE)
		rc = mt9p012_setting(REG_INIT, RES_PREVIEW);
	else
		rc = mt9p012_setting(REG_INIT, RES_CAPTURE);

	if (rc < 0) {
		CDBG("mt9p012_setting failed. rc = %d\n", rc);
		goto init_fail1;
	}

	/* sensor : output enable */
	rc = mt9p012_i2c_write_w(mt9p012_client->addr,
		MT9P012_REG_RESET_REGISTER, MT9P012_RESET_REGISTER_PWON);
	if (rc < 0) {
		CDBG("sensor output enable failed. rc = %d\n", rc);
		goto init_fail1;
	}

	/* enable AF actuator */
	rc = gpio_request(mt9p012_ctrl->sensordata->vcm_pwd, "mt9p012");
	if (!rc)
		gpio_direction_output(mt9p012_ctrl->sensordata->vcm_pwd, 1);
	else {
		CDBG("mt9p012_ctrl gpio request failed!\n");
		goto init_fail1;
	}

	mdelay(20);

	bam_infinite = 0;
	bam_macro    = 0;
	/*initialize AF actuator*/
	if (mt9p012_i2c_write_b(MT9P012_AF_I2C_ADDR >> 1, 0x01, ic_cont_1) < 0) {
		CDBG("AF initialization is failed in reg 0x01 on first try");
		mdelay(10);
		if (mt9p012_i2c_write_b(MT9P012_AF_I2C_ADDR >> 1, 0x01,ic_cont_1) < 0)
			CDBG("AF initialization is failed in reg 0x01 on second try");
	}
	mdelay(15);

	if (mt9p012_i2c_write_b(MT9P012_AF_I2C_ADDR >> 1, 0x07, ic_cont_7) < 0) {
		CDBG("AF initialization is failed in reg 0x07 on first try");
		mdelay(10);
		if (mt9p012_i2c_write_b(MT9P012_AF_I2C_ADDR >> 1, 0x07,ic_cont_7) < 0)
			CDBG("AF initialization is failed in reg 0x07 on second try");
	}
	mdelay(15);

	if (mt9p012_i2c_write_b(MT9P012_AF_I2C_ADDR >> 1, 0x0A,0xFF) < 0) {
		CDBG("AF initialization is failed in reg 0x0A on first try");
		mdelay(10);
		if (mt9p012_i2c_write_b(MT9P012_AF_I2C_ADDR >> 1, 0x0A,0xFF) < 0)
			CDBG("AF initialization is failed in reg 0x0A on second try");
	}
	mdelay(15);

	if (mt9p012_i2c_write_b(MT9P012_AF_I2C_ADDR >> 1, 0x16,0x15) < 0) {
		CDBG("AF initialization is failed in reg 0x16 on first try");
		mdelay(10);
		if (mt9p012_i2c_write_b(MT9P012_AF_I2C_ADDR >> 1, 0x16,0x15) < 0)
			CDBG("AF initialization is failed in reg 0x16 on second try");
	}

	Init_freq();

	if (mt9p012_i2c_read_b(MT9P012_AF_I2C_ADDR >> 1, 0x12, &temp_pos) >= 0) {

		bam_infinite = (uint16_t)temp_pos;

		if (mt9p012_i2c_read_b(MT9P012_AF_I2C_ADDR >> 1, 0x13, &temp_pos) >= 0) {
			bam_infinite = (bam_infinite << 8)|((uint16_t)temp_pos);
		} else {
			CDBG("Reading infinite data on 0x13 is failed");
			temp_pos = 0x00;
			bam_infinite = (bam_infinite << 8)|((uint16_t)temp_pos);
		}
	} else {
		CDBG("Reading infinite data on 0x12 is failed");
		bam_infinite = 100;
	}

	if (mt9p012_i2c_read_b(MT9P012_AF_I2C_ADDR >> 1, 0x14, &temp_pos) >= 0) {
		bam_macro = (uint16_t)temp_pos;
		if (mt9p012_i2c_read_b(MT9P012_AF_I2C_ADDR >> 1, 0x15, &temp_pos) >= 0) {
			bam_macro = (bam_macro << 8) | ((uint16_t)temp_pos);
		} else {
			CDBG("Reading infinite data on 0x15 is failed");
			temp_pos = 0xff;
			bam_macro = (bam_macro << 8)|((uint16_t)temp_pos);
		}
	} else {
		CDBG("Reading infinite data on 0x14 is failed");
	}

	/* true infinite is 20 PI from 1.2m infinite */
	bam_infinite += 20;
	temp = (bam_infinite-bam_macro) / MT9P012_TOTAL_STEPS_NEAR_TO_FAR;
	for (i = 0; i < MT9P012_TOTAL_STEPS_NEAR_TO_FAR; i++)
		bam_step_lookup_table[i] = bam_macro + temp*i;

	bam_step_lookup_table[MT9P012_TOTAL_STEPS_NEAR_TO_FAR] = bam_infinite;

	rc = mt9p012_set_default_focus();
	if (rc >= 0)
		goto init_done;

init_fail1:
	mt9p012_probe_init_done(data);
	kfree(mt9p012_ctrl);
init_done:
	return rc;
}

static int mt9p012_init_client(struct i2c_client *client)
{
	/* Initialize the MSM_CAMI2C Chip */
	init_waitqueue_head(&mt9p012_wait_queue);
	return 0;
}

static int32_t mt9p012_set_sensor_mode(enum sensor_mode_t mode,
					enum sensor_resolution_t res)
{
	int32_t rc = 0;

	switch (mode) {
	case SENSOR_PREVIEW_MODE:
		rc = mt9p012_video_config(mode, res);
		break;

	case SENSOR_SNAPSHOT_MODE:
		rc = mt9p012_snapshot_config(mode);
		break;

	case SENSOR_RAW_SNAPSHOT_MODE:
		rc = mt9p012_raw_snapshot_config(mode);
		break;

	default:
		rc = -EINVAL;
		break;
	}

	return rc;
}

int mt9p012_sensor_config(void __user *argp)
{
	struct sensor_cfg_data_t cdata;
	long   rc = 0;

	if (copy_from_user(&cdata,
			(void *)argp,
			sizeof(struct sensor_cfg_data_t)))
		return -EFAULT;

	down(&mt9p012_sem);

	CDBG("%s: cfgtype = %d\n", __func__, cdata.cfgtype);
	switch (cdata.cfgtype) {
	case CFG_GET_PICT_FPS:
		mt9p012_get_pict_fps(cdata.cfg.gfps.prevfps,
			&(cdata.cfg.gfps.pictfps));

		if (copy_to_user((void *)argp, &cdata,
				sizeof(struct sensor_cfg_data_t)))
			rc = -EFAULT;
		break;

	case CFG_GET_PREV_L_PF:
		cdata.cfg.prevl_pf = mt9p012_get_prev_lines_pf();

		if (copy_to_user((void *)argp,
			&cdata,
			sizeof(struct sensor_cfg_data_t)))
			rc = -EFAULT;
		break;

	case CFG_GET_PREV_P_PL:
		cdata.cfg.prevp_pl = mt9p012_get_prev_pixels_pl();

		if (copy_to_user((void *)argp,
			&cdata,
			sizeof(struct sensor_cfg_data_t)))
			rc = -EFAULT;
		break;

	case CFG_GET_PICT_L_PF:
		cdata.cfg.pictl_pf = mt9p012_get_pict_lines_pf();

		if (copy_to_user((void *)argp,
			&cdata,
			sizeof(struct sensor_cfg_data_t)))
			rc = -EFAULT;
		break;

	case CFG_GET_PICT_P_PL:
		cdata.cfg.pictp_pl = mt9p012_get_pict_pixels_pl();

		if (copy_to_user((void *)argp,
			&cdata,
			sizeof(struct sensor_cfg_data_t)))
			rc = -EFAULT;
		break;

	case CFG_GET_PICT_MAX_EXP_LC:
		cdata.cfg.pict_max_exp_lc =
			mt9p012_get_pict_max_exp_lc();

		if (copy_to_user((void *)argp,
			&cdata,
			sizeof(struct sensor_cfg_data_t)))
			rc = -EFAULT;
		break;

	case CFG_SET_FPS:
	case CFG_SET_PICT_FPS:
		rc = mt9p012_set_fps(&(cdata.cfg.fps));
		break;

	case CFG_SET_EXP_GAIN:
		rc =
			mt9p012_write_exp_gain(cdata.cfg.exp_gain.gain,
				cdata.cfg.exp_gain.line);
		break;

	case CFG_SET_PICT_EXP_GAIN:
		CDBG("Line:%d CFG_SET_PICT_EXP_GAIN \n", __LINE__);
		rc =
			mt9p012_set_pict_exp_gain(
				cdata.cfg.exp_gain.gain,
				cdata.cfg.exp_gain.line);
		break;

	case CFG_SET_MODE:
		rc =
			mt9p012_set_sensor_mode(
			cdata.mode, cdata.rs);
		break;

	case CFG_PWR_DOWN:
		rc = mt9p012_power_down();
		break;

	case CFG_MOVE_FOCUS:
		CDBG("mt9p012_ioctl: CFG_MOVE_FOCUS: dir=%d steps=%d\n",
			cdata.cfg.focus.dir, cdata.cfg.focus.steps);
		rc =
			mt9p012_move_focus(
			cdata.cfg.focus.dir,
			cdata.cfg.focus.steps);
		break;

	case CFG_SET_DEFAULT_FOCUS:
		rc =
			mt9p012_set_default_focus();

		break;

	case CFG_SET_EFFECT:
		rc =
			mt9p012_set_default_focus();
		break;

	case CFG_SET_LENS_SHADING:
		CDBG("%s: CFG_SET_LENS_SHADING\n", __func__);
		rc = mt9p012_lens_shading_enable(
			cdata.cfg.lens_shading);
		break;

	default:
		rc = -EFAULT;
		break;
	}

	up(&mt9p012_sem);
	return rc;
}

int mt9p012_sensor_release(void)
{
	int rc = -EBADF;

	down(&mt9p012_sem);

	mt9p012_power_down();

	gpio_direction_output(mt9p012_ctrl->sensordata->sensor_reset,
		0);
	gpio_free(mt9p012_ctrl->sensordata->sensor_reset);

	gpio_direction_output(mt9p012_ctrl->sensordata->vcm_pwd, 0);
	gpio_free(mt9p012_ctrl->sensordata->vcm_pwd);

	kfree(mt9p012_ctrl);
	mt9p012_ctrl = NULL;

	CDBG("mt9p012_release completed\n");

	up(&mt9p012_sem);
	return rc;
}

static int mt9p012_probe(struct i2c_client *client,
	const struct i2c_device_id *id)
{
	int rc = 0;
	CDBG("mt9p012_probe called!\n");

	if (!i2c_check_functionality(client->adapter, I2C_FUNC_I2C)) {
		CDBG("%s: i2c_check_functionality failed\n");
		goto probe_failure;
	}

	mt9p012_sensorw = kzalloc(sizeof(struct mt9p012_work_t), GFP_KERNEL);
	if (!mt9p012_sensorw) {
		CDBG("kzalloc failed.\n");
		rc = -ENOMEM;
		goto probe_failure;
	}

	i2c_set_clientdata(client, mt9p012_sensorw);
	mt9p012_init_client(client);
	mt9p012_client = client;

	mdelay(50);

	CDBG("mt9p012_probe successed! rc = %d\n", rc);
	return 0;

probe_failure:
	CDBG("mt9p012_probe failed! rc = %d\n", rc);
	return rc;
}

static int __exit mt9p012_remove(struct i2c_client *client)
{
	struct mt9p012_work_t *sensorw = i2c_get_clientdata(client);
	free_irq(client->irq, sensorw);
	i2c_detach_client(client);
	mt9p012_client = NULL;
	kfree(sensorw);
	return 0;
}

static const struct i2c_device_id mt9p012_id[] = {
	{ "mt9p012", 0},
	{ }
};

static struct i2c_driver mt9p012_driver = {
	.id_table = mt9p012_id,
	.probe  = mt9p012_probe,
	.remove = __exit_p(mt9p012_remove),
	.driver = {
		.name = "mt9p012",
	},
};

static int32_t mt9p012_init(void)
{
	int32_t rc = 0;

	CDBG("mt9p012_init called - 3/9/09!\n");

	rc = i2c_add_driver(&mt9p012_driver);
	if (IS_ERR_VALUE(rc))
		goto init_fail;

	return rc;

init_fail:
	CDBG("mt9p012_init failed\n");
	return rc;
}

void mt9p012_exit(void)
{
	i2c_del_driver(&mt9p012_driver);
}

int mt9p012_probe_init(void *dev, void *ctrl)
{
	int rc = 0;
	struct msm_camera_sensor_info *info =
		(struct msm_camera_sensor_info *)dev;

	struct msm_sensor_ctrl_t *s = (struct msm_sensor_ctrl_t *)ctrl;

	rc = mt9p012_init();
	if (rc < 0)
		goto probe_done;

	msm_camio_clk_rate_set(MT9P012_DEFAULT_CLOCK_RATE);
	mdelay(20);

	rc = mt9p012_probe_init_sensor(info);
	if (rc < 0)
		goto probe_done;

	s->s_init = mt9p012_sensor_open_init;
	s->s_release = mt9p012_sensor_release;
	s->s_config  = mt9p012_sensor_config;
	mt9p012_probe_init_done(info);

probe_done:
	CDBG("%s %s:%d\n", __FILE__, __func__, __LINE__);
	return rc;
}
