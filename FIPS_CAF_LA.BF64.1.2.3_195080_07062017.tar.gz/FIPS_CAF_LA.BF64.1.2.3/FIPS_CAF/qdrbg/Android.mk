#############################################
#
# Builds both app and kernel module
# Test DLKM  :  qdrbg_module.ko
#
# ##########################################

LOCAL_PATH := $(call my-dir)
commonSources :=

# Test dlkm
DLKM_DIR   := device/qcom/common/dlkm

ifeq ($(ARCH),arm64)
	BLOB_DIR := blob_64bits
else
	BLOB_DIR := blob_32bits
endif

include $(CLEAR_VARS)

LOCAL_MODULE      := qdrbg_module.ko

LOCAL_SRC_FILES := msm_rng_wrapper.c \
		$(BLOB_DIR)/msm_rng_bin.o_shipped \
		$(BLOB_DIR)/ctr_drbg_bin.o_shipped \
		$(BLOB_DIR)/fips_drbg_bin.o_shipped \
		$(BLOB_DIR)/msm_fips_selftest_bin.o_shipped

LOCAL_MODULE_PATH := $(TARGET_ROOT_OUT_SBIN)
LOCAL_MODULE_TAGS := debug

include $(DLKM_DIR)/AndroidKernelModule.mk

HMAC_KEY := b617318655057264e28bc0b6fb378c8ef146be
QDRBG_MODULE := $(TARGET_ROOT_OUT_SBIN)/$(LOCAL_MODULE)

HMAC_QDRBG_MODULE := $(TARGET_ROOT_OUT_SBIN)/qdrbg_module.hmac

all_modules: $(HMAC_QDRBG_MODULE)

$(HMAC_QDRBG_MODULE): $(QDRBG_MODULE)
	$(shell openssl dgst -sha256 -hmac "$(HMAC_KEY)" $(QDRBG_MODULE) | awk '{ print $$2 }'  > $(HMAC_QDRBG_MODULE))

ALL_DEFAULT_INSTALLED_MODULES += $(HMAC_QDRBG_MODULE)
ALL_MODULES.$(LOCAL_MODULE).INSTALLED += $(HMAC_QDRBG_MODULE)


