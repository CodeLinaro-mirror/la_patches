LOCAL_PATH := $(call my-dir)
commonSources :=

# the dlkm
DLKM_DIR   := device/qcom/common/dlkm

ifeq ($(ARCH),arm64)
	BLOB_DIR := blob_64bits
else
	BLOB_DIR := blob_32bits
endif

include $(CLEAR_VARS)
LOCAL_SRC_FILES := qcrypto_wrapper.c \
		compat_qcedev.c \
		$(BLOB_DIR)/qcrypto_bin.o_shipped \
		$(BLOB_DIR)/qcedev_bin.o_shipped \
		$(BLOB_DIR)/qce_bin.o_shipped \
		$(BLOB_DIR)/qcedev_fips_bin.o_shipped \
		$(BLOB_DIR)/qcrypto_fips_bin.o_shipped
LOCAL_MODULE      := qcrypto_module.ko
LOCAL_MODULE_TAGS := debug
LOCAL_MODULE_PATH := $(PRODUCT_OUT)/root/sbin
include $(DLKM_DIR)/AndroidKernelModule.mk

HMAC_KEY := b617318655057264e28bc0b6fb378c8ef146be

HMAC_QCRYPTO_MODULE := $(TARGET_ROOT_OUT_SBIN)/qcrypto_module.hmac

all_modules: $(HMAC_QCRYPTO_MODULE)

$(HMAC_QCRYPTO_MODULE): $(TARGET_ROOT_OUT_SBIN)/qcrypto_module.ko
	$(shell mkdir -p $(PRODUCT_OUT)/root/sbin)
#	$(info $(shell openssl version))
#	$(info $(shell which openssl))
	$(shell openssl dgst -sha256 -hmac "$(HMAC_KEY)" $(TARGET_ROOT_OUT_SBIN)/qcrypto_module.ko | awk '{ print $$2 }'  > $(HMAC_QCRYPTO_MODULE))

ALL_DEFAULT_INSTALLED_MODULES += $(HMAC_QCRYPTO_MODULE)
ALL_MODULES.$(LOCAL_MODULE).INSTALLED += $(HMAC_QCRYPTO_MODULE)
