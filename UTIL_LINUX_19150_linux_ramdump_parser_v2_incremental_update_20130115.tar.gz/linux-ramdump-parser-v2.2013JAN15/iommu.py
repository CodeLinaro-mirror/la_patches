# Copyright (c) 2012, The Linux Foundation. All rights reserved.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 and
# only version 2 as published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

import sys
import re
import os
import struct
import datetime
import array
import string
import bisect
import traceback
import math
import rb_tree
from subprocess import *
from optparse import OptionParser
from optparse import OptionGroup
from struct import unpack
from ctypes import *
from tempfile import *
from print_out import *

'''
struct msm_iova_data {
	struct rb_node node;
	struct mem_pool *pools;
	int npools;
	struct iommu_domain *domain;
	int domain_num;
};

struct iommu_domain {
	void *priv;
	iommu_fault_handler_t handler;
};

void *priv above points to msm_priv

struct msm_priv {
	unsigned long *pgtable;
	int redirect;
	struct list_head list_attached;
};

'''

IOMMU_DOMAIN_VAR = 'domain_root'

#Keep these in sync with below offset_required_iommu table.
NODE_IDX = 0
POOLS_IDX = 1
NPOOLS_IDX = 2
DOMAIN_IDX = 3
DOMAIN_NUM_IDX = 4
MSM_IOVA_DATA_SIZE_IDX = 5
PRIV_IDX = 6
PG_TABLE_IDX = 7
REDIRECT_IDX = 8

#Keep these in sync with above IDX's
offsets_required_iommu = [
        ('((struct msm_iova_data *)0x0)', 'node', 0, 0),
        ('((struct msm_iova_data *)0x0)', 'pools', 0, 0),
        ('((struct msm_iova_data *)0x0)', 'npools', 0, 0),
        ('((struct msm_iova_data *)0x0)', 'domain', 0, 0),
        ('((struct msm_iova_data *)0x0)', 'domain_num', 0, 0),
        ('sizeof(struct msm_iova_data)','',0, 1),
        ('((struct iommu_domain *)0x0)', 'priv', 0, 0),
#        ('((struct msm_priv *)0x0)', 'pgtable', 0, 0),
#        ('((struct msm_priv *)0x0)', 'redirect', 0, 0)
]

SZ_4K = 0x1000
SZ_64K = 0x10000
SZ_1M = 0x100000
SZ_16M = 0x1000000

MAP_SIZE_STR = [ '4K', '8K', '16K', '32K', '64K',
			'128K', '256K', '512K', '1M', '2M',
			'4M', '8M', '16M']

def get_order(size):
	order = math.log(size,2)
	if (order % 1.0) != 0.0:
		print 'ERROR: Number is not a power of 2: %x' % (size)
		order = 0
	else:
		order -= math.log(SZ_4K, 2)
	return int(order)

class IOMMU(object):
	class Domain(object):
		def __init__(self):
			self.domain_num = -1
			self.pg_table = 0
			self.redirect = 0

	class FlatMapping(object):
		def __init__(self, virt, phys=-1, type='[]', size=SZ_4K, mapped=False):
			self.virt = virt
			self.phys = phys
			self.mapping_type = type
			self.mapping_size = size
			self.mapped = mapped

	class CollapsedMapping(object):
		def __init__(self, virt_start, virt_end, phys_start=-1, phys_end=-1, type='[]', size=SZ_4K, mapped=False):
			self.virt_start = virt_start
			self.virt_end = virt_end-1
			self.phys_start = phys_start
			self.phys_end = phys_end-1
			self.mapping_type = type
			self.mapping_size = size
			self.mapped = mapped
		def phys_size(self):
			return (self.phys_end - self.phys_start + 1)
		def virt_size(self):
			return (self.virt_end - self.virt_start + 1)

	def __init__(self, ram_dump):
		self.out_file = None
		self.ram_dump = ram_dump
		self.domain_list = []
		self.NUM_FL_PTE = 4096
		self.NUM_SL_PTE = 256

		self.FL_BASE_MASK = 0xFFFFFC00
		self.FL_TYPE_TABLE = (1 << 0)
		self.FL_TYPE_SECT = (2 << 0)
		self.FL_SUPERSECTION = (1 << 18)
		self.FL_AP0 = (1 << 10)
		self.FL_AP1 = (1 << 11)
		self.FL_AP2 = (1 << 15)
		self.FL_SHARED = (1 << 16)
		self.FL_BUFFERABLE = (1 << 2)
		self.FL_CACHEABLE = (1 << 3)
		self.FL_TEX0 = (1 << 12)
		self.FL_NG = (1 << 17)

		self.SL_BASE_MASK_LARGE	= 0xFFFF0000
		self.SL_BASE_MASK_SMALL = 0xFFFFF000
		self.SL_TYPE_LARGE = (1 << 0)
		self.SL_TYPE_SMALL = (2 << 0)
		self.SL_AP0 = (1 << 4)
		self.SL_AP1 = (2 << 4)
		self.SL_AP2 = (1 << 9)
		self.SL_SHARED = (1 << 10)
		self.SL_BUFFERABLE = (1 << 2)
		self.SL_CACHEABLE = (1 << 3)
		self.SL_TEX0 = (1 << 6)
		self.SL_NG = (1 << 11)
	def fl_offset(va):
		retrn (((va) & 0xFFF00000) >> 20)

	def sl_offset(va):
		retrn (((va) & 0xFF000) >> 12)

	def iommu_domain_func(self, node):
		node_offset = self.ram_dump.get_offset_struct(offsets_required_iommu[NODE_IDX][0], offsets_required_iommu[NODE_IDX][1])
		domain_num_offset = self.ram_dump.get_offset_struct(offsets_required_iommu[DOMAIN_NUM_IDX][0], offsets_required_iommu[DOMAIN_NUM_IDX][1])
		domain_offset = self.ram_dump.get_offset_struct(offsets_required_iommu[DOMAIN_IDX][0], offsets_required_iommu[DOMAIN_IDX][1])
		priv_offset = self.ram_dump.get_offset_struct(offsets_required_iommu[PRIV_IDX][0], offsets_required_iommu[PRIV_IDX][1])
		#redirect_offset = self.ram_dump.get_offset_struct(offsets_required_iommu[REDIRECT_IDX][0], offsets_required_iommu[REDIRECT_IDX][1])
		#pgtable_offset = self.ram_dump.get_offset_struct(offsets_required_iommu[PG_TABLE_IDX][0], offsets_required_iommu[PG_TABLE_IDX][1])

		domain_num_addr = (node - node_offset) + domain_num_offset
		domain_num = self.ram_dump.read_word(domain_num_addr)

		domain_addr = (node - node_offset) + domain_offset
		domain = self.ram_dump.read_word(domain_addr)


		priv = self.ram_dump.read_word(domain + priv_offset)
		#Todo: Hardcode the offset for now since we are unable to look up the symbol.
		#pg_table = self.ram_dump.read_word(priv + pgtable_offset)
		pg_table = self.ram_dump.read_word(priv + 0)
		#Todo: Hardcode the offset for now since we are unable to look up the symbol.
		#redirect = self.ram_dump.read_word(priv + redirect_offset)
		redirect = self.ram_dump.read_word(priv + 4)

		domain = self.Domain()
		domain.domain_num = domain_num
		domain.pg_table = pg_table
		#domain.redirect = redirect
		domain.redirect = redirect
		self.domain_list.append(domain)

	def print_sl_page_table(self, pg_table):
		sl_pte = pg_table
		for i in range(0,self.NUM_SL_PTE):
			phy_addr = self.ram_dump.read_word(sl_pte, False)
			if phy_addr is not None: #and phy_addr & self.SL_TYPE_SMALL:
				read_write = '[R/W]'
				if phy_addr & self.SL_AP2:
					read_write = '[R]'

				if phy_addr & self.SL_TYPE_SMALL:
					self.out_file.write('SL_PTE[%d] = %x %s\n' % (i, phy_addr & self.SL_BASE_MASK_SMALL, read_write))
				elif phy_addr & self.SL_TYPE_LARGE:
					self.out_file.write('SL_PTE[%d] = %x %s\n' % (i, phy_addr & self.SL_BASE_MASK_LARGE, read_write))
				elif phy_addr != 0:
					self.out_file.write('SL_PTE[%d] = %x NOTE: ERROR [Do not understand page table bits]\n' % (i, phy_addr))
			sl_pte += 4


	def print_page_table(self, pg_table):
		fl_pte = pg_table
		for i in range(0,self.NUM_FL_PTE):
		#for i in range(0,5):
			sl_pg_table_phy_addr = self.ram_dump.read_word(fl_pte)
			if sl_pg_table_phy_addr is not None:
				if sl_pg_table_phy_addr & self.FL_TYPE_TABLE:
					self.out_file.write('FL_PTE[%d] = %x [4K/64K]\n' % (i, sl_pg_table_phy_addr & self.FL_BASE_MASK))
					self.print_sl_page_table(sl_pg_table_phy_addr & self.FL_BASE_MASK)
				elif sl_pg_table_phy_addr & self.FL_SUPERSECTION:
					self.out_file.write('FL_PTE[%d] = %x [16M]\n' % (i, sl_pg_table_phy_addr & 0xFF000000))
				elif sl_pg_table_phy_addr & self.FL_TYPE_SECT:
					self.out_file.write('FL_PTE[%d] = %x [1M]\n' % (i, sl_pg_table_phy_addr & 0xFFF00000))
				elif sl_pg_table_phy_addr != 0:
					self.out_file.write('FL_PTE[%d] = %x NOTE: ERROR [Cannot understand first level page table entry]\n' % (i, sl_pg_table_phy_addr))
			else:
					self.out_file.write('FL_PTE[%d] NOTE: ERROR [Cannot understand first level page table entry]\n' % (i))
			fl_pte += 4

	def get_mapping_info(self, pg_table, index):
		sl_pte = pg_table + (index * 4)
		phy_addr = self.ram_dump.read_word(sl_pte, False)
		current_phy_addr = -1
		current_page_size = SZ_4K
		current_map_type = 0
		status = True
		if phy_addr is not None:
			if phy_addr & self.SL_AP2:
				current_map_type = self.SL_AP2
			if phy_addr & self.SL_TYPE_SMALL:
				current_phy_addr = phy_addr & self.SL_BASE_MASK_SMALL
				current_page_size = SZ_4K
			elif phy_addr & self.SL_TYPE_LARGE:
				current_phy_addr = phy_addr & self.SL_BASE_MASK_LARGE
				current_page_size = SZ_64K
			elif phy_addr != 0:
				current_phy_addr = phy_addr
				status = False

		return (current_phy_addr, current_page_size, current_map_type, status)

	def get_sect_mapping_info(self, addr):
		current_phy_addr = -1
		current_page_size = SZ_4K
		current_map_type = 0
		status = True
		if addr is not None:
			if addr & self.SL_AP2:
				current_map_type = self.SL_AP2
			if addr & self.FL_SUPERSECTION:
				current_phy_addr = addr & 0xFF000000
				current_page_size = SZ_16M
			elif addr & self.FL_TYPE_SECT:
				current_phy_addr = addr & 0xFFF00000
				current_page_size = SZ_1M
			elif addr != 0:
				current_phy_addr = addr
				status = False

		return (current_phy_addr, current_page_size, current_map_type, status)

	def add_flat_mapping(self, mappings, fl_idx, sl_idx, phy_adr, map_type, page_size, mapped):
		virt = (fl_idx << 20) | (sl_idx << 12)
		map_type_str = '[R/W]'
		if map_type == self.SL_AP2:
			map_type_str = '[R]'
		map = self.FlatMapping(virt, phy_adr, map_type_str, page_size, mapped)
		if not mappings.has_key(virt):
			mappings[virt] = map
		else:
			self.out_file.write('[!] WARNING: FL_PTE[%d] SL_PTE[%d] ERROR [Duplicate mapping?]\n' % (fl_idx, sl_idx))
		return mappings

	def add_collapsed_mapping(self, mappings, virt_start, virt_end, phys_start, phys_end, map_type, page_size, mapped):
		map = self.CollapsedMapping(virt_start, virt_end, phys_start, phys_end, map_type, page_size, mapped)
		if not mappings.has_key(virt_start):
			mappings[virt_start] = map
		else:
			self.out_file.write('[!] WARNING: ERROR [Duplicate mapping at virtual address 0x%08x?]\n' % (virt_start))
		return mappings

	def create_flat_mapping(self, pg_table):
		tmp_mapping = {}
		fl_pte = pg_table
		for fl_index in range(0,self.NUM_FL_PTE):
			sl_pg_table_phy_addr = self.ram_dump.read_word(fl_pte)

			if sl_pg_table_phy_addr is not None:
				if sl_pg_table_phy_addr & self.FL_TYPE_TABLE:
					sl_pte = sl_pg_table_phy_addr & self.FL_BASE_MASK

					for sl_index in range(0,self.NUM_SL_PTE):
						(phy_addr, page_size, map_type, status) = self.get_mapping_info(sl_pte, sl_index)
						if status:
							if phy_addr != -1:
								tmp_mapping = self.add_flat_mapping(tmp_mapping, fl_index, sl_index, phy_addr, map_type, page_size, True)
							else:
								#no mapping
								tmp_mapping = self.add_flat_mapping(tmp_mapping, fl_index, sl_index, -1, 0, 0, False)
						else:
							self.out_file.write('[!] WARNING: FL_PTE[%d] SL_PTE[%d] ERROR [Unknown error]\n' % (fl_index, sl_index))
				elif sl_pg_table_phy_addr & self.FL_TYPE_SECT:
					(phy_addr, page_size, map_type, status) = self.get_sect_mapping_info(sl_pg_table_phy_addr)
					if status:
						if phy_addr != -1:
							tmp_mapping = self.add_flat_mapping(tmp_mapping, fl_index, 0, phy_addr, map_type, page_size, True)
						else:
							#no mapping
							tmp_mapping = self.add_flat_mapping(tmp_mapping, fl_index, 0, -1, 0, 0, False)
				elif sl_pg_table_phy_addr != 0:
					self.out_file.write('[!] WARNING: FL_PTE[%d] = %x NOTE: ERROR [Cannot understand first level page table entry]\n' % (fl_index, sl_pg_table_phy_addr))
				else:
					tmp_mapping = self.add_flat_mapping(tmp_mapping, fl_index, 0, -1, 0, 0, False)
			else:
				self.out_file.write('[!] WARNING: FL_PTE[%d] NOTE: ERROR [Cannot understand first level page table entry]\n' % (fl_index))
			fl_pte += 4
		return tmp_mapping

	def create_collapsed_mapping(self, flat_mapping):
		collapsed_mapping = {}
		if len(flat_mapping.keys()) > 0:
			virt_addrs = sorted(flat_mapping.keys())
			start_map = prev_map = flat_mapping[virt_addrs[0]]
			last_mapping = False
			for virt in virt_addrs[1:]:
				map = flat_mapping[virt]
				new_mapping = False
				if map.mapping_size == prev_map.mapping_size and map.mapping_type == prev_map.mapping_type and map.mapped == prev_map.mapped:
					if prev_map.mapping_size == SZ_4K:
						if (map.phys - SZ_4K) != prev_map.phys and map.phys != prev_map.phys:
							new_mapping = True
					elif prev_map.mapping_size == SZ_64K:
						if (map.phys - SZ_64K) != prev_map.phys and map.phys != prev_map.phys:
							new_mapping = True
					elif prev_map.mapping_size == SZ_1M:
						if (map.phys - SZ_1M) != prev_map.phys and map.phys != prev_map.phys:
							new_mapping = True
					elif prev_map.mapping_size == SZ_16M:
						if (map.phys - SZ_16M) != prev_map.phys and map.phys != prev_map.phys:
							new_mapping = True
					elif virt == virt_addrs[-1]:
						#Last one
						last_mapping = True
				else:
					new_mapping = True
				if new_mapping:
					collapsed_mapping = self.add_collapsed_mapping(collapsed_mapping, start_map.virt, map.virt,
																	start_map.phys, prev_map.phys+prev_map.mapping_size,
																	prev_map.mapping_type, prev_map.mapping_size, prev_map.mapped)
					start_map = map
				elif last_mapping:
					collapsed_mapping = self.add_collapsed_mapping(collapsed_mapping, start_map.virt, 0xFFFFFFFF+1,
																	start_map.phys, prev_map.phys+prev_map.mapping_size,
																	prev_map.mapping_type, prev_map.mapping_size, prev_map.mapped)
				prev_map = map
		return collapsed_mapping

	def print_page_table_pretty(self, pg_table):
		flat_mapping = self.create_flat_mapping(pg_table)
		collapsed_mapping = self.create_collapsed_mapping(flat_mapping)

		for virt in sorted(collapsed_mapping.keys()):
			mapping = collapsed_mapping[virt]
			if mapping.mapped:
				self.out_file.write('0x%08x--0x%08x [0x%08x] A:0x%08x--0x%08x [0x%08x] %s[%s]\n' % (mapping.virt_start, mapping.virt_end, mapping.virt_size(),
																						mapping.phys_start, mapping.phys_end,
																						mapping.phys_size(), mapping.mapping_type, MAP_SIZE_STR[get_order(mapping.mapping_size)]))
			else:
				self.out_file.write('0x%08x--0x%08x [0x%08x] [UNMAPPED]\n' % (mapping.virt_start, mapping.virt_end, mapping.virt_size()))

	def iommu_parse(self):
		iommu_domains_rb_root = self.ram_dump.addr_lookup(IOMMU_DOMAIN_VAR)
		if iommu_domains_rb_root is None :
			print_out_str ('[!] WARNING: IOMMU domains was not found in this build. No IOMMU page tables will be generated')
			return

                out_dir = self.ram_dump.outdir
		self.ram_dump.setup_offset_table(offsets_required_iommu)

		iommu_domains_rb_root_addr = self.ram_dump.read_word(iommu_domains_rb_root)
		rb_walker = rb_tree.RbTreeWalker(self.ram_dump)
		rb_walker.walk(iommu_domains_rb_root_addr, self.iommu_domain_func)

		for d in self.domain_list:
			self.out_file = open('%s/msm_iommu_domain_%02d.txt' % (out_dir, d.domain_num), 'wb')
			redirect = 'OFF'
			if d.redirect > 0:
				redirect = 'ON'

			self.out_file.write('Domain: %d [L2 cache redirect for page tables is %s]\n' % (d.domain_num, redirect))
			self.print_page_table_pretty(d.pg_table)
			self.out_file.write('\n-------------\nRAW Dump\n')
			self.print_page_table(d.pg_table)
			self.out_file.close()

