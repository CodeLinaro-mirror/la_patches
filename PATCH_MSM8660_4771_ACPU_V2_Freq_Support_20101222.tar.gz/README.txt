The included changes adds support for MSM8660 V2 Frequency Table.  At this point, the feature is not complete and requires the following to be disabled:

Stand-alone power-collapse must be disabled:
	echo 0 > /sys/module/pm_8x60/modes/cpu0/standalone_power_collapse/suspend_enabled
	echo 0 > /sys/module/pm_8x60/modes/cpu1/standalone_power_collapse/suspend_enabled
	echo 0 > /sys/module/pm_8x60/modes/cpu0/standalone_power_collapse/idle_enabled
	echo 0 > /sys/module/pm_8x60/modes/cpu1/standalone_power_collapse/idle_enabled

RPM-assisted power-collapse needs to be disabled:
	echo 0 > /sys/module/pm_8x60/modes/cpu0/power_collapse/suspend_enabled
	echo 0 > /sys/module/pm_8x60/modes/cpu1/power_collapse/suspend_enabled
	echo 0 > /sys/module/pm_8x60/modes/cpu0/power_collapse/idle_enabled
	echo 0 > /sys/module/pm_8x60/modes/cpu1/power_collapse/idle_enabled


