ls
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/ NetworkPatch.tar.gz /usr/local/most/patches/release/quic/la/
clear
tar zcf PATCH_NetworkPatch.tar.gz .
ls 
scp PATCH_NetworkPatch.tar.gz.tar.gz harishkumarm@codeaurora.org:/usr/local/most/patches/staging/quic/la
scp PATCH_NetworkPatch.tar.gz harishkumarm@codeaurora.org:/usr/local/most/patches/staging/quic/la
ssh -t harishkumarm@codeaurora.org sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/PATCH_NetworkPatch.tar.gz /usr/local/most/patches/release/quic/la/
clear
ssh -t harishkumarm@codeaurora.org sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/PATCH_NetworkPatch.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/ PATCH_DisableTBS_10707_01312012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/PATCH_DisableTBS_10707_01312012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/PATCH_745190_ION_Cache_Changes_02012012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/PATCH_Rendering_02032012.tar.gz.tar.gz /usr/local/most/patches/release/quic/la/
clear
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/PATCH_Rendering_02032012.tar.gz.tar.gz /usr/local/most/patches/release/quic/la/
ls -l
exit
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/PATCH_Rendering_02032012.tar.gz.tar.gz /usr/local/most/patches/release/quic/la/
clear
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/PATCH_Rendering_02032012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/PATCH_Power_WW_02062012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/ PATCH_Tcp_Fing_10812_02072012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/PATCH_Tcp_Fing_10812_02072012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/PATCH_WebApps_02072012.tar.gz /usr/local/most/patches/release/quic/la/
clera
clear
ls
exit
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/PATCH_WebApps_02072012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/PATCH_10847_02082012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/PATCH_Canvas_10881_10768_02102012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/PATCH_Power_10928_03132012.tar.gz /usr/local/most/patches/release/quic/la/
clear
exit
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/PATCH_Browser_Power_10928_03132012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/PATCH_WebApps_03162012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/PATCH_ZoomInOut_5947_03162012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/PATCH_WebWorkers_03162012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/Webapps_02222012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/PATCH_6375_02232012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/PATCH_HTML5_02282012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/Canvas_10881_03012012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/Zoom_10977_03022012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/SBA_WiFi_AU_074_03022012.tar.gz.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/SBA_WiFi_AU_074_03022012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/PATCH_MSM8960_WebWorkers_03052012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/DSP_Perf_11366_03062012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/PATCH_8960_7x27a_Zoom_10977_03072012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/PATCH_TBS_11359_03082012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/PATCH_8960_WebApps_03212012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/SBA_8960_NWStackCrashFix_04052012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/PATCH_GUIMark_04092012.tar.gz /usr/local/most/patches/release/quic/la/
exit
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/PATCH_8960_Network_04092012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/PATCH_NetWorkRendering_04102012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/PATCH_WebApps_04112012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/PATCH_Canvas_04112012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/SBA_QTBS_12413_04202012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/8x55_QTBS_04272012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/harishkumarm.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/QTBS_04272012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/Webtech_Canvas_Rendering_04302012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/Disp_04032012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/Canvas_MR4_05212012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/WebWorkers_05242012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/BrowserMgmt_123981_05302012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/ScrollZoom.tar.gz /usr/local/most/patches/release/quic/la/
ssh harishkumarm@codeaurora.org
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/SBA_8960_WebGL.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/SBA_WEbGL_07032012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/SBA_8960_DnsOpt_07252012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/SBA_UI_07262012.tar.gz /usr/local/most/patches/release/quic/la/
pwd
exit
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/SBA_UI_07262012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/SBA_Crash_Logs.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/SBA_M8960_Dinara_LTE.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/PATCH_MSM8960_940358_GPUCanvas_fixes_20120815.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/PATCH_8960_ICS_20120815.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/SBA_8960_JB_V8_OpenSource.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/SBA_JB_WebApps_08212012.tar.gz /usr/local/most/patches/release/quic/la/
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/SBA_GPU_Canvas_08282012.tar.gz /usr/local/most/patches/release/quic/l
sudo -u sbarelease cp /usr/local/most/patches/staging/quic/la/SBA_GPU_Canvas_08282012.tar.gz /usr/local/most/patches/release/quic/la
