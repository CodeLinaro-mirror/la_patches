
    Release Notes for Patch adding ISP1763A USB Controller driver support

    The code of this driver is based on the 'v1.2.1' driver taken from
    ST-E. It supports just the host controller on the ISP1763A.

    It has been tested on MSM8660 based on the CRM release:
    M8660AAABQNLGA1055.


*******

Driver version information
   This patch is based on the 'v1.2.1' isp1763A driver provided by ST-E
   and has been tested with the M8660AAABQNLGA1055 release of 8660.


*******

Files affected
   Following new files are added:
   drivers/usb/host/pehci/Makefile
   drivers/usb/host/pehci/hal/Makefile
   drivers/usb/host/pehci/hal/hal_intf.h
   drivers/usb/host/pehci/hal/hal_msm.c
   drivers/usb/host/pehci/hal/hal_msm.h
   drivers/usb/host/pehci/hal/isp1763.h
   drivers/usb/host/pehci/host/Makefile
   drivers/usb/host/pehci/host/itdptd.c
   drivers/usb/host/pehci/host/mem.c
   drivers/usb/host/pehci/host/pehci.c
   drivers/usb/host/pehci/host/pehci.h
   drivers/usb/host/pehci/host/qtdptd.c

   Following is the list of modified files:
   arch/arm/configs/msm8660_defconfig
   arch/arm/mach-msm/board-msm8x60.c
   arch/arm/mach-msm/gpiomux-8x60.c
   arch/arm/mach-msm/include/mach/board.h
   drivers/usb/Makefile
   drivers/usb/host/Kconfig
   drivers/usb/host/Makefile


*******

Configuration

   This driver can be compiled by enabling the following config option:
   CONFIG_USB_PEHCI_HCD

   isp1763a has 24KB of memory that can be used for PTD payload transfers.
   This memory is divided into a number of memory blocks. The configuration
   of the blocks can be controlled from the file:
   drivers/usb/host/pehci/host/pehci.h

