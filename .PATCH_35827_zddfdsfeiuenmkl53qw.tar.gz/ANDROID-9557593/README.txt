ID: ANDROID-9557593
Affected Android versions: prior to Android 4.0 (Ice Cream Sandwich)
A path check flaw in AudioFlinger lets arbitrary apps inject arbitrary code into AudioFlinger by loading dynamic libraries via AudioFlinger�s LOAD_EFFECT_LIBRARY RPC. This RPC has been removed in Android 4.0, therefore Android 4.0 and newer are not affected. Fix for versions prior to Android 4.0 is not available.


