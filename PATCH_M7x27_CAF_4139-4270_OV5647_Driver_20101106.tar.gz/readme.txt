Place the code at kernel/drivers/media/video/msm/

Note: In ov5647.h, OV5647_AF_I2C_ADDR may be set to 0x18 if AF does not work.

