/* Copyright (c) 2010, Code Aurora Forum. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 and
 * only version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301, USA.
 *
 */


#include <linux/delay.h>
#include <linux/types.h>
#include <linux/i2c.h>
#include <linux/uaccess.h>
#include <linux/miscdevice.h>
#include <media/msm_camera.h>
#include <mach/gpio.h>
#include <mach/camera.h>
#include "ov5647.h"
#include <mach/vreg.h>

#define OV5647_DEFAULT_CLOCK_RATE  24000000

struct reg_struct const ov5647_reg_pat[2] = {
	{ /* Preview */
		/* vt_pix_clk_div          REG=0x0300 */
		6,  /* 5 */

		/* vt_sys_clk_div          REG=0x0302 */
		1,

		/* pre_pll_clk_div         REG=0x0304 */
		2,

		/* pll_multiplier          REG=0x0306 */
		60,

		/* op_pix_clk_div          REG=0x0308 */
		8,  /* 10 */

		/* op_sys_clk_div          REG=0x030A */
		1,

		/* scale_m                 REG=0x0404 */
		16,

		/* row_speed               REG=0x3016 */
		0x0111,

		/* x_addr_start            REG=0x3004 */
		8,

		/* x_addr_end              REG=0x3008 */
		2597,

		/* y_addr_start            REG=0x3002 */
		8,

		/* y_addr_end              REG=0x3006 */
		1949,

		/* read_mode               REG=0x3040
		 * Preview 2x2 skipping */
		0x006C,

		/* x_output_size           REG=0x034C */
		1296,

		/* y_output_size           REG=0x034E */
		972,

		/* line_length_pck         REG=0x300C */
		3783,

		/* frame_length_lines      REG=0x300A */
		1074,

		/* coarse_integration_time REG=0x3012 */
		16,

		/* fine_integration_time   REG=0x3014 */
		1764
	},
	{ /* Snapshot */
		/* vt_pix_clk_div          REG=0x0300 */
		6,

		/* vt_sys_clk_div          REG=0x0302 */
		1,

		/* pre_pll_clk_div         REG=0x0304 */
		2,

		/* pll_multiplier          REG=0x0306
		 * 39 for 10fps snapshot */
		39,

		/* op_pix_clk_div          REG=0x0308 */
		8,

		/* op_sys_clk_div          REG=0x030A */
		1,

		/* scale_m                 REG=0x0404 */
		16,

		/* row_speed               REG=0x3016 */
		0x0111,

		/* x_addr_start            REG=0x3004 */
		8,

		/* x_addr_end              REG=0x3008 */
		2615,

		/* y_addr_start            REG=0x3002 */
		8,

		/* y_addr_end              REG=0x3006 */
		1967,

		/* read_mode               REG=0x3040 */
		0x0024,

		/* x_output_size           REG=0x034C */
		2608,

		/* y_output_size           REG=0x034E */
		1960,

		/* line_length_pck         REG=0x300C */
		3788,

		/* frame_length_lines      REG=0x300A 10 fps snapshot */
		2045,

		/* coarse_integration_time REG=0x3012 */
		16,

		/* fine_integration_time   REG=0x3014 */
		882
	}
};

#define REG_OV5647_GAIN_MSB           0x350A
#define REG_OV5647_GAIN_LSB           0x350B
#define REG_OV5647_LINE_HSB           0x3500
#define REG_OV5647_LINE_MSB           0x3501
#define REG_OV5647_LINE_LSB           0x3502


//Camera Power
static struct vreg *vreg_CAM_gp3;      //power 1.5v
static struct vreg *vreg_CAM_gp6;      //power 2.8v
static struct vreg *vreg_CAM_wlan;     //power 2.8v

//Camera init flag for check if it is inited.
static bool camera_init_flag;

struct ov5647_work {
   struct work_struct work;
};
static struct ov5647_work *ov5647_sensorw;
static struct i2c_client    *ov5647_client;
static DECLARE_WAIT_QUEUE_HEAD(ov5647_wait_queue);
DEFINE_MUTEX(ov5647_mutex);
static u8 ov5647_i2c_buf[4];
static u8 ov5647_counter = 0;

struct __ov5647_ctrl 
{
	const struct msm_camera_sensor_info *sensordata;
	int sensormode;
	uint fps_divider; /* init to 1 * 0x00000400 */
	uint pict_fps_divider; /* init to 1 * 0x00000400 */
	u16 curr_step_pos;
	u16 curr_lens_pos;
	u16 init_curr_lens_pos;
	u16 my_reg_gain;
	u16 my_reg_line_count;
	enum msm_s_resolution prev_res;
	enum msm_s_resolution pict_res;
	enum msm_s_resolution curr_res;
	enum msm_s_test_mode  set_test;
};
static struct __ov5647_ctrl *ov5647_ctrl;
//static u32 exp_gain_tbl[3][2];

static int ov5647_i2c_remove(struct i2c_client *client);
static int ov5647_i2c_probe(struct i2c_client *client,const struct i2c_device_id *id);

static int ov5647_i2c_txdata(u16 saddr,u8 *txdata,int length)
{
	struct i2c_msg msg[] = {
		{
			.addr  = saddr,
			.flags = 0,
			.len = length,
			.buf = txdata,
		},
	};
	if (i2c_transfer(ov5647_client->adapter, msg, 1) < 0)	return -EIO;
	else return 0;
}

static int ov5647_i2c_write(unsigned short saddr, unsigned int waddr,
	unsigned short bdata,u8 trytimes)
{
   int rc = -EIO;
   ov5647_counter = 0;
   ov5647_i2c_buf[0] = (waddr & 0xFF00)>>8;
   ov5647_i2c_buf[1] = (waddr & 0x00FF);
   //ov5647_i2c_buf[2] = (bdata & 0xFF00)>>8;
   ov5647_i2c_buf[2] = (bdata & 0x00FF);
   
   while ( (ov5647_counter<trytimes) &&(rc != 0) )
   {
      rc = ov5647_i2c_txdata(saddr, ov5647_i2c_buf, 3);
      if (rc < 0)
      {
      	ov5647_counter++;
      	printk(KERN_ERR "***Tom i2c_write_w failed,i2c addr=0x%x, command addr = 0x%x, val = 0x%x, s=%d, rc=%d!\n",saddr,waddr, bdata,ov5647_counter,rc);
      	msleep(4);
      }
      else 
	  {
	  	printk(KERN_ERR "i2c_write_w succeed,i2c addr=0x%x, command addr = 0x%x, val = 0x%x, s=%d, rc=%d!\n",saddr,waddr, bdata,ov5647_counter,rc);
		//printk(KERN_ERR "--CAMERA--i2c_write_w ok!\n");
	  }
   }
   return rc;
}


static void camera_power_onoff(u8 v)
{
	return;
}

static int ov5647_write_exp_gain(uint16_t gain, uint32_t line){
	int rc = 0;	
	u8 intg_time_hsb,intg_time_msb, intg_time_lsb;
	ov5647_ctrl->my_reg_gain = gain;
	ov5647_ctrl->my_reg_line_count = (uint16_t)line;


	line = line<<4; 
	// ov5647 need this operation
	intg_time_hsb = (u8)(line>>16);
	intg_time_msb = (u8) ((line & 0xFF00) >> 8);
	intg_time_lsb = (u8) (line& 0x00FF);
	//	CAMDEBUG4("write_exposure_gain:gain=0x%x(MAX==0x7f),line=%d;	preview gain=0x%x,line=%d",gain,line,my_reg_gain,my_reg_line_count);
	ov5647_i2c_write(ov5647_client->addr, \
		REG_OV5647_LINE_HSB, intg_time_hsb, 10);

	ov5647_i2c_write(ov5647_client->addr, \
		REG_OV5647_LINE_MSB, intg_time_msb, 10);
	
	ov5647_i2c_write(ov5647_client->addr, \
		REG_OV5647_LINE_LSB, intg_time_lsb, 10);

	ov5647_i2c_write(ov5647_client->addr, \
		REG_OV5647_GAIN_MSB, (ov5647_ctrl->my_reg_gain& 0x300)>>8, 10);

	ov5647_i2c_write(ov5647_client->addr, \
		REG_OV5647_GAIN_LSB, (u8) ov5647_ctrl->my_reg_gain, 10);
	
	return rc;


}

static int ov5647_probe_init_sensor(const struct msm_camera_sensor_info *data)
{
	u32 device_id=0;
	printk(KERN_ERR "--CAMERA-- %s (Start...)\n",__func__);
	// (1) set Camera PMIC and power on   
	vreg_CAM_gp3 = vreg_get(NULL, "gp3");
	vreg_CAM_gp6 = vreg_get(NULL, "gp6");
	vreg_CAM_wlan = vreg_get(NULL, "wlan");

	// (2) config pwd and rest pin
	printk(KERN_ERR "--CAMERA-- %s : sensor_pwd_pin=%d, sensor_reset_pin=%d\n",__func__,data->sensor_pwd,data->sensor_reset);
	gpio_request(data->sensor_pwd, "ov5647");
	gpio_request(data->sensor_reset, "ov5647");
	gpio_direction_output(data->sensor_pwd, 1);
	gpio_direction_output(data->sensor_reset, 1);

	camera_init_flag=true;
	printk(KERN_ERR "--CAMERA-- %s ok , device id=0x%x\n",__func__,device_id);
	return 0;

		

}

static int ov5647_setting(enum msm_s_reg_update rupdate,enum msm_s_setting rt)
{
	int rc = -EINVAL;
	//u16 num_lperf;
	int len;
	int i = 0;
	printk(KERN_ERR "--CAMERA-- %s (Start...), rupdate=%d \n",__func__,rupdate);

	len = sizeof(preview_ov5647_reg)/sizeof(preview_ov5647_reg[0]);

	typedef struct register_address_value_pair_struct  {
		u16 register_address;
		u8 register_value;
	} register_address_value_pair;
	
	register_address_value_pair ov5647_sunny_init_array[] =  {
		{0x0100, 0x00},   {0x0103, 0x01},   {0x0100, 0x00},   {0x0100, 0x00},
		{0x0100, 0x00},   {0x0100, 0x00},   {0x5000, 0x06},   {0x5003, 0x08},
		{0x5a00, 0x08},   {0x3000, 0xff},   {0x3001, 0xff},   {0x3002, 0xff},
		{0x3a18, 0x01},   {0x3a19, 0xe0},   {0x3c01, 0x80},   {0x3b07, 0x0c},
		{0x3630, 0x2e},   {0x3632, 0xe2},   {0x3633, 0x23},   {0x3634, 0x44}, 
		{0x3620, 0x64},   {0x3621, 0xe0},   {0x3600, 0x37},   {0x3704, 0xa0},
		{0x3703, 0x5a},   {0x3715, 0x78},   {0x3717, 0x01},   {0x3731, 0x02},
		{0x370b, 0x60},   {0x3705, 0x1a},   {0x3f05, 0x02},   {0x3f06, 0x10},
		{0x3f01, 0x0a},   {0x3a08, 0x00},   {0x3a0a, 0x00},   {0x3a0f, 0x58},
		{0x3a10, 0x50},   {0x3a1b, 0x58},   {0x3a1e, 0x50},   {0x3a11, 0x60},
		{0x3a1f, 0x28},   {0x4001, 0x02},   {0x4000, 0x09},   {0x0100, 0x01}, 
		{0x4003, 0x08},   {0x3503, 0x03},   {0x3501, 0x10},   {0x3502, 0x80},
		{0x350a, 0x00},   {0x350b, 0x7f},   {0x5001, 0x01},   {0x5180, 0x08}, 
		{0x5186, 0x04},   {0x5187, 0x00},   {0x5188, 0x04},   {0x5189, 0x00},
		{0x518a, 0x04},   {0x518b, 0x00},   {0x5000, 0x06},  };  
		// 2608x1952 to 1296x972 30fps 
	register_address_value_pair ov5647_sunny_to_preview_array[] =  {
		{0x0100, 0x00},   {0x0103, 0x01},   {0x0100, 0x00},   {0x0100, 0x00},
		{0x0100, 0x00},   {0x0100, 0x00},   {0x3035, 0x11},   {0x3036, 0x46},
		{0x303c, 0x11},   {0x3821, 0x07},   {0x3820, 0x41},   {0x370c, 0x03},
		{0x3612, 0x49},   {0x3618, 0x00},   {0x5000, 0x06},   {0x5003, 0x08},
		{0x5a00, 0x08},   {0x3000, 0xff},   {0x3001, 0xff},   {0x3002, 0xff},
		{0x3a18, 0x01},   {0x3a19, 0xe0},   {0x3c01, 0x80},   {0x3b07, 0x0c},
		{0x380c, 0x07},   {0x380d, 0x60},   {0x380e, 0x03},   {0x380f, 0xd8},
		{0x3814, 0x31},   {0x3815, 0x31},   {0x3708, 0x22},   {0x3709, 0x52}, 
		{0x3815, 0x31},   {0x3808, 0x05},   {0x3809, 0x10},   {0x380a, 0x03}, 
		{0x380b, 0xcc},   {0x3800, 0x00},   {0x3801, 0x08},   {0x3802, 0x00},
		{0x3803, 0x02},   {0x3804, 0x0a},   {0x3805, 0x37},   {0x3806, 0x07}, 
		{0x3807, 0xa1},   {0x3630, 0x2e},   {0x3632, 0xe2},   {0x3633, 0x23},
		{0x3634, 0x44},   {0x3620, 0x64},   {0x3621, 0xe0},   {0x3600, 0x37},
		{0x3704, 0xa0},   {0x3703, 0x5a},   {0x3715, 0x78},   {0x3717, 0x01}, 
		{0x3731, 0x02},   {0x370b, 0x60},   {0x3705, 0x1a},   {0x3f05, 0x02}, 
		{0x3f06, 0x10},   {0x3f01, 0x0a},   {0x3a08, 0x01},   {0x3a09, 0x27}, 
		{0x3a0a, 0x00},   {0x3a0b, 0xf6},   {0x3a0d, 0x04},   {0x3a0e, 0x03}, 
		{0x3a0f, 0x58},   {0x3a10, 0x50},   {0x3a1b, 0x58},   {0x3a1e, 0x50},
		{0x3a11, 0x60},   {0x3a1f, 0x28},   {0x4001, 0x02},   {0x4004, 0x02},
		{0x4000, 0x09},   {0x0100, 0x01},   {0x3503, 0x03},   {0x3501, 0x10}, 
		{0x3502, 0x80},   {0x350a, 0x00},   {0x350b, 0x7f},   {0x5001, 0x01},
		{0x5180, 0x08},   {0x5186, 0x04},   {0x5187, 0x00},   {0x5188, 0x04},
		{0x5189, 0x00},   {0x518a, 0x04},   {0x518b, 0x00},   {0x3011, 0x62}, 
		{0x5000, 0x86},   {0x5800, 0x1e},   {0x5801, 0xf },   {0x5802, 0xc },
		{0x5803, 0xd },   {0x5804, 0xf },   {0x5805, 0x25},   {0x5806, 0xa },
		{0x5807, 0x7 },   {0x5808, 0x4 },   {0x5809, 0x4 },   {0x580a, 0x7 }, 
		{0x580b, 0xb },   {0x580c, 0x7 },   {0x580d, 0x2 },   {0x580e, 0x0 },
		{0x580f, 0x0 },   {0x5810, 0x3 },   {0x5811, 0x9 },   {0x5812, 0x7 }, 
		{0x5813, 0x3 },   {0x5814, 0x0 },   {0x5815, 0x0 },   {0x5816, 0x3 }, 
		{0x5817, 0x9 },   {0x5818, 0xb },   {0x5819, 0x8 },   {0x581a, 0x5 }, 
		{0x581b, 0x5 },   {0x581c, 0x8 },   {0x581d, 0xd },   {0x581e, 0x21}, 
		{0x581f, 0x13},   {0x5820, 0xe },   {0x5821, 0xe },   {0x5822, 0x12}, 
		{0x5823, 0x25},   {0x5824, 0x27},   {0x5825, 0x25},   {0x5826, 0x7 }, 
		{0x5827, 0x25},   {0x5828, 0x45},   {0x5829, 0x47},   {0x582a, 0x43}, 
		{0x582b, 0x41},   {0x582c, 0x21},   {0x582d, 0x45},   {0x582e, 0x25},
		{0x582f, 0x41},   {0x5830, 0x41},   {0x5831, 0x21},   {0x5832, 0x23},
		{0x5833, 0x47},   {0x5834, 0x43},   {0x5835, 0x41},   {0x5836, 0x23},  
		{0x5837, 0x45},   {0x5838, 0x65},   {0x5839, 0x45},   {0x583a, 0x29}, 
		{0x583b, 0x27},   {0x583c, 0x65},   {0x583d, 0xcf},    
	};    // 1296x972 to 2608x1952, 10.5fps 
	register_address_value_pair ov5647_sunny_to_capture_array[] =  {
		{0x3035, 0x11},   {0x3036, 0x46},   {0x303c, 0x11},   {0x3821, 0x06},
		{0x3820, 0x00},   {0x370c, 0x00},   {0x3612, 0x4b},   {0x3618, 0x04}, 
		{0x380c, 0x0a},   {0x380d, 0x8c},   {0x380e, 0x07},   {0x380f, 0xb0}, 
		{0x3814, 0x11},   {0x3815, 0x11},   {0x3708, 0x24},   {0x3709, 0x12},
		{0x3815, 0x11},   {0x3808, 0x0a},   {0x3809, 0x30},   {0x380a, 0x07},
		{0x380b, 0xa0},   {0x3800, 0x00},   {0x3801, 0x04},   {0x3802, 0x00},
		{0x3803, 0x00},   {0x3804, 0x0a},   {0x3805, 0x3b},   {0x3806, 0x07},
		{0x3807, 0xa3},   {0x3a08, 0x00},   {0x3a09, 0x4a},   {0x3a0a, 0x00}, 
		{0x3a0b, 0x3d},   {0x3a0d, 0x20},   {0x3a0e, 0x1a},   {0x4004, 0x04},
	};  

	
	switch (rupdate)	{
		case S_UPDATE_PERIODIC:
			printk(KERN_ERR "--CAMERA-- S_UPDATE_PERIODIC (Start)\n");
			if (rt == S_RES_CAPTURE) {
				printk(KERN_ERR "--CAMERA-- OV5647_RES_CAPTURE (Start)\n");
				len = sizeof (ov5647_sunny_to_capture_array) /sizeof (ov5647_sunny_to_capture_array[0]);
				for(i = 0; i < len; i++){
					rc = ov5647_i2c_write(ov5647_client->addr, \
						ov5647_sunny_to_capture_array[i].register_address, ov5647_sunny_to_capture_array[i].register_value,10);
					udelay(500);
				}
			} else if(rt == S_RES_PREVIEW ) {  
				len = sizeof (ov5647_sunny_to_preview_array) /sizeof (ov5647_sunny_to_preview_array[0]);
				for(i = 0; i < len; i++){
					rc = ov5647_i2c_write(ov5647_client->addr, \
						ov5647_sunny_to_preview_array[i].register_address, ov5647_sunny_to_preview_array[i].register_value,10);
					udelay(500);
				}
			}
			break; /* UPDATE_PERIODIC */
		case S_REG_INIT:
			printk(KERN_ERR "--CAMERA-- S_REG_INIT (Start)\n");
			for(i = 0;i<len;i++)
			{
				rc = ov5647_i2c_write(ov5647_client->addr, \
					preview_ov5647_reg[i][0], preview_ov5647_reg[i][1],10);
				udelay(500);
			}
			ov5647_ctrl->fps_divider = 1 * 0x0400;
			printk(KERN_ERR "--CAMERA-- S_REG_INIT (End)\n");
			break; /* case REG_INIT: */
		default:
			break;
	}
	return rc;
}

static int ov5647_sensor_open_init(const struct msm_camera_sensor_info *data)
{
	int rc = -ENOMEM;
	printk(KERN_ERR "--CAMERA-- %s\n",__func__);

	ov5647_ctrl = kzalloc(sizeof(struct __ov5647_ctrl), GFP_KERNEL);
	if (!ov5647_ctrl)
	{
		printk(KERN_ERR "--CAMERA-- kzalloc ov5647_ctrl error !!\n");
		kfree(ov5647_ctrl);
		return rc;
	}
	ov5647_ctrl->fps_divider = 1 * 0x00000400;
	ov5647_ctrl->pict_fps_divider = 1 * 0x00000400;
	ov5647_ctrl->set_test = S_TEST_OFF;
	ov5647_ctrl->prev_res = S_QTR_SIZE;
	ov5647_ctrl->pict_res = S_FULL_SIZE;
	
	if (data) ov5647_ctrl->sensordata = data;

	/* enable mclk = 50 MHz first */
	msm_camio_clk_rate_set(24000000);
	mdelay(20);

	msm_camio_camif_pad_reg_reset();
	mdelay(20);

//	camera_power_onoff(1);
	gpio_set_value(data->sensor_pwd, 0);
	gpio_set_value(data->sensor_reset, 1);
   	mdelay(5);
   	gpio_set_value(data->sensor_reset, 0);
   	mdelay(5);
   	gpio_set_value(data->sensor_reset, 1);
	mdelay(1);
	
	if (ov5647_ctrl->prev_res == S_QTR_SIZE)
		rc = ov5647_setting(S_REG_INIT, S_RES_PREVIEW);
	else
		rc = ov5647_setting(S_REG_INIT, S_RES_CAPTURE);

	if (rc < 0)
	{
		printk(KERN_ERR "--CAMERA-- %s : ov5647_setting failed. rc = %d\n",__func__,rc);
		kfree(ov5647_ctrl);
		return rc;
	}

	printk(KERN_ERR "--CAMERA--re_init_sensor ok!!\n");
	return rc;
}

static int ov5647_sensor_release(void)
{
	printk(KERN_ERR "--CAMERA--ov5647_sensor_release!!\n");

	mutex_lock(&ov5647_mutex);//	camera_power_onoff(0);
	gpio_set_value(ov5647_ctrl->sensordata->sensor_reset, 1);
	gpio_free(ov5647_ctrl->sensordata->sensor_reset);
	gpio_free(ov5647_ctrl->sensordata->sensor_pwd);
	kfree(ov5647_ctrl);	ov5647_ctrl = NULL;
	mutex_unlock(&ov5647_mutex);
	return 0;
}


			       
static const struct i2c_device_id ov5647_i2c_id[] = {
	{"ov5647", 0},{}
};

static int ov5647_i2c_remove(struct i2c_client *client)
{
   return 0;
}


static int ov5647_init_client(struct i2c_client *client)
{
   /* Initialize the MSM_CAMI2C Chip */
   init_waitqueue_head(&ov5647_wait_queue);
   return 0;
}


static int32_t ov5647_video_config(int mode)
{
	int32_t rc;

	rc = ov5647_setting(S_UPDATE_PERIODIC, S_RES_PREVIEW);
	if (rc < 0)
		return rc;
	CDBG("mt9p012_km sensor configuration done!\n");

	ov5647_ctrl->curr_res = ov5647_ctrl->prev_res;
	ov5647_ctrl->sensormode = mode;

	rc = ov5647_write_exp_gain(ov5647_ctrl->my_reg_gain,
				    ov5647_ctrl->my_reg_line_count);

	/* need reset? */
	//	rc = ov5647_i2c_write_w(mt9p012_km_client->addr,
	//			 MT9P012_KM_REG_RESET_REGISTER,
	//		 0x10cc | 0x0002);

	mdelay(15);
	return rc;
}

static int32_t ov5647_snapshot_config(int mode)
{
	int32_t rc = 0;

	rc = ov5647_setting(S_UPDATE_PERIODIC, S_RES_CAPTURE);
	if (rc < 0)
		return rc;

	ov5647_ctrl->curr_res = ov5647_ctrl->pict_res;

	ov5647_ctrl->sensormode = mode;

	return rc;
}


static int ov5647_raw_snapshot_config(int mode)
{
#if 0
	int rc;
	printk(KERN_ERR "--CAMERA-- %s (Start...)\n",__func__);
	rc = ov5647_setting(S_UPDATE_PERIODIC, S_RES_CAPTURE);
	if (rc < 0)	
		return rc;
	ov5647_ctrl->curr_res = ov5647_ctrl->pict_res;
	ov5647_ctrl->sensormode = mode;
#endif
	printk(KERN_ERR "--CAMERA-- %s (End...)\n",__func__);
	return 0;
}

static void ov5647_get_pict_fps(uint16_t fps, uint16_t *pfps){
	/* input fps is preview fps in Q8 format */
	u32 d1 = (u32)(
	((ov5647_reg_pat[0].frame_length_lines) *	0x400) / 
	(ov5647_reg_pat[1].frame_length_lines ));
	u32 d2 = (u32)(
		((ov5647_reg_pat[0].line_length_pck) *	0x400) / 
		(ov5647_reg_pat[1].line_length_pck));
	u32 divider = (uint32_t) (d1 * d2) / 0x00000400;
	/* Verify PCLK settings and frame sizes. */
	*pfps = (u16)(fps * divider / 0x00000400);
}

static uint16_t ov5647_get_prev_lines_pf(void)
{
	return  ov5647_reg_pat[0].frame_length_lines;
}

static uint16_t ov5647_get_prev_pixels_pl(void)
{
	return  ov5647_reg_pat[0].line_length_pck;
}

static uint16_t ov5647_get_pict_lines_pf(void)
{
	return  ov5647_reg_pat[1].frame_length_lines;
}

static uint16_t ov5647_get_pict_pixels_pl(void)
{
	return  ov5647_reg_pat[1].line_length_pck;
}

static uint32_t ov5647_get_pict_max_exp_lc(void)
{
	uint16_t snapshot_lines_per_frame;

	snapshot_lines_per_frame =
	    ov5647_reg_pat[1].frame_length_lines - 1;
	return snapshot_lines_per_frame * 24;
}


static int ov5647_set_sensor_mode(int mode, int res)
{
	int rc = -EINVAL;
	//int len2;
	int len;
	int len3;
	int i =0;

	printk(KERN_ERR "--CAMERA-- ov5647_set_sensor_mode mode = %d, res = %d\n", mode, res);

	//len2 = sizeof(ov5647_capture_tbl_1)/sizeof(ov5647_capture_tbl_1[0]);

	len3 = sizeof(preview_ov5647_reg)/sizeof(preview_ov5647_reg[0]);

	switch (mode)
	{
		case SENSOR_PREVIEW_MODE:
			printk(KERN_ERR "--CAMERA-- SENSOR_PREVIEW_MODE\n");
			ov5647_video_config(mode);
			//for(i = 0;i<len3;i++)
//			{
				//rc = ov5647_i2c_write(ov5647_client->addr, \
				//	preview_ov5647_reg[i][0], preview_ov5647_reg[i][1],10);
				//udelay(500);
//			}
			break;
		case SENSOR_SNAPSHOT_MODE:
			printk(KERN_ERR "--CAMERA-- SENSOR_SNAPSHOT_MODE\n");
			ov5647_snapshot_config(mode);
			break;
		case SENSOR_RAW_SNAPSHOT_MODE:
			printk(KERN_ERR "--CAMERA-- SENSOR_RAW_SNAPSHOT_MODE\n");
			rc = ov5647_raw_snapshot_config(mode);
			break;
		default:
			printk(KERN_ERR "--CAMERA--ov5647_set_sensor_mode  DEFAULT\n");
			break;
	}
	return 1;
}


static int32_t ov5647_lens_shading_enable(uint8_t is_enable)
{
	int32_t rc = 0;

	CDBG("%s: entered. enable = %d\n", __func__, is_enable);

	rc = ov5647_i2c_write(ov5647_client->addr, \
			0x5000,0xff,10);
	udelay(500);
	
	if (rc < 0)
		return rc;

	CDBG("%s: exiting. rc = %d\n", __func__, rc);
	return rc;
}
static int ov5647_sensor_config(void __user *argp)
{
	struct sensor_cfg_data cdata;
	long  rc = 0;
	printk(KERN_ERR "--CAMERA-- %s (Start...)\n",__func__);
	if (copy_from_user(&cdata,(void *)argp,sizeof(struct sensor_cfg_data))) 
		return -EFAULT;

	printk(KERN_ERR "--CAMERA-- %s %d\n",__func__,cdata.cfgtype);
		
	mutex_lock(&ov5647_mutex);
	switch (cdata.cfgtype)
	{
		case CFG_SET_MODE:   // 0
			rc =ov5647_set_sensor_mode(cdata.mode, cdata.rs);
			break;
		case CFG_SET_EFFECT: // 1
			printk(KERN_ERR "--CAMERA-- CFG_SET_EFFECT (Not Support) !!\n");
			// Not Support
			break;
		case CFG_START:      // 2
			printk(KERN_ERR "--CAMERA-- CFG_START (Not Support) !!\n");
			// Not Support
			break;
		case CFG_PWR_UP:     // 3
			printk(KERN_ERR "--CAMERA-- CFG_PWR_UP (Not Support) !!\n");
			// Not Support
			break;
		case CFG_PWR_DOWN:   // 4
			printk(KERN_ERR "--CAMERA-- CFG_PWR_DOWN (Not Support) \n");
			//camera_power_onoff(0);
			break;
		case CFG_SET_DEFAULT_FOCUS:  // 06
			printk(KERN_ERR "--CAMERA-- CFG_SET_DEFAULT_FOCUS (Not Implement) !!\n");
			break;		
		case CFG_MOVE_FOCUS:     //  07
			printk(KERN_ERR "--CAMERA-- CFG_MOVE_FOCUS (Not Implement) !!\n");
			break;
		case CFG_GET_AF_MAX_STEPS: //26
			printk(KERN_ERR "--CAMERA-- CFG_GET_AF_MAX_STEPS (!!\n");
			cdata.max_steps = 30;
			if (copy_to_user((void *)argp,
				 &cdata, sizeof(struct sensor_cfg_data)))
			rc = -EFAULT;
			break;
		case CFG_SET_LENS_SHADING: //20
			CDBG("%s: CFG_SET_LENS_SHADING\n", __func__);
			rc = ov5647_lens_shading_enable(cdata.cfg.lens_shading);
			break;
		case CFG_GET_PICT_FPS: //21
			ov5647_get_pict_fps(cdata.cfg.gfps.prevfps,
				     &(cdata.cfg.gfps.pictfps));

			if (copy_to_user((void *)argp, &cdata,
				 sizeof(struct sensor_cfg_data)))
			rc = -EFAULT;
		break;
		case CFG_SET_EXP_GAIN: //18
			ov5647_write_exp_gain(cdata.cfg.exp_gain.gain,
					    cdata.cfg.exp_gain.line);
			break;
		case CFG_GET_PICT_MAX_EXP_LC: //27
			cdata.cfg.pict_max_exp_lc = ov5647_get_pict_max_exp_lc();

			if (copy_to_user((void *)argp, &cdata,
				 sizeof(struct sensor_cfg_data)))
			rc = -EFAULT;
		case CFG_GET_PREV_L_PF: //22
			cdata.cfg.prevl_pf = ov5647_get_prev_lines_pf();

			if (copy_to_user((void *)argp,
				 &cdata, sizeof(struct sensor_cfg_data)))
				rc = -EFAULT;
			break;

		case CFG_GET_PREV_P_PL: //23
			cdata.cfg.prevp_pl = ov5647_get_prev_pixels_pl();

			if (copy_to_user((void *)argp,
				 &cdata, sizeof(struct sensor_cfg_data)))
				rc = -EFAULT;
			break;
		case CFG_GET_PICT_L_PF: //24
			cdata.cfg.pictl_pf = ov5647_get_pict_lines_pf();

			if (copy_to_user((void *)argp,
				 &cdata, sizeof(struct sensor_cfg_data)))
				rc = -EFAULT;
			break;

		case CFG_GET_PICT_P_PL: //25
			cdata.cfg.pictp_pl = ov5647_get_pict_pixels_pl();

			if (copy_to_user((void *)argp,
				 &cdata, sizeof(struct sensor_cfg_data)))
				rc = -EFAULT;
			break;
		default:
			printk(KERN_ERR "--CAMERA-- %s: Command=%d (Not Implement)!!\n",__func__,cdata.cfgtype);
			if (cdata.cfgtype >= CFG_MAX)
				rc = -EINVAL;
			else 
				rc = 0;
		break;	
	}
	mutex_unlock(&ov5647_mutex);
	return rc;	
}

static struct i2c_driver ov5647_i2c_driver = {
	.id_table = ov5647_i2c_id,
	.probe  = ov5647_i2c_probe,
	.remove = ov5647_i2c_remove,
	.driver = {
		.name = "ov5647",
	},
};


static int ov5647_sensor_probe(const struct msm_camera_sensor_info *info,struct msm_sensor_ctrl *s)
{
	int rc = -ENOTSUPP;
  //camera_init_flag = false;
  printk(KERN_ERR "--CAMERA-- %s (Start...)\n",__func__);
  rc = i2c_add_driver(&ov5647_i2c_driver);
  if ((rc < 0 ) || (ov5647_client == NULL))
  {
  	printk(KERN_ERR "--CAMERA-- i2c_add_driver FAILS!!\n");
   	return rc;
  }

  msm_camio_clk_rate_set(OV5647_DEFAULT_CLOCK_RATE);
  mdelay(20);

  rc = ov5647_probe_init_sensor(info);
  if (rc < 0)
  {
  	printk(KERN_ERR "--CAMERA--ov5647_probe_init_sensor Fail !!~~~~!!\n");
  	return rc;
  }
  s->s_init = ov5647_sensor_open_init;
  s->s_release = ov5647_sensor_release;
  s->s_config  = ov5647_sensor_config;
  
  //camera_init_flag = true;
  printk(KERN_ERR "--CAMERA-- %s (End...)\n",__func__);
  return rc;
}

static int ov5647_i2c_probe(struct i2c_client *client,const struct i2c_device_id *id)
{
   printk(KERN_ERR "--CAMERA-- %s ... (Start...)\n",__func__);
   if (!i2c_check_functionality(client->adapter, I2C_FUNC_I2C))
   {
      printk(KERN_ERR "--CAMERA--i2c_check_functionality failed\n");
      return -ENOMEM;
   }
   
   ov5647_sensorw = kzalloc(sizeof(struct ov5647_work), GFP_KERNEL);
   if (!ov5647_sensorw)
   {
      printk(KERN_ERR "--CAMERA--kzalloc failed\n");
      return -ENOMEM;
   }
   i2c_set_clientdata(client, ov5647_sensorw);
   ov5647_init_client(client);
   ov5647_client = client;
   printk("--CAMERA-- %s ... (End...)\n",__func__);
   return 0;
}

static int __ov5647_probe(struct platform_device *pdev)
{
   return msm_camera_drv_start(pdev, ov5647_sensor_probe);
}

static struct platform_driver msm_camera_driver = {
  .probe = __ov5647_probe,
	.driver = {
		.name = "msm_camera_ov5647",
		.owner = THIS_MODULE,
		},
};

static int __init ov5647_init(void)
{
	//memset(ov5647_i2c_buf,0,sizeof(ov5647_i2c_buf));
	ov5647_i2c_buf[0]=0x5A;
	return platform_driver_register(&msm_camera_driver);
}

module_init(ov5647_init);
