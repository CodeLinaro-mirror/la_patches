/* Copyright (c) 2008-2009, Code Aurora Forum. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of Code Aurora Forum nor
 *       the names of its contributors may be used to endorse or promote
 *       products derived from this software without specific prior written
 *       permission.
 *
 * Alternatively, provided that this notice is retained in full, this software
 * may be relicensed by the recipient under the terms of the GNU General Public
 * License version 2 ("GPL") and only version 2, in which case the provisions of
 * the GPL apply INSTEAD OF those given above.  If the recipient relicenses the
 * software under the GPL, then the identification text in the MODULE_LICENSE
 * macro must be changed to reflect "GPLv2" instead of "Dual BSD/GPL".  Once a
 * recipient changes the license terms to the GPL, subsequent recipients shall
 * not relicense under alternate licensing terms, including the BSD or dual
 * BSD/GPL terms.  In addition, the following license statement immediately
 * below and between the words START and END shall also then apply when this
 * software is relicensed under the GPL:
 *
 * START
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 2 and only version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
 * END
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include <linux/delay.h>
#include <linux/types.h>
#include <linux/i2c.h>
#include <linux/uaccess.h>
#include <linux/miscdevice.h>
#include <media/msm_camera.h>
#include <mach/gpio.h>
#include <mach/camera.h>
#include "vx6953.h"

/*=============================================================
	SENSOR REGISTER DEFINES
==============================================================*/
  
	#define REG_GROUPED_PARAMETER_HOLD        0x0104
    #define GROUPED_PARAMETER_HOLD_OFF        0x00
    #define GROUPED_PARAMETER_HOLD            0x01

    #define REG_MODE_SELECT                   0x0100
    #define MODE_SELECT_STANDBY_MODE          0x00
    #define MODE_SELECT_STREAM                0x01

   /* Integration Time */
    #define REG_COARSE_INTEGRATION_TIME_HI   0x0202   
    #define REG_COARSE_INTEGRATION_TIME_LO   0x0203   

    /* Gain */
    #define REG_ANALOGUE_GAIN_CODE_GLOBAL_HI 0x0204
    #define REG_ANALOGUE_GAIN_CODE_GLOBAL_LO 0x0205

    /* Digital Gain */
    #define REG_DIGITAL_GAIN_GREEN_R_HI     0x020E
    #define REG_DIGITAL_GAIN_GREEN_R_LO     0x020F
    #define REG_DIGITAL_GAIN_RED_HI         0x0210
    #define REG_DIGITAL_GAIN_RED_LO         0x0211
    #define REG_DIGITAL_GAIN_BLUE_HI        0x0212
    #define REG_DIGITAL_GAIN_BLUE_LO        0x0213
    #define REG_DIGITAL_GAIN_GREEN_B_HI     0x0214
    #define REG_DIGITAL_GAIN_GREEN_B_LO     0x0215

    /* output bits setting */
    #define REG_0x0112                      0x0112    
    #define REG_0x0113                      0x0113

    /* PLL registers */
    #define REG_VT_PIX_CLK_DIV              0x0301
    #define REG_PRE_PLL_CLK_DIV              0x0305
    #define REG_PLL_MULTIPLIER              0x0307
    #define REG_OP_PIX_CLK_DIV              0x0309

    #define REG_0x034c                      0x034c
    #define REG_0x034d                      0x034d
    #define REG_0x034e                      0x034e
    #define REG_0x034f                      0x034f

    #define REG_0x0387                      0x0387
    #define REG_0x0383                      0x0383

    #define REG_FRAME_LENGTH_LINES_HI       0x0340
    #define REG_FRAME_LENGTH_LINES_LO       0x0341
    #define REG_LINE_LENGTH_PCK_HI          0x0342
    #define REG_LINE_LENGTH_PCK_LO          0x0343

    #define REG_0x3030                      0x3030
                                                  
    #define REG_0x0111                      0x0111
    #define REG_0x0b00                      0x0b00
    #define REG_0x3001                      0x3001
    #define REG_0x3004                      0x3004
    #define REG_0x3007                      0x3007
    #define REG_0x301a                      0x301a
    #define REG_0x3101                      0x3101
                                                  
    #define REG_0x3364                      0x3364
    #define REG_0x3365                      0x3365
                                                  
    #define REG_0x0b83                      0x0b83
    #define REG_0x0b84                      0x0b84
    #define REG_0x0b8a                      0x0b8a

    #define REG_0x3005                      0x3005
    #define REG_0x3036                      0x3036

    #define REG_0x0b80                      0x0b80
                                            
    #define REG_0x0900                      0x0900
    #define REG_0x0901                      0x0901
    #define REG_0x0902                      0x0902
                                            
    #define REG_0x3016                      0x3016
    #define REG_0x303a                      0x303a
                                                  
    #define REG_0x1716                      0x1716
    #define REG_0x1717                      0x1717
    #define REG_0x1718                      0x1718
    #define REG_0x1719                      0x1719

    #define REG_0x3011                      0x3011
    #define REG_0x3035                      0x3035
    #define REG_0x3045                      0x3045
    
    /* Test Pattern */   
    #define REG_TEST_PATTERN_MODE           0x0601

reg_struct_init vx6953_reg_init =
{
   10,   //REG = 0x0112 /* 10 bit */
   10,   //REG = 0x0113
       
   9,    //REG = 0x0301 vt_pix_clk_div
   4,    //REG = 0x0305 pre_pll_clk_div
   133,  //REG = 0x0307 pll_multiplier
   10,   //REG = 0x0309 op_pix_clk_div

   0x01, //REG = 0x3030
                       
   0x02, //REG = 0x0111
   0x00, //REG = 0x0b00 /* lens shading off */   
   0x30, //REG = 0x3001
   0x34, //REG = 0x3004
   0x0b, //REG = 0x3007
   0x51, //REG = 0x301a
   0x01, //REG = 0x3101 
                       
   0x01, //REG = 0x3364
   0x86, //REG = 0x3365
                       
   0x40, //REG = 0x0b83
   0x40, //REG = 0x0b84
   0x01, //REG = 0x0b8a       
};


/* Preview / Snapshot register settings */
reg_struct vx6953_reg_pat[2] = 
{
  { /* Preview */
   0x03, //REG = 0x0202 coarse_integration_time_hi
   0xd0, //REG = 0x0203 coarse_integration_time_lo
   0xc0, //REG = 0x0205 analogue_gain_code_global     
         
   0x03, //REG = 0x0340 frame_length_lines_hi
   0xf0, //REG = 0x0341 frame_length_lines_lo
   0x0b, //REG = 0x0342  line_length_pck_hi   
   0x74, //REG = 0x0343  line_length_pck_lo     
         
   0x01, //REG = 0x3005
   0x31, //REG = 0x3036
   0x00, //0x02, //REG = 0x0b80
                         
   0x01, //REG = 0x0900
   0x22, //REG = 0x0901
   0x05, //REG = 0x0902
   0x03, //REG = 0x0383
   0x03, //REG = 0x0387   
                       
   0x05, //REG = 0x034c
   0x18, //REG = 0x034d
   0x03, //REG = 0x034e
   0xd4, //REG = 0x034f  
                       
   0x10, //REG = 0x3016
   0x03, //REG = 0x303a
   0x02, //REG = 0x1716
   0x04, //REG = 0x1717
   0x08, //REG = 0x1718
   0x2c, //REG = 0x1719
   0x01, //REG = 0x3011
   0x03, //REG = 0x3035
   0xb1, //REG = 0x3045

  },
  { /* Snapshot */             
   0x07, //REG = 0x0202 coarse_integration_time_hi
   0x00, //REG = 0x0203 coarse_integration_time_lo
   0xc0, //REG = 0x0205 analogue_gain_code_global 

   0x07, //REG = 0x0340 frame_length_lines_hi
   0xd0, //REG = 0x0341 frame_length_lines_lo
   0x0b, //REG = 0x0342 line_length_pck_hi   
   0x8c, //REG = 0x0343 line_length_pck_lo  
         
   0x05, //REG = 0x3005
   0x33, //REG = 0x3036
   0x00, //0x01, //REG = 0x0b80
                       
   0x00, //REG = 0x0900
   0x00, //REG = 0x0901
   0x00, //REG = 0x0902
   0x01, //REG = 0x0383
   0x01, //REG = 0x0387
                       
   0x0A, //REG = 0x034c
   0x30, //REG = 0x034d
   0x07, //REG = 0x034e
   0xA8, //REG = 0x034f
                       
   0x00, //REG = 0x3016
   0x01, //REG = 0x303a
   0x04, //REG = 0x1716
   0x10, //REG = 0x1717
   0x06, //REG = 0x1718
   0xAE, //REG = 0x1719
   0x00,    //REG = 0x3011
   0x01, //REG = 0x3035
   0xb7, //REG = 0x3045
  }
};

/*============================================================================
                             TYPE DECLARATIONS
============================================================================*/

/* 16bit address - 8 bit context register structure */

	#define VX6953_STM5M0EDOF_OFFSET  9         

    #define Q8    0x00000100

    static uint8_t vx6953_stm5m0edof_delay_msecs_stdby = 0;
    static uint8_t vx6953_stm5m0edof_delay_msecs_stream = 11;

    #define VX6953_STM5M0EDOF_MAX_SNAPSHOT_EXPOSURE_LINE_COUNT 2922

    #define VX6953_STM5M0EDOF_DEFAULT_MASTER_CLK_RATE 24000000
    #define VX6953_STM5M0EDOF_OP_PIXEL_CLOCK_RATE     79800000
    #define VX6953_STM5M0EDOF_VT_PIXEL_CLOCK_RATE     88670000
     
    /* Full Size */
    #define VX6953_FULL_SIZE_WIDTH     2608
    #define VX6953_FULL_SIZE_HEIGHT    1960
    #define VX6953_FULL_SIZE_DUMMY_PIXELS 1
    #define VX6953_FULL_SIZE_DUMMY_LINES  0//2
     
    /* Quarter Size */
    #define VX6953_QTR_SIZE_WIDTH      1304
    #define VX6953_QTR_SIZE_HEIGHT      980
    #define VX6953_QTR_SIZE_DUMMY_PIXELS 1
    #define VX6953_QTR_SIZE_DUMMY_LINES   0
    
    /* Blanking as measured on the scope */
    /* Full Size */
    #define VX6953_HRZ_FULL_BLK_PIXELS   348
    #define VX6953_VER_FULL_BLK_LINES     40
     
    /* Quarter Size */
    #define VX6953_HRZ_QTR_BLK_PIXELS   1628
    #define VX6953_VER_QTR_BLK_LINES      28

    #define MAX_LINE_LENGTH_PCK 8190

    #define VX6953_REVISION_NUMBER 0x10  // revision number for Cut2.0

/* FIXME: Changes from here */
struct vx6953_work_t {
	struct work_struct work;
};

static struct  vx6953_work_t *vx6953_sensorw;
static struct  i2c_client *vx6953_client;

struct vx6953_ctrl_t {
	const struct  msm_camera_sensor_info *sensordata;

	uint32_t sensormode;
	uint32_t fps_divider; 		/* init to 1 * 0x00000400 */
	uint32_t pict_fps_divider; 	/* init to 1 * 0x00000400 */
	uint16_t fps;
	
	int16_t  curr_lens_pos;
    uint16_t curr_step_pos;
	uint16_t my_reg_gain;
	uint32_t my_reg_line_count;
	uint16_t total_lines_per_frame;

	enum vx6953_resolution_t prev_res;
	enum vx6953_resolution_t pict_res;
	enum vx6953_resolution_t curr_res;
	enum vx6953_test_mode_t  set_test;
    enum sensor_revision_t sensor_type;

	unsigned short imgaddr;
};

/*static uint16_t use_sensor_digital_gain = 1; 
static uint16_t my_reg_gain = 0;
static uint32_t my_reg_line_count = 0;*/

static struct vx6953_ctrl_t *vx6953_ctrl;
static DECLARE_WAIT_QUEUE_HEAD(vx6953_wait_queue);
DECLARE_MUTEX(vx6953_sem);

/*=============================================================*/

static int vx6953_i2c_rxdata(unsigned short saddr,
	unsigned char *rxdata, int length)
{
	struct i2c_msg msgs[] = {
	{
		.addr   = saddr,
		.flags = 0,
		.len   = 2,
		.buf   = rxdata,
	},
	{
		.addr  = saddr,
		.flags = I2C_M_RD,
		.len   = 2,
		.buf   = rxdata,
	},
	};

	if (i2c_transfer(vx6953_client->adapter, msgs, 2) < 0) {
		CDBG("vx6953_i2c_rxdata failed!\n");
		return -EIO;
	}

	return 0;
}
static int32_t vx6953_i2c_txdata(unsigned short saddr,
				 unsigned char *txdata, int length)
{
	struct i2c_msg msg[] = {
		{
		 .addr = saddr,
		 .flags = 0,
		 .len = length,
		 .buf = txdata,
		 },
	};

	if (i2c_transfer(vx6953_client->adapter, msg, 1) < 0) {
		CDBG("vx6953_i2c_txdata faild 0x%x\n", vx6953_client->addr);
		return -EIO;
	}

	return 0;
}


static int32_t vx6953_i2c_read(unsigned short raddr,
				   unsigned short *rdata, int rlen)
{
	int32_t rc = 0;
	unsigned char buf[2];
	
	if (!rdata)
		return -EIO;
	
	memset(buf, 0, sizeof(buf));
	
	buf[0] = (raddr & 0xFF00) >> 8;
	buf[1] = (raddr & 0x00FF);
	
	rc = vx6953_i2c_rxdata(vx6953_client->addr>>1, buf, rlen);
	
	if (rc < 0) {
		CDBG("vx6953_i2c_read 0x%x failed!\n", raddr);
		return rc;
	}
	
	*rdata = (rlen == 2 ? buf[0] << 8 | buf[1] : buf[0]);
	
	return rc;

}


static int32_t vx6953_i2c_write_b_sensor(unsigned short waddr, uint8_t bdata)
{
	int32_t rc = -EFAULT;
	unsigned char buf[3];
    /* read test */
    unsigned short read_data;

	memset(buf, 0, sizeof(buf));
	buf[0] = (waddr & 0xFF00) >> 8;
	buf[1] = (waddr & 0x00FF);
	buf[2] = bdata;

	CDBG("i2c_write_b addr = 0x%x, val = 0x%x\n", waddr, bdata);
	rc = vx6953_i2c_txdata(vx6953_client->addr>>1, buf, 3);

	if (rc < 0) {
		CDBG("i2c_write_b failed, addr = 0x%x, val = 0x%x!\n",
			 waddr, bdata);
	}
    mdelay(1);
    //udelay(500);
    /* read test */
    rc = vx6953_i2c_read(waddr, &read_data, 1);
    CDBG("vx6953_i2c_write_b_sensor read addr = 0x%x, val = 0x%x!\n",
			 waddr, read_data);
    
    mdelay(1);
	return rc;
}

static int32_t vx6953_i2c_write_w_table(vx6953_i2c_reg_conf const
					 *reg_conf_tbl, int num)
{
	int i;
	int32_t rc = -EIO;

	for (i = 0; i < num; i++) {
		rc = vx6953_i2c_write_b_sensor(reg_conf_tbl->waddr,
					 reg_conf_tbl->wdata);
		if (rc < 0)
			break;
		reg_conf_tbl++;
	}

	return rc;
}

static void vx6953_get_pict_fps(uint16_t fps, uint16_t *pfps)
{
	/* input fps is preview fps in Q8 format */
  uint16_t preview_frame_length_lines, snapshot_frame_length_lines;
  uint16_t preview_line_length_pck, snapshot_line_length_pck;
  uint32_t divider, d1,d2;
//todo
  /* Total frame_length_lines and line_length_pck for preview */
  preview_frame_length_lines = VX6953_QTR_SIZE_HEIGHT + VX6953_VER_QTR_BLK_LINES;
  preview_line_length_pck = VX6953_QTR_SIZE_WIDTH + VX6953_HRZ_QTR_BLK_PIXELS;  

  /* Total frame_length_lines and line_length_pck for snapshot */
  snapshot_frame_length_lines = VX6953_FULL_SIZE_HEIGHT + VX6953_HRZ_FULL_BLK_PIXELS;
  snapshot_line_length_pck = VX6953_FULL_SIZE_WIDTH + VX6953_HRZ_FULL_BLK_PIXELS;
 d1 = preview_frame_length_lines * 0x00000400/snapshot_frame_length_lines; 
 d2 = preview_line_length_pck *  0x00000400/snapshot_line_length_pck;
 divider = d1*d2/0x400;

  //Verify PCLK settings and frame sizes.
  *pfps = (uint16_t) (fps * divider /0x400);
                    /* 2 is the ratio of no.of snapshot channels to number of preview channels */




 
}/*endof vx6953_get_pict_fps*/

static uint16_t vx6953_get_prev_lines_pf(void)
{
  if (vx6953_ctrl->prev_res == QTR_SIZE) {
	  return (VX6953_QTR_SIZE_HEIGHT + VX6953_VER_QTR_BLK_LINES);
  } else  {
	  return (VX6953_FULL_SIZE_HEIGHT + VX6953_VER_FULL_BLK_LINES);
  }
}

static uint16_t vx6953_get_prev_pixels_pl(void)
{
  if (vx6953_ctrl->prev_res == QTR_SIZE) {
	  return (VX6953_QTR_SIZE_WIDTH + VX6953_HRZ_QTR_BLK_PIXELS);
  } else  {
	  return (VX6953_FULL_SIZE_WIDTH + VX6953_HRZ_FULL_BLK_PIXELS);
  }
}

static uint16_t vx6953_get_pict_lines_pf(void)
{
  if (vx6953_ctrl->pict_res == QTR_SIZE) {
	  return (VX6953_QTR_SIZE_HEIGHT + VX6953_VER_QTR_BLK_LINES);
  } else  {
  
	  return (VX6953_FULL_SIZE_HEIGHT + VX6953_VER_FULL_BLK_LINES);
  }
}

static uint16_t vx6953_get_pict_pixels_pl(void)
{
  if (vx6953_ctrl->pict_res == QTR_SIZE) {
	  return (VX6953_QTR_SIZE_WIDTH + VX6953_HRZ_QTR_BLK_PIXELS);
  } else  {
	  return (VX6953_FULL_SIZE_WIDTH + VX6953_HRZ_FULL_BLK_PIXELS);
  }
}

static uint32_t vx6953_get_pict_max_exp_lc(void)
{
	if (vx6953_ctrl->pict_res == QTR_SIZE) {
		return (VX6953_QTR_SIZE_HEIGHT + VX6953_VER_QTR_BLK_LINES);
	} else  {
		return (VX6953_FULL_SIZE_HEIGHT + VX6953_VER_FULL_BLK_LINES);
	}
}

static int32_t vx6953_set_fps(struct fps_cfg	*fps)
{
    uint16_t total_lines_per_frame;
    int32_t rc = 0;
    //vx6953_ctrl->fps_divider =  fps->fps_divider;
   // fps_divider = 1;

    total_lines_per_frame = (uint16_t)((VX6953_QTR_SIZE_HEIGHT + VX6953_VER_QTR_BLK_LINES) * vx6953_ctrl->fps_divider/0x400);

    if (vx6953_i2c_write_b_sensor(REG_FRAME_LENGTH_LINES_HI, ((total_lines_per_frame & 0xFF00) >> 8)) < 0)
        return rc;

    if (vx6953_i2c_write_b_sensor(REG_FRAME_LENGTH_LINES_LO, (total_lines_per_frame & 0x00FF)) < 0)
        return rc;


    return rc;
	
}

static int32_t vx6953_write_exp_gain(uint16_t gain, uint32_t line)
{
  static uint16_t max_legal_gain  = 0x00E0; 
  uint16_t line_length_pck, frame_length_lines;
  uint8_t gain_hi, gain_lo;
  uint8_t intg_time_hi, intg_time_lo;
  uint8_t line_length_pck_hi = 0, line_length_pck_lo = 0;
  uint16_t line_length_ratio = 1 * Q8;
  int32_t rc = 0;
  
  if (vx6953_ctrl->sensormode != SENSOR_SNAPSHOT_MODE)
  {       
     
    frame_length_lines = VX6953_QTR_SIZE_HEIGHT + VX6953_VER_QTR_BLK_LINES;
    line_length_pck = VX6953_QTR_SIZE_WIDTH + VX6953_HRZ_QTR_BLK_PIXELS;

    if( line > (frame_length_lines - VX6953_STM5M0EDOF_OFFSET))
    {
        vx6953_ctrl->fps = (uint16_t) (30 * Q8 * (frame_length_lines - VX6953_STM5M0EDOF_OFFSET)/ line);
    }    
    else
    {
        vx6953_ctrl->fps = (uint16_t) (30 * Q8);
    }

  }
  else
  {
    frame_length_lines = VX6953_FULL_SIZE_HEIGHT + VX6953_VER_FULL_BLK_LINES;
    line_length_pck = VX6953_FULL_SIZE_WIDTH + VX6953_HRZ_FULL_BLK_PIXELS;
  }

  /* calculate line_length_ratio */
  if ((frame_length_lines - VX6953_STM5M0EDOF_OFFSET) < line)
  {
    line_length_ratio =(line*Q8) / (frame_length_lines - VX6953_STM5M0EDOF_OFFSET);
    line = frame_length_lines - VX6953_STM5M0EDOF_OFFSET;
  }
  else
  {
    line_length_ratio = 1*Q8;
  }

  vx6953_i2c_write_b_sensor(REG_GROUPED_PARAMETER_HOLD, GROUPED_PARAMETER_HOLD);


    line_length_pck = (line_length_pck > MAX_LINE_LENGTH_PCK) ? MAX_LINE_LENGTH_PCK : line_length_pck; 
    line_length_pck = (uint16_t) (line_length_pck * line_length_ratio/Q8);
    line_length_pck_hi = (uint8_t) ((line_length_pck & 0xFF00) >> 8);
    line_length_pck_lo = (uint8_t) (line_length_pck & 0x00FF);

  vx6953_i2c_write_b_sensor(REG_LINE_LENGTH_PCK_HI, line_length_pck_hi);
  vx6953_i2c_write_b_sensor(REG_LINE_LENGTH_PCK_LO, line_length_pck_lo);

  if (gain > max_legal_gain)
  {
    /* range: 0 to 224 */ 
    gain = max_legal_gain;
  }

  /* update analogue gain registers */
  gain_hi = (uint8_t) ((gain & 0xFF00) >> 8);
  gain_lo = (uint8_t) (gain & 0x00FF);

  vx6953_i2c_write_b_sensor(REG_ANALOGUE_GAIN_CODE_GLOBAL_HI, gain_hi);
  vx6953_i2c_write_b_sensor(REG_ANALOGUE_GAIN_CODE_GLOBAL_LO, gain_lo);

  /* update line count registers */
  intg_time_hi = (uint8_t) (((uint16_t)line & 0xFF00) >> 8);
  intg_time_lo = (uint8_t) ((uint16_t)line & 0x00FF);
  vx6953_i2c_write_b_sensor(REG_COARSE_INTEGRATION_TIME_HI, intg_time_hi);
  vx6953_i2c_write_b_sensor(REG_COARSE_INTEGRATION_TIME_LO, intg_time_lo);
  vx6953_i2c_write_b_sensor(REG_GROUPED_PARAMETER_HOLD, GROUPED_PARAMETER_HOLD_OFF);

  return rc;
}

static int32_t vx6953_set_pict_exp_gain(uint16_t gain, uint32_t line)
{
	int32_t rc = 0;
	rc = vx6953_write_exp_gain(gain, line);
	return rc;
}/* endof vx6953_set_pict_exp_gain*/


static int32_t vx6953_move_focus( int direction,
	int32_t num_steps)
{
  return 0;
}


static int32_t vx6953_set_default_focus(uint8_t af_step)
{
  return 0;
}

static int32_t vx6953_test(enum vx6953_test_mode_t mo)
{
  int32_t rc = 0;

  if (mo == TEST_OFF)
  {
    return rc;
  }
  else
  {
    /* REG_0x30D8[4] is TESBYPEN: 0: Normal Operation, 1: Bypass Signal Processing  
       REG_0x30D8[5] is EBDMASK: 0: Output Embedded data, 1: No output embedded data */

    if (vx6953_i2c_write_b_sensor(REG_TEST_PATTERN_MODE, (uint8_t) mo) < 0)
    {
      return rc;
    }

  }
  return rc;
}

static int32_t vx6953_sensor_setting(int update_type,int rt)
{

    int32_t rc = 0;
    unsigned short frame_cnt;

    CDBG("%s,%d %d \n",__func__,__LINE__, rt);
  switch (update_type)
  {
    case REG_INIT:

        if (rt == RES_PREVIEW || rt == RES_CAPTURE)
        {
    
            vx6953_i2c_reg_conf init_tbl[] = {
				{REG_0x0112,
				 vx6953_reg_init.reg_0x0112},
				{REG_0x0113,
				 vx6953_reg_init.reg_0x0113},
				{REG_VT_PIX_CLK_DIV,
				 vx6953_reg_init.vt_pix_clk_div},
				{REG_PRE_PLL_CLK_DIV,
				 vx6953_reg_init.pre_pll_clk_div},
				{REG_PLL_MULTIPLIER,
				 vx6953_reg_init.pll_multiplier},
				{REG_OP_PIX_CLK_DIV,
				 vx6953_reg_init.op_pix_clk_div},
                {REG_COARSE_INTEGRATION_TIME_HI,
                 vx6953_reg_pat[rt].coarse_integration_time_hi},
                {REG_COARSE_INTEGRATION_TIME_LO, 
                    vx6953_reg_pat[rt].coarse_integration_time_lo}, 
                {REG_ANALOGUE_GAIN_CODE_GLOBAL_LO, 
                    vx6953_reg_pat[rt].analogue_gain_code_global},
                {REG_0x3030, 
                    vx6953_reg_init.reg_0x3030},
                 /* 953 specific registers */
                {REG_0x0111, 
                    vx6953_reg_init.reg_0x0111},
                {REG_0x3001, 
                    vx6953_reg_init.reg_0x3001},                                                       
                {REG_0x3004, 
                    vx6953_reg_init.reg_0x3004},   
                {REG_0x3007, 
                    vx6953_reg_init.reg_0x3007},
                /* Cut 2.0 specific registers */
                {0x301d, 0x03},                                                                  
                {0x3400, 0x38},
                /* Turn On lens shading since NVM data is programmed */
                {REG_0x0b00, 0x01},   
                /* 953 Cut 2.0 settings for analogue binning */
                {REG_0x3016, 0x1F},  
                {0x3010, 0x00},            
                {0x301a, 0x55},            
                {0x3036, 0x23},  
                {0x3041, 0x00},            

                /* DEFCOR settings */
                {0x0b06, 0x00},  //Single Defect Correction Weight DISABLE
                {0x0b07, 0x80},  //Single_defect_correct_weight = auto
                {0x0b08, 0x01},  //Dynamic couplet correction ENABLED
                {0x0b09, 0x4F},  //Dynamic couplet correction weight

                /* Clock Setup */
                {0x0136, 0x18},  // Tell sensor ext clk is 24MHz 
                {0x0137, 0x00},  
                /* The white balance gains must be written to the sensor every frame. */

                /* Edof */
                {REG_0x0b83, 0x20},  
                {REG_0x0b84, 0x20},  
                {0x0b85, 0x20},  
                {0x0b88, 0x80},  
                {0x0b89, 0x00},            
                {REG_0x0b8a, 0x00}, 

                {0x317E, 0x11}, // IQ av_r2_shift         
                {0x317F, 0x09}, // IQ av_slant_shift  
                {0x3042, 0x24}, // Hicurr mode    (Default setting)
                {REG_0x3011, vx6953_reg_pat[rt].reg_0x3011},
                {REG_0x3035, vx6953_reg_pat[rt].reg_0x3035},
                {REG_0x3045, vx6953_reg_pat[rt].reg_0x3045},
                {0x3005, 0x1},
                 
            {REG_0x0900, vx6953_reg_pat[rt].reg_0x0900},  
            {REG_0x0901, vx6953_reg_pat[rt].reg_0x0901},  
            {REG_0x0902, vx6953_reg_pat[rt].reg_0x0902},  
            {REG_0x0383, vx6953_reg_pat[rt].reg_0x0383},  
            {REG_0x0387, vx6953_reg_pat[rt].reg_0x0387},  
            /* Mode specific regieters */      
            {REG_FRAME_LENGTH_LINES_HI, vx6953_reg_pat[rt].frame_length_lines_hi},   
            {REG_FRAME_LENGTH_LINES_LO, vx6953_reg_pat[rt].frame_length_lines_lo},   
            {REG_LINE_LENGTH_PCK_HI, vx6953_reg_pat[rt].line_length_pck_hi},   
            {REG_LINE_LENGTH_PCK_LO, vx6953_reg_pat[rt].line_length_pck_lo},

            /* Change output size / frame rate */                   
            {REG_0x034c, vx6953_reg_pat[rt].reg_0x034c},  
            {REG_0x034d, vx6953_reg_pat[rt].reg_0x034d},  
            {REG_0x034e, vx6953_reg_pat[rt].reg_0x034e},  
            {REG_0x034f, vx6953_reg_pat[rt].reg_0x034f},
            /*EDOF: Estimation settings for Preview mode
           Application settings for capture mode  (standard settings - Not tuned) */
            {REG_0x0b80, vx6953_reg_pat[rt].reg_0x0b80},  
			};

            /* reset fps_divider */
            vx6953_ctrl->fps = 30 * Q8;

            /* stop streaming */
            if(vx6953_i2c_write_b_sensor( REG_MODE_SELECT, MODE_SELECT_STANDBY_MODE )< 0){return rc;}
            mdelay(vx6953_stm5m0edof_delay_msecs_stream);
            
            rc = vx6953_i2c_write_w_table(&init_tbl[0],
                               ARRAY_SIZE(init_tbl));

            if (rc < 0)
                return rc;

            /* Start sensor streaming */
            if(vx6953_i2c_write_b_sensor( REG_MODE_SELECT, MODE_SELECT_STREAM )< 0){return rc;}
            mdelay(vx6953_stm5m0edof_delay_msecs_stream);

            if (vx6953_i2c_read (0x0005, &frame_cnt,1) < 0) return rc;

            while(frame_cnt == 0xFF)
            {
               if (vx6953_i2c_read (0x0005, &frame_cnt,1) < 0) return rc;
               CDBG("frame_cnt=%d", frame_cnt);
            }
        }
        return rc;
    case UPDATE_PERIODIC:

        if (rt == RES_PREVIEW || rt == RES_CAPTURE)
        {
         vx6953_i2c_reg_conf mode_tbl[] = {
             {REG_VT_PIX_CLK_DIV,
				 vx6953_reg_init.vt_pix_clk_div},
             {REG_PRE_PLL_CLK_DIV,
                 vx6953_reg_init.pre_pll_clk_div},
             {REG_PLL_MULTIPLIER,
				 vx6953_reg_init.pll_multiplier},
             {REG_OP_PIX_CLK_DIV,
				 vx6953_reg_init.op_pix_clk_div},
            {REG_COARSE_INTEGRATION_TIME_HI,
             vx6953_reg_pat[rt].coarse_integration_time_hi},
            {REG_COARSE_INTEGRATION_TIME_LO, 
                vx6953_reg_pat[rt].coarse_integration_time_lo}, 
            {REG_ANALOGUE_GAIN_CODE_GLOBAL_LO, 
                vx6953_reg_pat[rt].analogue_gain_code_global},
            {REG_0x3011, vx6953_reg_pat[rt].reg_0x3011},
            {REG_0x3035, vx6953_reg_pat[rt].reg_0x3035},
            {REG_0x3045, vx6953_reg_pat[rt].reg_0x3045},     

            {REG_0x0900, vx6953_reg_pat[rt].reg_0x0900},  
            {REG_0x0901, vx6953_reg_pat[rt].reg_0x0901},  
            {REG_0x0902, vx6953_reg_pat[rt].reg_0x0902},  
            {REG_0x0383, vx6953_reg_pat[rt].reg_0x0383},  
            {REG_0x0387, vx6953_reg_pat[rt].reg_0x0387},  
            /* Mode specific regieters */      
            {REG_FRAME_LENGTH_LINES_HI, vx6953_reg_pat[rt].frame_length_lines_hi},   
            {REG_FRAME_LENGTH_LINES_LO, vx6953_reg_pat[rt].frame_length_lines_lo},   
            {REG_LINE_LENGTH_PCK_HI, vx6953_reg_pat[rt].line_length_pck_hi},   
            {REG_LINE_LENGTH_PCK_LO, vx6953_reg_pat[rt].line_length_pck_lo},

            /* Change output size / frame rate */                   
            {REG_0x034c, vx6953_reg_pat[rt].reg_0x034c},  
            {REG_0x034d, vx6953_reg_pat[rt].reg_0x034d},  
            {REG_0x034e, vx6953_reg_pat[rt].reg_0x034e},  
            {REG_0x034f, vx6953_reg_pat[rt].reg_0x034f},
            /*EDOF: Estimation settings for Preview mode
           Application settings for capture mode  (standard settings - Not tuned) */
            {REG_0x0b80, vx6953_reg_pat[rt].reg_0x0b80},  
        };

            /* stop streaming */
            if(vx6953_i2c_write_b_sensor( REG_MODE_SELECT, MODE_SELECT_STANDBY_MODE )< 0){return rc;}
            mdelay(vx6953_stm5m0edof_delay_msecs_stream);

            rc = vx6953_i2c_write_w_table(&mode_tbl[0],
                               ARRAY_SIZE(mode_tbl));
            if (rc < 0)
                return rc;

            /* Start sensor streaming */
            if(vx6953_i2c_write_b_sensor( REG_MODE_SELECT, MODE_SELECT_STREAM )< 0){return rc;}
            mdelay(vx6953_stm5m0edof_delay_msecs_stream);

            if (vx6953_i2c_read (0x0005, &frame_cnt,1) < 0) return rc;

            while(frame_cnt == 0xFF)
            {
               if (vx6953_i2c_read (0x0005, &frame_cnt,1) < 0) return rc;
               CDBG("frame_cnt=%d", frame_cnt);
            }
        }
    return rc;
  default:
      return rc;
  }

  return rc;
}


static int32_t vx6953_video_config(int mode )
{

  int32_t rc = 0;
  int rt;
   CDBG("%s,%d\n",__func__,__LINE__);
  /* change sensor resolution if needed */
  if (vx6953_ctrl->curr_res != vx6953_ctrl->prev_res)
  {
    if (vx6953_ctrl->prev_res == QTR_SIZE)
    {
      rt = RES_PREVIEW;
      vx6953_stm5m0edof_delay_msecs_stdby = ((2 * 1000 * Q8 * vx6953_ctrl->fps_divider)/  vx6953_ctrl->fps) + 1;
      
       CDBG("%s,%d\n",__func__,__LINE__);
    }
    else
    {
      rt = RES_CAPTURE;
     vx6953_stm5m0edof_delay_msecs_stdby = ((1000 * Q8 * vx6953_ctrl->fps_divider)/  vx6953_ctrl->fps) + 1;
       CDBG("%s,%d\n",__func__,__LINE__);
    }

    if (vx6953_sensor_setting(UPDATE_PERIODIC, rt) < 0)
    {
         CDBG("%s,%d\n",__func__,__LINE__);
      return rc;
    }   
  }
   if(vx6953_ctrl->set_test)
  {
    if (vx6953_test(vx6953_ctrl->set_test) < 0) {return rc;}
  }
   vx6953_ctrl->curr_res = vx6953_ctrl->prev_res;
   vx6953_ctrl->sensormode = mode;
	 CDBG("%s,%d\n",__func__,__LINE__);
   return rc;
}/*end of ov354_video_config*/

static int32_t vx6953_snapshot_config(int mode)
{
	
    int32_t rc = 0;
    int rt;

    CDBG("%s,%d\n",__func__,__LINE__);

  /* change sensor resolution if needed */
  if (vx6953_ctrl->curr_res != vx6953_ctrl->pict_res)
  {
    if (vx6953_ctrl->pict_res == QTR_SIZE)
    {
      rt = RES_PREVIEW;
      vx6953_stm5m0edof_delay_msecs_stdby = ((2 * 1000 * Q8 * vx6953_ctrl->fps_divider)/  vx6953_ctrl->fps) + 1;
    }
    else
    {
      rt = RES_CAPTURE;
      vx6953_stm5m0edof_delay_msecs_stdby = (( 1000 * Q8 * vx6953_ctrl->fps_divider)/  vx6953_ctrl->fps) + 1;
     }

    if (vx6953_sensor_setting(UPDATE_PERIODIC, rt) < 0)
    {
      return rc;
    }   
  }
   vx6953_ctrl->curr_res = vx6953_ctrl->pict_res;
   vx6953_ctrl->sensormode = mode;
     return rc;
 }/*end of vx6953_snapshot_config*/

static int32_t vx6953_raw_snapshot_config(int mode)
{
   int32_t rc = 0;
     int rt;
  /* change sensor resolution if needed */
  if (vx6953_ctrl->curr_res != vx6953_ctrl->pict_res)
  {
    if (vx6953_ctrl->pict_res == QTR_SIZE)
    {
      rt = RES_PREVIEW;
       vx6953_stm5m0edof_delay_msecs_stdby = ((2 * 1000 * Q8 * vx6953_ctrl->fps_divider)/  vx6953_ctrl->fps) + 1;
    }
    else
    {
      rt = RES_CAPTURE;
      vx6953_stm5m0edof_delay_msecs_stdby = ((1000 * Q8 * vx6953_ctrl->fps_divider)/  vx6953_ctrl->fps) + 1;
    }
    if (vx6953_sensor_setting(UPDATE_PERIODIC, rt) < 0)
    {
      return rc;
    }   
  }
   vx6953_ctrl->curr_res = vx6953_ctrl->pict_res;
   vx6953_ctrl->sensormode = mode;
     return rc;
}/*end of vx6953_raw_snapshot_config*/

static int32_t vx6953_set_sensor_mode(int  mode,
	int  res)
{
	int32_t rc = 0;

	switch (mode) {
	case SENSOR_PREVIEW_MODE:
		rc = vx6953_video_config(mode);
		break;

	case SENSOR_SNAPSHOT_MODE:
		rc = vx6953_snapshot_config(mode);
		break;

	case SENSOR_RAW_SNAPSHOT_MODE:
		rc = vx6953_raw_snapshot_config(mode);
		break;
				
	default:
		rc = -EINVAL;
		break;
	}
	return rc;
}

static int32_t vx6953_power_down(void)
{
	return 0;
}


static int vx6953_probe_init_done(const struct msm_camera_sensor_info *data)
{
	gpio_direction_output(data->sensor_reset, 0);
	gpio_free(data->sensor_reset);
	return 0;
}
static int vx6953_probe_init_sensor(const struct msm_camera_sensor_info *data)
{
	int32_t rc = 0;

    unsigned short chipidl, chipidh;

    CDBG("%s: %d\n", __func__, __LINE__);
	rc = gpio_request(data->sensor_reset, "vx6953");
     CDBG(" vx6953_probe_init_sensor \n");
	if (!rc)
    {    CDBG("sensor_reset = %d\n", rc);
        CDBG(" vx6953_probe_init_sensor 1\n");
    
		gpio_direction_output(data->sensor_reset, 0);
        mdelay(50);
       CDBG(" vx6953_probe_init_sensor 1\n");
		gpio_direction_output(data->sensor_reset, 1);
        mdelay(13);
    }
	else
    {    CDBG(" vx6953_probe_init_sensor 2\n");
		goto init_probe_done;
    }
    
	mdelay(20);

    CDBG(" vx6953_probe_init_sensor is called \n");

	/* 3. Read sensor Model ID: */
    rc = vx6953_i2c_read(0x0000, &chipidh,1);
	if ( rc < 0) {
        CDBG(" vx6953_probe_init_sensor 3 \n");    
		goto init_probe_fail;
    }

    rc = vx6953_i2c_read(0x0001, &chipidl,1);
    if ( rc < 0) {
        CDBG(" vx6953_probe_init_sensor4 \n");    
		goto init_probe_fail;
    }

	CDBG("vx6953 model_id = 0x%x  0x%x\n", chipidh, chipidl);

	/* 4. Compare sensor ID to VX6953 ID: */
	if (chipidh != 0x03 || chipidl != 0xB9) {
		rc = -ENODEV;
        CDBG("vx6953_probe_init_sensor fail chip id doesnot match\n");
		goto init_probe_fail;
	}

	//mdelay(VX6953_RESET_DELAY_MSECS);

  goto init_probe_done;

init_probe_fail:
    CDBG(" vx6953_probe_init_sensor fails\n");
	vx6953_probe_init_done(data);
init_probe_done:
	CDBG(" vx6953_probe_init_sensor finishes\n");
	return rc;
}
 /* camsensor_iu060f_vx6953_reset */

int vx6953_sensor_open_init(const struct msm_camera_sensor_info *data)
{

    unsigned short revision_number;
    int32_t  rc = 0;
    struct msm_camera_csi_params *vx6953_csi_params = kzalloc(sizeof(struct msm_camera_csi_params), GFP_KERNEL);
    

    CDBG("%s: %d\n", __func__, __LINE__);
	CDBG("Calling vx6953_sensor_open_init\n");
	vx6953_ctrl = kzalloc(sizeof(struct vx6953_ctrl_t), GFP_KERNEL);
	if (!vx6953_ctrl) {
		CDBG("vx6953_init failed!\n");
		rc = -ENOMEM;
		goto init_done;
	}

	vx6953_ctrl->fps_divider = 1 * 0x00000400;
	vx6953_ctrl->pict_fps_divider = 1 * 0x00000400;
	vx6953_ctrl->set_test = TEST_OFF;
	vx6953_ctrl->prev_res = QTR_SIZE;
	vx6953_ctrl->pict_res = FULL_SIZE;
	vx6953_ctrl->curr_res = INVALID_SIZE;
    vx6953_ctrl->sensor_type = VX6953_STM5M0EDOF_CUT_2;

	if (data)
		vx6953_ctrl->sensordata = data;
	//rc = vx6953_reset();
    if (rc < 0) {
        CDBG("Calling vx6953_sensor_open_init fail1\n");
        return rc;
    }
    CDBG("%s: %d\n", __func__, __LINE__);
	/* enable mclk first */
	msm_camio_clk_rate_set(VX6953_STM5M0EDOF_DEFAULT_MASTER_CLK_RATE);
	mdelay(20);

	//msm_camio_camif_pad_reg_reset();
	//mdelay(20);

    CDBG("%s: %d\n", __func__, __LINE__);

	rc = vx6953_probe_init_sensor(data);
	if (rc < 0)
    {     CDBG("Calling vx6953_sensor_open_init fail3\n");
		goto init_fail;
    }
      /* Initialize Sensor registers */
 CDBG("Calling vx6953_sensor_open_init fail4\n");
    /* send reset signal */
  //rc = vx6953_reset();
  if (rc < 0) {
   CDBG("Calling vx6953_sensor_open_init fail5\n");
      return rc;
  }
   
    if (vx6953_i2c_read (0x0002, &revision_number,1) < 0) return rc;
    CDBG("sensor revision number major = 0x%x\n", revision_number);

    if (vx6953_i2c_read (0x0018, &revision_number,1) < 0) return rc;
    CDBG("sensor revision number = 0x%x\n", revision_number);

    if(revision_number == VX6953_REVISION_NUMBER)
    {
      vx6953_ctrl->sensor_type = VX6953_STM5M0EDOF_CUT_2;

      CDBG("VX6953 EDof Cut 2.0 sensor\n ");
    }
    else
    {/* Cut1.0 reads 0x00 for register 0x0018*/
      vx6953_ctrl->sensor_type = VX6953_STM5M0EDOF_CUT_1;
      CDBG("VX6953 EDof Cut 1.0 sensor \n");
    }    

    /* config mipi csi controller */
    CDBG("vx6953_sensor_open_init: config csi controller \n");
    vx6953_csi_params->data_format = CSI_8BIT;
    vx6953_csi_params->lane_cnt = 1;
    vx6953_csi_params->lane_assign = 0xe4; 
    vx6953_csi_params->dpcm_scheme = 0;
    vx6953_csi_params->settle_cnt = 7;
    rc = msm_camio_csi_config(vx6953_csi_params);
    if (rc < 0) {
        CDBG("vx6953_sensor_open_init: config csi controller failed \n");
    }


	 if (vx6953_ctrl->prev_res == QTR_SIZE)
    {
      if (vx6953_sensor_setting(REG_INIT, RES_PREVIEW) < 0)
        return rc;
    }
    else
    {
      if (vx6953_sensor_setting(REG_INIT, RES_CAPTURE)< 0)
        return rc;
    }

	vx6953_ctrl->fps = 30*Q8;
	if (rc < 0)
		
		goto init_fail;
	else
		goto init_done;
	    /* reset the driver state */
	init_fail:
		CDBG(" init_fail \n");
        vx6953_probe_init_done(data);
			kfree(vx6953_ctrl);
	init_done:
			CDBG("init_done \n");
			return rc;
}/*endof vx6953_sensor_open_init*/

static int vx6953_init_client(struct i2c_client *client)
{
	/* Initialize the MSM_CAMI2C Chip */
	init_waitqueue_head(&vx6953_wait_queue);
	return 0;
}

static const struct i2c_device_id vx6953_i2c_id[] = {
	{ "vx6953", 0},
	{ }
};

static int vx6953_i2c_probe(struct i2c_client *client,
	const struct i2c_device_id *id)
{
	int rc = 0;
	CDBG("vx6953_probe called!\n");

	if (!i2c_check_functionality(client->adapter, I2C_FUNC_I2C)) {
		CDBG("i2c_check_functionality failed\n");
		goto probe_failure;
	}

	vx6953_sensorw = kzalloc(sizeof(struct vx6953_work_t), GFP_KERNEL);
	if (!vx6953_sensorw) {
		CDBG("kzalloc failed.\n");
		rc = -ENOMEM;
		goto probe_failure;
	}

	i2c_set_clientdata(client, vx6953_sensorw);
	vx6953_init_client(client);
	vx6953_client = client;

	mdelay(50);

	CDBG("vx6953_probe successed! rc = %d\n", rc);
	return 0;

probe_failure:
	CDBG("vx6953_probe failed! rc = %d\n", rc);
	return rc;
}

static int __exit vx6953_remove(struct i2c_client *client)
{
	struct vx6953_work_t_t *sensorw = i2c_get_clientdata(client);
	free_irq(client->irq, sensorw);
	vx6953_client = NULL;
	kfree(sensorw);
	return 0;
}

static struct i2c_driver vx6953_i2c_driver = {
	.id_table = vx6953_i2c_id,
	.probe	= vx6953_i2c_probe,
	.remove = __exit_p(vx6953_i2c_remove),
	.driver = {
		.name = "vx6953",
	},
};

int vx6953_sensor_config(void __user *argp)
{
	struct sensor_cfg_data cdata;
	long   rc = 0;

	if (copy_from_user(&cdata,
				(void *)argp,
				sizeof(struct sensor_cfg_data)))
		return -EFAULT;

	down(&vx6953_sem);

  CDBG("vx6953_sensor_config: cfgtype = %d\n",
	  cdata.cfgtype);
		switch (cdata.cfgtype) {
		case CFG_GET_PICT_FPS:
				vx6953_get_pict_fps(
				cdata.cfg.gfps.prevfps,
				&(cdata.cfg.gfps.pictfps));

			if (copy_to_user((void *)argp,
				&cdata,
				sizeof(struct sensor_cfg_data)))
				rc = -EFAULT;
			break;

		case CFG_GET_PREV_L_PF:
			cdata.cfg.prevl_pf =
			vx6953_get_prev_lines_pf();

			if (copy_to_user((void *)argp,
				&cdata,
				sizeof(struct sensor_cfg_data)))
				rc = -EFAULT;
			break;

		case CFG_GET_PREV_P_PL:
			cdata.cfg.prevp_pl =
				vx6953_get_prev_pixels_pl();

			if (copy_to_user((void *)argp,
				&cdata,
				sizeof(struct sensor_cfg_data)))
				rc = -EFAULT;
			break;

		case CFG_GET_PICT_L_PF:
			cdata.cfg.pictl_pf =
				vx6953_get_pict_lines_pf();

			if (copy_to_user((void *)argp,
				&cdata,
				sizeof(struct sensor_cfg_data)))
				rc = -EFAULT;
			break;

		case CFG_GET_PICT_P_PL:
			cdata.cfg.pictp_pl =
				vx6953_get_pict_pixels_pl();

			if (copy_to_user((void *)argp,
				&cdata,
				sizeof(struct sensor_cfg_data)))
				rc = -EFAULT;
			break;

		case CFG_GET_PICT_MAX_EXP_LC:
			cdata.cfg.pict_max_exp_lc =
				vx6953_get_pict_max_exp_lc();

			if (copy_to_user((void *)argp,
				&cdata,
				sizeof(struct sensor_cfg_data)))
				rc = -EFAULT;
			break;

		case CFG_SET_FPS:
		case CFG_SET_PICT_FPS:
			rc = vx6953_set_fps(&(cdata.cfg.fps));
			break;

		case CFG_SET_EXP_GAIN:
			rc =
				vx6953_write_exp_gain(
					cdata.cfg.exp_gain.gain,
					cdata.cfg.exp_gain.line);
			break;

		case CFG_SET_PICT_EXP_GAIN:
			rc =
				vx6953_set_pict_exp_gain(
					cdata.cfg.exp_gain.gain,
					cdata.cfg.exp_gain.line);
			break;

		case CFG_SET_MODE:
			rc = vx6953_set_sensor_mode(cdata.mode,
						cdata.rs);
			break;

		case CFG_PWR_DOWN:
			rc = vx6953_power_down();
			break;

		case CFG_MOVE_FOCUS:
			rc =
				vx6953_move_focus(
					cdata.cfg.focus.dir,
					cdata.cfg.focus.steps);
			break;

		case CFG_SET_DEFAULT_FOCUS:
			rc =
				vx6953_set_default_focus(
					cdata.cfg.focus.steps);
			break;

		case CFG_SET_EFFECT:
			rc = vx6953_set_default_focus(
						cdata.cfg.effect);
			break;

		default:
			rc = -EFAULT;
			break;
		}

	up(&vx6953_sem);

	return rc;
}




static int vx6953_sensor_release(void)
{
	int rc = -EBADF;

	down(&vx6953_sem);

	vx6953_power_down();

	gpio_direction_output(vx6953_ctrl->sensordata->sensor_reset,
		0);
	gpio_free(vx6953_ctrl->sensordata->sensor_reset);

	kfree(vx6953_ctrl);
	vx6953_ctrl = NULL;

	CDBG("vx6953_release completed\n");

	
	up(&vx6953_sem);
	
	return rc;
}

static int vx6953_sensor_probe(const struct msm_camera_sensor_info *info,
		struct msm_sensor_ctrl *s)
{
	int rc = 0;

	rc = i2c_add_driver(&vx6953_i2c_driver);
	if (rc < 0 || vx6953_client == NULL) {
		rc = -ENOTSUPP;
		goto probe_fail;
	}

	msm_camio_clk_rate_set(24000000);
	//mdelay(20);

	rc = vx6953_probe_init_sensor(info);
	if (rc < 0)
		goto probe_fail;

	s->s_init = vx6953_sensor_open_init;
	s->s_release = vx6953_sensor_release;
	s->s_config  = vx6953_sensor_config;
	vx6953_probe_init_done(info);

	return rc;

probe_fail:
	CDBG("vx6953_sensor_probe: SENSOR PROBE FAILS!\n");
	return rc;
}

static int __vx6953_probe(struct platform_device *pdev)
{
	return msm_camera_drv_start(pdev, vx6953_sensor_probe);
}

static struct platform_driver msm_camera_driver = {
	.probe = __vx6953_probe,
	.driver = {
		.name = "msm_camera_vx6953",
		.owner = THIS_MODULE,
	},
};

static int __init vx6953_init(void)
{
	return platform_driver_register(&msm_camera_driver);
}

module_init(vx6953_init);
void vx6953_exit(void)
{
	i2c_del_driver(&vx6953_i2c_driver);
}


