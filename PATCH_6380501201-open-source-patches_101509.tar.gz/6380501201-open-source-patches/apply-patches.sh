#!/bin/bash 
#Assumption 1: This script assumes that the patches have been pushed out to <android_root>/vendor/qcom-patches 
#Assumption 2: This script requires the current directory to be the android root directory

pushd frameworks/base
git apply ../../vendor/qcom-patches/frameworks-base.patch
popd
pushd frameworks/policies/base 
git apply ../../../vendor/qcom-patches/frameworks-policies-base.patch 
popd 

