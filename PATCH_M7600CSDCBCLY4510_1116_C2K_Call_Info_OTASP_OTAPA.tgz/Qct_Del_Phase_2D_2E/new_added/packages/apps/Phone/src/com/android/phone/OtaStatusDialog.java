/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.phone;

import android.app.Activity;
import android.app.Dialog;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.DialogInterface;
import android.os.AsyncResult;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;


public class OtaStatusDialog extends Activity {

    // defines of ota status
    private static final int SPL_UNLOCKED = 0;
    private static final int SPC_RETRIES_EXCEEDED = 1;
    private static final int A_KEY_EXCHANGED = 2;
    private static final int SSD_UPDATED = 3;
    private static final int NAM_DOWNLOADED = 4;
    private static final int MDN_DOWNLOADED = 5;
    private static final int IMSI_DOWNLOADED = 6;
    private static final int PRL_DOWNLOADED = 7;
    private static final int COMMITTED = 8;
    private static final int OTAPA_STARTED = 9;
    private static final int OTAPA_STOPPED = 10;
    private static final int OTAPA_ABORTED = 11;

//    private IntentFilter mOtaStatusFilter;

    // dialog creation method, called by showDialog()
    @Override
    protected Dialog onCreateDialog(int id) {

        int otaMessageResId = 99;
        switch (id) {
            case SPL_UNLOCKED:
                otaMessageResId = R.string.spl_unlocked;
                break;

            case SPC_RETRIES_EXCEEDED:
                otaMessageResId = R.string.spc_retries_exceeded;
                break;

            case A_KEY_EXCHANGED:
                otaMessageResId = R.string.a_key_exchanged;
                break;

            case SSD_UPDATED:
                otaMessageResId = R.string.ssd_updated;
                break;

            case NAM_DOWNLOADED:
                otaMessageResId = R.string.nam_downloaded;
                break;

            case MDN_DOWNLOADED:
                otaMessageResId = R.string.mdn_downloaded;
                break;

            case IMSI_DOWNLOADED:
                otaMessageResId = R.string.imsi_downloaded;
                break;

            case PRL_DOWNLOADED:
                otaMessageResId = R.string.prl_downloaded;
                break;

            case COMMITTED:
                otaMessageResId = R.string.committed;
                break;

            case OTAPA_STARTED:
                otaMessageResId = R.string.otapa_started;
                break;

            case OTAPA_STOPPED:
                otaMessageResId = R.string.otapa_stopped;
                break;

            case OTAPA_ABORTED:
                otaMessageResId = R.string.otapa_aborted;
                break;

            default:
                otaMessageResId = R.string.ota_unexpected;
                break;
        }


        AlertDialog.Builder otaStatusDialog = new AlertDialog.Builder(this)
            .setMessage(otaMessageResId)
            .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                public void onClick (DialogInterface dialog, int id) {
                    finish();
                    }
                });

        AlertDialog dialog = otaStatusDialog.create();

        // make the dialog more obvious by bluring the background.
        dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND);

        return dialog;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.ecbm_layout);

        final PhoneApp app = PhoneApp.getInstance();
        app.setOtaStatusDialogInstance(this);
        showDialog(app.otaStatus);

    }

}
