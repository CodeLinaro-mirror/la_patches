#-----------------------------------------------------------------------------
# Copyright (c) 2009 QUALCOMM Incorporated.
# All Rights Reserved. QUALCOMM Proprietary and Confidential.
#-----------------------------------------------------------------------------

ifeq ($(TARGET_ARCH),arm)

LOCAL_PATH := $(call my-dir)
commonSources :=
commonSharedLibraries += libc libcutils libutils

include $(CLEAR_VARS)
LOCAL_MODULE := fun_jump
LOCAL_C_INCLUDE := 
LOCAL_SRC_FILES += $(commonSources) fun_jump.c
LOCAL_SHARED_LIBRARIES := $(commonSharedLibraries)
LOCAL_MODULE_TAGS := eng
LOCAL_MODULE_PATH := $(TARGET_OUT_DATA)/kernel-tests
include $(BUILD_EXECUTABLE)

include $(CLEAR_VARS)
LOCAL_MODULE := fun_branch
LOCAL_C_INCLUDE := 
LOCAL_SRC_FILES += $(commonSources) fun_branch.c
LOCAL_SHARED_LIBRARIES := $(commonSharedLibraries)
LOCAL_MODULE_TAGS := eng
LOCAL_MODULE_PATH := $(TARGET_OUT_DATA)/kernel-tests
include $(BUILD_EXECUTABLE)

include $(CLEAR_VARS)
LOCAL_MODULE := fun_load
LOCAL_C_INCLUDE := 
LOCAL_SRC_FILES += $(commonSources) fun_load.c
LOCAL_SHARED_LIBRARIES := $(commonSharedLibraries)
LOCAL_MODULE_TAGS := eng
LOCAL_MODULE_PATH := $(TARGET_OUT_DATA)/kernel-tests
include $(BUILD_EXECUTABLE)

LOCAL_CFLAGS+=-Werror

endif