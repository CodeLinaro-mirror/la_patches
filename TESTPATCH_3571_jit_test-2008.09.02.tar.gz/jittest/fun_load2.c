

/*

arm-eabi-gcc -c fun.c
arm-eabi-ld --dynamic-linker /system/bin/linker -L ../out/target/product/msm7630_surf/system/lib -lc -ldl -o fun fun.o

I didn't set an rpath.....
Maybe push libc.so and libdl.so to /system/bin or the same place as fun

*/

/* Instruction buffer size... We only need 49 insns */
#define N_INST 100
#define EXP_RES 19 
#define EXP_RES -38

/* Our 'function buffer' */
unsigned int fun[N_INST*2];

/* Function... no input parameters, return an int in r0 */
/* Does not clobber registers besides r0 */
/* Compute 1+2+3+...+47. Expect result = 1128, returned in r0 */
unsigned int fun1[N_INST] = {
	0xE3A03000, 	/* mov r3, #0 		*/

	0xE5902000, 	/* ldr r2, [r0]		*/
	0xE0833002, 	/* add r3, r3, r2 	*/
	0xE5902000, 	/* ldr r2, [r0]		*/
	0xE0833002, 	/* add r3, r3, r2 	*/
	0xE5902000, 	/* ldr r2, [r0]		*/
	0xE0833002, 	/* add r3, r3, r2 	*/
	0xE5902000, 	/* ldr r2, [r0]		*/
	0xE0833002, 	/* add r3, r3, r2 	*/
	0xE5902000, 	/* ldr r2, [r0]		*/
	0xE0833002, 	/* add r3, r3, r2 	*/
	0xE5902000, 	/* ldr r2, [r0]		*/
	0xE0833002, 	/* add r3, r3, r2 	*/
	0xE5902000, 	/* ldr r2, [r0]		*/
	0xE0833002, 	/* add r3, r3, r2 	*/
	0xE5902000, 	/* ldr r2, [r0]		*/
	0xE0833002, 	/* add r3, r3, r2 	*/
	0xE5902000, 	/* ldr r2, [r0]		*/
	0xE0833002, 	/* add r3, r3, r2 	*/
	0xE5902000, 	/* ldr r2, [r0]		*/
	0xE0833002, 	/* add r3, r3, r2 	*/
	0xE5902000, 	/* ldr r2, [r0]		*/
	0xE0833002, 	/* add r3, r3, r2 	*/
	0xE5902000, 	/* ldr r2, [r0]		*/
	0xE0833002, 	/* add r3, r3, r2 	*/
	0xE5902000, 	/* ldr r2, [r0]		*/
	0xE0833002, 	/* add r3, r3, r2 	*/
	0xE5902000, 	/* ldr r2, [r0]		*/
	0xE0833002, 	/* add r3, r3, r2 	*/
	0xE5902000, 	/* ldr r2, [r0]		*/
	0xE0833002, 	/* add r3, r3, r2 	*/
	0xE5902000, 	/* ldr r2, [r0]		*/
	0xE0833002, 	/* add r3, r3, r2 	*/
	0xE5902000, 	/* ldr r2, [r0]		*/
	0xE0833002, 	/* add r3, r3, r2 	*/
	0xE5902000, 	/* ldr r2, [r0]		*/
	0xE0833002, 	/* add r3, r3, r2 	*/
	0xE5902000, 	/* ldr r2, [r0]		*/
	0xE0833002, 	/* add r3, r3, r2 	*/

	0xE1A00003,	/* mov r0, r3 		*/
	0xE1A0F00E	/* mov pc, lr   	*/

};

/* Function... no input parameters, return an int in r0 */
/* Does not clobber registers besides r0 */
/* Compute 0-1-2-3-...-47. Expect result = -1128, returned in r0 */
unsigned int fun2[N_INST] = {
	0xE3A03000, 	/* mov r3, #0 		*/

	0xE5912000, 	/* ldr r2, [r1] 	*/
	0xE0433002, 	/* sub r3, r3, r2	*/
	0xE5912000, 	/* ldr r2, [r1] 	*/
	0xE0433002, 	/* sub r3, r3, r2	*/
	0xE5912000,
	0xE0433002,
	0xE5912000,
	0xE0433002,
	0xE5912000,
	0xE0433002,
	0xE5912000,
	0xE0433002,
	0xE5912000,
	0xE0433002,
	0xE5912000,
	0xE0433002,
	0xE5912000,
	0xE0433002,
	0xE5912000,
	0xE0433002,
	0xE5912000,
	0xE0433002,
	0xE5912000,
	0xE0433002,
	0xE5912000,
	0xE0433002,
	0xE5912000,
	0xE0433002,
	0xE5912000,
	0xE0433002,
	0xE5912000,
	0xE0433002,
	0xE5912000,
	0xE0433002,
	0xE5912000,
	0xE0433002,
	0xE5912000,
	0xE0433002,

	0xE1A00003,	/* mov r0, r3 		*/
	0xE1A0F00E	/* mov pc, lr		*/
};

void flush(void)
{
	cacheflush((long)fun, (long)(fun+N_INST), 0);
}

int main(int argc, char** argv)
{
	int (*do_stuff)(unsigned int,unsigned int) = fun;

	int ret = 0, i = 0, n = 0;
	volatile int addval;
	unsigned int ptr = &addval;

	printf("Load test starting\n");

	fun[N_INST*2-1] = (unsigned int)getpid();
	/* Some iteration counter stuff... */
	for (n = 0; n < 1000; n++) {
		if (n % 10000 == 0)
			printf("Iteration %d\n", n);


		for (i = 0; i < N_INST; i++)	/* Copy first function into */
			fun[i] = fun1[i];	/* execution buffer */

		addval = 1;
		fun[45] = (unsigned int)getpid();
		flush();			/* Flush caches */
		ret = do_stuff(ptr, 0);		/* Call execution buffer */

		if (ret != 19) {		/* Compare result value */
			printf("CRAAAAASH! Test 1, ret = %d\n", ret);
			goto fail;
		}

		for (i = 0; i < N_INST; i++)	/* Copy secnod function into */
			fun[i] = fun2[i];	/* execution buffer */


		addval = 2;
		fun[45] = (unsigned int)getpid();
		flush();			/* Flush caches */

		ret = do_stuff(0, ptr);		/* Call execution buffer */

		if (ret != -38) {		/* Compare result value */
			printf("CRAAAAASH! Test 2, ret = %d\n", ret);
			goto fail;
		}
	}
	printf("Load test finished OK\n");
	return 0;
fail:
	while(1);
	return -1;
}

