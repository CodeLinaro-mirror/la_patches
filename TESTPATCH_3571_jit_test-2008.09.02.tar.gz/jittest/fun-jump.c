
/*

arm-eabi-gcc -c fun.c
arm-eabi-ld --dynamic-linker /system/bin/linker -L ../out/target/product/msm7630_surf/system/lib -lc -ldl -o fun fun.o

I didn't set an rpath.....
Maybe push libc.so and libdl.so to /system/bin or the same place as fun

*/

/* Instruction buffer size... We only need 49 insns */
#define N_INST 100

/* Our 'function buffer' */
unsigned int fun[N_INST];

/* Function... no input parameters, return an int in r0 */
unsigned int fun1[N_INST] = {
	0xE3A00000,	/* mov r0, #0     */
	0xE28FF008, 	/* add pc, pc, #8 */
	0xE2800001,	/* add r0, r0, #1 */
	0xE2800002,	/* add r0, r0, #2 */
	0xE2800003,
	0xE2800004,
	0xE2800005,
	0xE2800006,
	0xE2800007,
	0xE2800008,
	0xE2800009,
	0xE280000A,
	0xE280000B,
	0xE280000C,
	0xE280000D,
	0xE280000E,
	0xE280000F,
	0xE2800010,
	0xE2800011,
	0xE2800012,
	0xE2800013,
	0xE2800014,
	0xE2800015,
	0xE2800016,
	0xE2800017,
	0xE2800018,
	0xE2800019,
	0xE280001A,
	0xE280001B,
	0xE280001C,
	0xE280001D,
	0xE280001E,
	0xE280001F,
	0xE2800020,
	0xE2800021,
	0xE2800022,
	0xE2800023,
	0xE2800024,
	0xE2800025,
	0xE2800026,
	0xE2800027,
	0xE2800028,
	0xE2800029,
	0xE280002A,
	0xE280002B,
	0xE280002C,
	0xE280002D,
	0xE280002E,
	0xE280002F,
	0xE1A0F00E	/* mov pc, lr     */
};

/* Function... no input parameters, return an int in r0 */
unsigned int fun2[N_INST] = {
	0xE3A00000,	/* mov r0, #0     */
	0xE28FF010, 	/* add pc, pc, #10 */
	0xE2400001,	/* sub r0, r0, #1 */
	0xE2400002,	/* sub r0, r0, #2 */
	0xE2400003,
	0xE2400004,
	0xE2400005,
	0xE2400006,
	0xE2400007,
	0xE2400008,
	0xE2400009,
	0xE240000A,
	0xE240000B,
	0xE240000C,
	0xE240000D,
	0xE240000E,
	0xE240000F,
	0xE2400010,
	0xE2400011,
	0xE2400012,
	0xE2400013,
	0xE2400014,
	0xE2400015,
	0xE2400016,
	0xE2400017,
	0xE2400018,
	0xE2400019,
	0xE240001A,
	0xE240001B,
	0xE240001C,
	0xE240001D,
	0xE240001E,
	0xE240001F,
	0xE2400020,
	0xE2400021,
	0xE2400022,
	0xE2400023,
	0xE2400024,
	0xE2400025,
	0xE2400026,
	0xE2400027,
	0xE2400028,
	0xE2400029,
	0xE240002A,
	0xE240002B,
	0xE240002C,
	0xE240002D,
	0xE240002E,
	0xE240002F,
	0xE1A0F00E	/* mov pc, lr     */
};

void flush(void)
{
	cacheflush((long)fun, (long)(fun+N_INST), 0);
}

int main(int argc, char** argv)
{
	int (*do_stuff)(void) = fun;

	int ret = 0, i = 0, n = 0;

	printf("Branching test starting\n");

	/* Some iteration counter stuff... */
	for (n = 0; n < 1000; n++) {
		if (n % 10000 == 0)
			printf("Iteration %d\n", n);


		for (i = 0; i < N_INST; i++)	/* Copy first function into */
			fun[i] = fun1[i];	/* execution buffer */

		flush();			/* Flush caches */
		ret = do_stuff();		/* Call execution buffer */

		if (ret != 1115) {		/* Compare result value */
			printf("CRAAAAASH! Test 1, ret = %d, expected 1115, iter=%d\n", ret, n);
			goto fail;
		}

		for (i = 0; i < N_INST; i++)	/* Copy secnod function into */
			fun[i] = fun2[i];	/* execution buffer */

		flush();			/* Flush caches */

		ret = do_stuff();		/* Call execution buffer */

		if (ret != -1107) {		/* Compare result value */
			printf("CRAAAAASH! Test 2, ret = %d, expected -1107, iter=%d\n", ret, n);
			goto fail;
		}
	}
	printf("Branching test finished OK\n");
	return 0;
fail:
	while(1);
	return -1;
}
