Instructions
1) Apply PATCH_MSM8x55_404003_2.3.4r1_20110521.tar.gz first
2) Then Apply frameworks_base.gitdiff for USB tethering fix
3) Only if needed, apply device_qcom_msm7630_surf.gitdiff (resolves wifi issue).
