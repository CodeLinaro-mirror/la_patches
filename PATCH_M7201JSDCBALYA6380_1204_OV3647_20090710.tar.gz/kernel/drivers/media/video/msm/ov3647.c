/* Copyright (c) 2008-2009, Code Aurora Forum. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of Code Aurora Forum nor
 *       the names of its contributors may be used to endorse or promote
 *       products derived from this software without specific prior written
 *       permission.
 *
 * Alternatively, provided that this notice is retained in full, this software
 * may be relicensed by the recipient under the terms of the GNU General Public
 * License version 2 ("GPL") and only version 2, in which case the provisions of
 * the GPL apply INSTEAD OF those given above.  If the recipient relicenses the
 * software under the GPL, then the identification text in the MODULE_LICENSE
 * macro must be changed to reflect "GPLv2" instead of "Dual BSD/GPL".  Once a
 * recipient changes the license terms to the GPL, subsequent recipients shall
 * not relicense under alternate licensing terms, including the BSD or dual
 * BSD/GPL terms.  In addition, the following license statement immediately
 * below and between the words START and END shall also then apply when this
 * software is relicensed under the GPL:
 *
 * START
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 2 and only version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
 * END
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include <linux/delay.h>
#include <linux/types.h>
#include <linux/i2c.h>
#include <linux/uaccess.h>
#include <linux/miscdevice.h>
#include <media/msm_camera.h>
#include <mach/gpio.h>
#include <mach/camera.h>
#include "ov3647.h"

/*=============================================================
	SENSOR REGISTER DEFINES
==============================================================*/
#define Q8    0x00000100
typedef unsigned char byte;
typedef struct
{
  byte reg;
  byte val;
} ov3647_config_struct_t;


static ov3647_config_struct_t ov3647_init_qtr_settings[] = {
  {0x77, 0x00}, {0x78, 0x00}, {0x01, 0x3f}, {0x0c, 0x08}, {0x0e, 0x29},
  {0x0f, 0x0c}, {0x13, 0x00}, {0x15, 0x82}, {0x16, 0x83}, {0x72, 0x02},
  {0x75, 0x06}, {0x7a, 0x08}, {0x7b, 0x12}, {0x91, 0x4a}, {0x99, 0x4c},
  {0x9b, 0xf0}, {0xA8, 0x20}, {0x9B, 0x00}, {0xA9, 0xB3}, {0x9c, 0x18},
  {0xd8, 0x0d}, {0xd9, 0x80}, {0x78, 0x60}, {0xa6, 0x83}, {0xd8, 0x0d},
  {0xd9, 0x8d}, {0x67, 0xcc}, {0x66, 0x04}, {0xd9, 0x8e}, {0x21, 0x35},
  {0x23, 0x06}, {0x24, 0x40}, {0x25, 0x88}, {0x26, 0x30}, {0x27, 0x40},
  {0x28, 0x07}, {0x29, 0x44}, {0x2a, 0x03}, {0x2b, 0xdd}, {0x92, 0x80},
  {0x12, 0x10}, {0x11, 0x00}, {0x7b, 0x02}, {0xb1, 0xc3}, {0xc9, 0x75},
  {0xB7, 0x3F}, {0xB8, 0x2D}, {0xB9, 0x2D}, {0xBA, 0x31}, {0xBB, 0x00},
  {0xBC, 0x07}, {0xBD, 0x3F}, {0xBE, 0x2D}, {0xBF, 0x2D}, {0xC0, 0x2B},
  {0xC1, 0x00}, {0xC2, 0x07}, {0xC3, 0x3F}, {0xC4, 0x2D}, {0xC5, 0x2D},
  {0xC6, 0x28}, {0xC7, 0x00}, {0xC8, 0x07}, {0x93, 0x1f}, {0xd4, 0x20},
  {0xd6, 0x00}, {0x67, 0xcc}
 };

static ov3647_config_struct_t ov3647_qtr_full_settings[] = {
  {0x0e, 0x29}, {0x21, 0x35}, {0x23, 0x0c}, {0x24, 0x81}, {0x25, 0x00},
  {0x26, 0x60}, {0x27, 0x80}, {0x28, 0x09}, {0x29, 0x3c}, {0x2a, 0x06},
  {0x2b, 0x26}, {0xd9, 0x8d}, {0x92, 0x00}, {0x12, 0x00}, {0xb1, 0xc3},
  {0xd4, 0x00}, {0x93, 0x1e}, {0x91, 0x40}, {0xd6, 0x00}, {0x67, 0xcc}
};

/* Omnivision5630 product ID register address */
#define OV3647_PIDH_REG                0x0A
#define OV3647_PIDL_REG                0x0B
#define OV3647_PID                     0x36 /* Omnivision5630 product ID */
#define OV3647_VER                     0x47 /* Omnivision5630 version */
#define OV3647_AF_I2C_ADDR             0x18
#define REG_COLOR_BAR_PATTERN_SEL_REG  0x97 /* Test Pattern */
#define REG_COLOR_BAR_ENABLE_REG       0x12


#define OV3647_GAIN         0x01


#define OV3647_AEC_MSB      0x02
#define OV3647_AEC_LSB      0x03

#define MAX_LINE_STEP     7 /* Max allowed exposure line increase for SVGA */

/* AF Total steps parameter */  
#define OV3647_STEPS_NEAR_TO_CLOSEST_INF  24         
#define OV3647_TOTAL_STEPS_NEAR_TO_FAR    24  

/* static Variables*/
static uint8_t ov3647_offset = 6;
static uint32_t ov3647_line=1574;
static uint16_t step_position_table[OV3647_TOTAL_STEPS_NEAR_TO_FAR+1];
static uint32_t current_r1_value = 0x1FF;
static uint8_t current_rd4_value = 0xFF;
static uint8_t current_r93_value = 0xFF;

enum ov3647_test_mode_t {
	TEST_OFF,
	TEST_1,
	TEST_2,
	TEST_3
};

enum ov3647_resolution_t {
	QTR_SIZE,
	FULL_SIZE,
	INVALID_SIZE
};


/*
 * Time in milisecs for waiting for the sensor to reset.
 */
#define OV3647_RESET_DELAY_MSECS   66

/* for 30 fps preview */
#define OV3647_DEFAULT_CLOCK_RATE  24000000




/* CAMIF output resolutions */
#define OV3647_FULL_WIDTH    2064
#define OV3647_FULL_HEIGHT   1544
#define OV3647_QTR_WIDTH    1032
#define OV3647_QTR_HEIGHT   772

#define OV3647_HRZ_FULL_BLK_PIXELS  300
#define OV3647_VER_FULL_BLK_LINES  30
#define OV3647_HRZ_QTR_BLK_PIXELS  828
#define OV3647_VER_QTR_BLK_LINES  217



/* FIXME: Changes from here */
struct ov3647_work_t {
	struct work_struct work;
};

static struct  ov3647_work_t *ov3647_sensorw;
static struct  i2c_client *ov3647_client;

struct ov3647_ctrl_t {
	struct  msm_camera_sensor_info *sensordata;

	enum sensor_mode_t sensormode;
	uint32_t fps_divider; 		/* init to 1 * 0x00000400 */
	uint32_t pict_fps_divider; 	/* init to 1 * 0x00000400 */
	uint16_t fps;

	uint16_t curr_lens_pos;
	uint16_t my_reg_gain;
	uint32_t my_reg_line_count;
	uint16_t total_lines_per_frame;

	enum ov3647_resolution_t prev_res;
	enum ov3647_resolution_t pict_res;
	enum ov3647_resolution_t curr_res;
	enum ov3647_test_mode_t  set_test;

	unsigned short imgaddr;
};


static struct ov3647_ctrl_t *ov3647_ctrl;
static DECLARE_WAIT_QUEUE_HEAD(ov3647_wait_queue);
DECLARE_MUTEX(ov3647_sem);

/*=============================================================*/

static int ov3647_i2c_rxdata(unsigned short saddr,
	unsigned char *rxdata, int length)
{
	struct i2c_msg msgs[] = {
	{
		.addr   = saddr,
		.flags = 0,
		.len   = 2,
		.buf   = rxdata,
	},
	{
		.addr  = saddr,
		.flags = I2C_M_RD,
		.len   = length,
		.buf   = rxdata,
	},
	};

	if (i2c_transfer(ov3647_client->adapter, msgs, 2) < 0) {
		CDBG("ov3647_i2c_rxdata failed!\n");
		return -EIO;
	}

	return 0;
}

static int32_t ov3647_i2c_read_b(unsigned short saddr, unsigned char 
raddr, unsigned short *rdata)
{
	int32_t rc = 0;
	if (!rdata)
		return -EIO;
	rc = ov3647_i2c_rxdata(saddr, &raddr, 1);
	if (rc < 0)
		return rc;
	*rdata = raddr;
	if (rc < 0)
		CDBG("ov3647_i2c_read_b failed!\n");
	return rc;
}

static int32_t ov3647_i2c_txdata(unsigned short saddr,
	unsigned char *txdata, int length)
{
	struct i2c_msg msg[] = {
	{
		.addr = saddr,
		.flags = 0,
		.len = length,
		.buf = txdata,
	},
	};

	if (i2c_transfer(ov3647_client->adapter, msg, 1) < 0) {
		CDBG("ov3647_i2c_txdata faild\n");
		return -EIO;
	}

	return 0;
}

static int32_t ov3647_i2c_write_b(unsigned short saddr,
	unsigned short waddr, unsigned short wdata)
{
	int32_t rc = -EFAULT;
	unsigned char buf[2];

	memset(buf, 0, sizeof(buf));
	buf[0] = waddr;
	buf[1] = wdata;
	rc = ov3647_i2c_txdata(saddr, buf, 2);

	if (rc < 0)
		CDBG("i2c_write failed, addr = 0x%x, val = 0x%x!\n",
		waddr, wdata);

	return rc;
}



static int32_t ov3647_set_default_focus(uint8_t af_step)
{
	int32_t rc = 0;
	uint8_t code_val_msb, code_val_lsb;
	code_val_msb = 0x00;
	code_val_lsb = 0x00;
	if (ov3647_i2c_write_b(OV3647_AF_I2C_ADDR>>1,
			code_val_msb, code_val_lsb) < 0)
			return rc;
	ov3647_ctrl->curr_lens_pos = 0;
	return rc;
	
}

static int32_t ov3647_move_focus(enum sensor_move_focus_t direction,
	int32_t num_steps)
{

	int32_t rc = 0;
	int16_t step_direction;
	int16_t next_position;
	int16_t next_step_position;
	int16_t time_wait_per_step;
	uint8_t code_val_msb, code_val_lsb;
	uint8_t ov3647_damping_us_per_step = 45; //111 DAC
	uint8_t ov3647_damping_threshold = 5;
	uint8_t ov3647_damping_mode = 0x2; // if ok, use smaller interval 
	uint8_t  ov3647_mode_mask = 0x02;

	if (direction == MOVE_NEAR)
	{
		step_direction = 1;   
	}
	else if (direction == MOVE_FAR)
	{
    	step_direction = -1;  
	}
	else
	{
		CDBG("Illegal focus direction!\n");
		return -EINVAL;;//CAMERA_INVALID_PARM;
	}
	next_step_position = ov3647_ctrl->curr_lens_pos + (step_direction * num_steps);

  	if (next_step_position < 0)
  	{
    	next_step_position = 0;
  	}
  	else if (next_step_position > OV3647_TOTAL_STEPS_NEAR_TO_FAR)
  	{
    	next_step_position = OV3647_TOTAL_STEPS_NEAR_TO_FAR;
  	}

  	if(next_step_position == ov3647_ctrl->curr_lens_pos)
  	{
    	return rc;
  	}
  
  	next_position = step_position_table[next_step_position];
  	time_wait_per_step = 5000 / (step_direction * (next_position - step_position_table[ov3647_ctrl->curr_lens_pos]));

  	if (time_wait_per_step >= 400) 
  	{
    	/* 400~ */
    	ov3647_mode_mask = 0x4;
  	}
  	else if (time_wait_per_step >= 200)
  	{
    	/* 200~400 */
    	ov3647_mode_mask = 0x3;
  	}
  	else if (time_wait_per_step >= 100)
  	{
   	 	/* 100~200 */
   	 	ov3647_mode_mask = 0x2;
  	}
  	else if (time_wait_per_step >= 50)
  	{
    	/* 50~100 */
    	ov3647_mode_mask = 0x1;
  	}
  	else if (step_direction == -1 && next_step_position <= ov3647_damping_threshold 
           && time_wait_per_step <= ov3647_damping_us_per_step) 
  	{
    	/* extra damping needed */
    	ov3647_mode_mask = ov3647_damping_mode;
  	}
  	else 
  	{
		ov3647_mode_mask = 0xB;
  	}

  code_val_msb = next_position >> 4;
  code_val_lsb = (next_position & 0x000F) << 4;
  code_val_lsb |= ov3647_mode_mask;

  if (ov3647_i2c_write_b(OV3647_AF_I2C_ADDR>>1,
		  code_val_msb, code_val_lsb) < 0)
		  return rc;


  //ov3647_current_lens_position = next_position;
  ov3647_ctrl->curr_lens_pos = next_step_position;
  return  rc;
}

static void ov3647_get_pict_fps(uint16_t fps, uint16_t *pfps)
{
	/* input fps is preview fps in Q8 format */

	uint32_t divider; 
	
	uint16_t snapshot_height, preview_height, preview_width,snapshot_width;

	if (ov3647_ctrl->prev_res == QTR_SIZE) {
		preview_width = OV3647_QTR_WIDTH  + OV3647_HRZ_QTR_BLK_PIXELS ;
		preview_height= OV3647_QTR_HEIGHT + OV3647_VER_QTR_BLK_LINES ;
	} 
	else {
		/* full size resolution used for preview. */
		preview_width = OV3647_FULL_WIDTH + OV3647_HRZ_FULL_BLK_PIXELS ;
		preview_height= OV3647_FULL_HEIGHT + OV3647_VER_FULL_BLK_LINES ;
	}
	if (ov3647_ctrl->pict_res == QTR_SIZE){
		snapshot_width  = OV3647_QTR_WIDTH + OV3647_HRZ_QTR_BLK_PIXELS ;
		snapshot_height = OV3647_QTR_HEIGHT + OV3647_VER_QTR_BLK_LINES ;
	} 
	else {
		snapshot_width  = OV3647_FULL_WIDTH + OV3647_HRZ_FULL_BLK_PIXELS;
		snapshot_height = OV3647_FULL_HEIGHT + OV3647_VER_FULL_BLK_LINES;
	}

  divider = (snapshot_height*snapshot_width)/
	       (preview_height*preview_width);

  *pfps = (uint16_t)((fps)/(divider));

 
}

static uint16_t ov3647_get_prev_lines_pf(void)
{
  if (ov3647_ctrl->pict_res == QTR_SIZE) {
	  return (OV3647_QTR_HEIGHT + OV3647_VER_QTR_BLK_LINES);
  } else  {
	  return (OV3647_FULL_HEIGHT + OV3647_VER_FULL_BLK_LINES);
  }
}

static uint16_t ov3647_get_prev_pixels_pl(void)
{
  if (ov3647_ctrl->pict_res == QTR_SIZE) {
	  return (OV3647_QTR_WIDTH + OV3647_HRZ_QTR_BLK_PIXELS);
  } else  {
	  return (OV3647_FULL_WIDTH + OV3647_HRZ_FULL_BLK_PIXELS);
  }
}

static uint16_t ov3647_get_pict_lines_pf(void)
{
  if (ov3647_ctrl->pict_res == QTR_SIZE) {
	  return (OV3647_QTR_HEIGHT + OV3647_VER_QTR_BLK_LINES);
  } else  {
	  return (OV3647_FULL_HEIGHT + OV3647_VER_FULL_BLK_LINES);
  }
}

static uint16_t ov3647_get_pict_pixels_pl(void)
{
  if (ov3647_ctrl->pict_res == QTR_SIZE) {
	  return (OV3647_QTR_WIDTH + OV3647_HRZ_QTR_BLK_PIXELS);
  } else  {
	  return (OV3647_FULL_WIDTH + OV3647_HRZ_FULL_BLK_PIXELS);
  }
}

static uint32_t ov3647_get_pict_max_exp_lc(void)
{
	if (ov3647_ctrl->pict_res == QTR_SIZE) {
		return (OV3647_QTR_HEIGHT + OV3647_VER_QTR_BLK_LINES);
	} else  {
		return (OV3647_FULL_HEIGHT + OV3647_VER_FULL_BLK_LINES);
	}
}

static int32_t ov3647_set_fps(struct fps_cfg	*fps)
{

	int32_t rc = 0;
	uint16_t total_lines_per_frame, preview_height;
	uint32_t fps_to_set;
	ov3647_ctrl->fps_divider = fps->fps_div;
	ov3647_ctrl->pict_fps_divider = fps->pict_fps_div;

	fps_to_set = fps->f_mult;

	if (ov3647_ctrl->prev_res == QTR_SIZE)
	{
		preview_height= OV3647_QTR_HEIGHT + OV3647_VER_QTR_BLK_LINES;
    }
    else
	{
		preview_height= OV3647_FULL_HEIGHT + OV3647_VER_FULL_BLK_LINES;
    }

    if (ov3647_ctrl->sensormode == SENSOR_SNAPSHOT_MODE)
    {
		total_lines_per_frame = (OV3647_FULL_HEIGHT + OV3647_VER_FULL_BLK_LINES)* ov3647_ctrl->pict_fps_divider / 0x400;
    }
    else
    {
		total_lines_per_frame = preview_height * ov3647_ctrl->fps_divider / 0x400;
    }

    if((ov3647_i2c_write_b(ov3647_client->addr,0x2A, (total_lines_per_frame & 0xFF00) >> 8)) < 0)
		return rc;
    if((ov3647_i2c_write_b(ov3647_client->addr,0x2B, (total_lines_per_frame & 0x00FF))) < 0)
		return rc;

	if ((fps_to_set * 10) == (75 * Q8))
    {
		/* update black level correction only when needed in preview at very low light 6.25fps */
		if((ov3647_i2c_write_b(ov3647_client->addr,0x67, 0x8c)) < 0)
		  return rc;
    }
    else
    {
      /* update black level correction every frame in preview at low light and normal light 25 fps and 12.5 fps */
      if((ov3647_i2c_write_b(ov3647_client->addr,0x67, 0xcc)) < 0)
		  return rc;
    }


	ov3647_ctrl->fps = fps_to_set;
	return rc; 
}



static int32_t ov3647_write_exp_gain(uint16_t gain, uint32_t line)
{
	int32_t rc = 0;
	uint16_t elc;
	uint16_t aec_msb;
	uint16_t aec_lsb;
	uint32_t r1_value = 0;
	uint8_t rd4_value = 0;
	uint8_t r93_value = 0;
	uint32_t local_total_lines_per_frame;

	elc = (uint16_t)line;

	if (ov3647_ctrl->sensormode != SENSOR_SNAPSHOT_MODE)
		elc = (uint32_t)( (elc * (ov3647_ctrl->fps_divider))/0x00000400);

	if (ov3647_ctrl->prev_res == QTR_SIZE)
		local_total_lines_per_frame = (OV3647_QTR_HEIGHT + OV3647_VER_QTR_BLK_LINES)*ov3647_ctrl->fps_divider / 0x00000400;
	else
		local_total_lines_per_frame = (OV3647_FULL_HEIGHT + OV3647_VER_FULL_BLK_LINES)*ov3647_ctrl->pict_fps_divider / 0x00000400;

	if(elc > (local_total_lines_per_frame - 6))
		elc = local_total_lines_per_frame - 6;
 
	if (ov3647_ctrl->sensormode != SENSOR_SNAPSHOT_MODE)
    {
		if (gain & 0x10)
		{
			rd4_value = 0x00;
		}
		else
		{
			rd4_value = 0x20;
		}

		if (gain & 0x20)
		{
			r93_value = 0x1E;
		}
		else
		{
			r93_value = 0x1F;
		}

		r1_value = ((gain & 0xC0) >> 2) | (gain  & 0xF);
		if (rd4_value != current_rd4_value)
		{
			if (ov3647_i2c_write_b(ov3647_client->addr,0xD4, rd4_value) < 0)
				return rc;
			current_rd4_value = rd4_value;
		}
		if (r93_value != current_r93_value)
		{
			if (ov3647_i2c_write_b(ov3647_client->addr,0x93, r93_value) < 0)
				return rc;
			current_r93_value = r93_value;
		}
   }/* endof if (ov3647_ctrl->sensormode != SENSOR_SNAPSHOT_MODE)*/
   else {
	   if (ov3647_i2c_write_b(ov3647_client->addr,OV3647_GAIN, (uint8_t)gain) < 0)
		   return rc;
		}

   aec_msb = (elc & 0xFF00) >> 8;
   aec_lsb = elc & 0x00FF;

   if (ov3647_ctrl->sensormode == SENSOR_SNAPSHOT_MODE)
   {
	   if (ov3647_i2c_write_b(ov3647_client->addr,OV3647_AEC_MSB, aec_msb) < 0)
		   return rc;
	   if (ov3647_i2c_write_b(ov3647_client->addr,OV3647_AEC_LSB, aec_lsb) < 0)
		   return rc;
   }
   else
   {
     if ((ov3647_line != elc) || (r1_value != current_r1_value))
     {
		 /* send expsoure in one packet */
		 if (ov3647_i2c_write_b(ov3647_client->addr,OV3647_GAIN, (uint8_t)r1_value) < 0)
			 return rc;
		 if (ov3647_i2c_write_b(ov3647_client->addr,OV3647_AEC_MSB, aec_msb) < 0)
			 return rc;
		 if (ov3647_i2c_write_b(ov3647_client->addr,OV3647_AEC_LSB, aec_lsb) < 0)
			 return rc;
		 /* update current r1 value;*/
		 current_r1_value = r1_value;
     }
   }

   ov3647_line = elc;
   return rc;
}/* endof ov3647_write_exp_gain*/

static int32_t ov3647_set_pict_exp_gain(uint16_t gain, uint32_t line)
{
	int32_t rc = 0;
	rc = ov3647_write_exp_gain(gain, line);
	return rc;
}/* endof ov3647_set_pict_exp_gain*/
static int32_t ov3647_test(enum ov3647_test_mode_t mo)
{
	int32_t rc = 0;

	if (mo == TEST_OFF)
		return 0;
	else {
		if (ov3647_i2c_write_b(ov3647_client->addr,0xc, 0x10) < 0) {
		  return rc;
		}
		if (ov3647_i2c_write_b(ov3647_client->addr,0xb2, 0x23) < 0) {
		  return rc;
		}
		if (ov3647_i2c_write_b(ov3647_client->addr,0x13, 0x0) < 0) {
		  return rc;
		}
		if (ov3647_i2c_write_b(ov3647_client->addr,0x1, 0x0) < 0) {
		  return rc;
		}
	}

}
static int32_t ov3647_setting(enum sensor_mode_t mode)
{
	int32_t   idx;
	int32_t rc = 0;
	switch (mode)
	{
		/* set sensor to quarter or full size dependent on camsensor_preview_resolution */
    case SENSOR_PREVIEW_MODE:
	      if ((ov3647_ctrl->prev_res == QTR_SIZE) &&
          (ov3647_ctrl->curr_res != QTR_SIZE))
		{
      
			  for (idx = 0; idx < sizeof(ov3647_init_qtr_settings)/sizeof(ov3647_config_struct_t); idx++)
			  {
				  if (ov3647_i2c_write_b(ov3647_client->addr,ov3647_init_qtr_settings[idx].reg,
                                        ov3647_init_qtr_settings[idx].val) < 0)
					  return rc;
			  }
			  ov3647_ctrl->curr_res = QTR_SIZE;
			  ov3647_ctrl->total_lines_per_frame = (OV3647_QTR_HEIGHT + OV3647_VER_QTR_BLK_LINES) * ov3647_ctrl->fps_divider / 0x400;
		
		  }
		  else if ((ov3647_ctrl->prev_res == FULL_SIZE) &&
               (ov3647_ctrl->curr_res != FULL_SIZE))
		  {
			  for (idx = 0; idx < sizeof(ov3647_init_qtr_settings)/sizeof(ov3647_config_struct_t); idx++)
			  {
				  if (ov3647_i2c_write_b(ov3647_client->addr,ov3647_init_qtr_settings[idx].reg,
                                        ov3647_init_qtr_settings[idx].val) < 0)
					  return rc;
			  }
			  for (idx = 0; idx < sizeof(ov3647_qtr_full_settings)/sizeof(ov3647_config_struct_t); idx++)
			  {
				  if (ov3647_i2c_write_b(ov3647_client->addr,ov3647_qtr_full_settings[idx].reg,
                                        ov3647_qtr_full_settings[idx].val) < 0)
					  return rc;
			
			  }

			  ov3647_ctrl->curr_res  = FULL_SIZE;
			  ov3647_ctrl->total_lines_per_frame = (OV3647_FULL_HEIGHT + OV3647_VER_FULL_BLK_LINES) * ov3647_ctrl->pict_fps_divider / 0x400;
		  }
		  else
		  {
			  for (idx = 0; idx < sizeof(ov3647_init_qtr_settings)/sizeof(ov3647_config_struct_t); idx++)
			  {
				  if (ov3647_i2c_write_b(ov3647_client->addr,ov3647_init_qtr_settings[idx].reg,
                                        ov3647_init_qtr_settings[idx].val) < 0)
					  return rc;
			  }

			  ov3647_ctrl->total_lines_per_frame = (OV3647_QTR_HEIGHT + OV3647_VER_QTR_BLK_LINES) * ov3647_ctrl->fps_divider / 0x400;
			  ov3647_ctrl->curr_res  = QTR_SIZE;
		  }
		  break;

    // set sensor to full size
	case SENSOR_SNAPSHOT_MODE:
		for (idx = 0; idx < sizeof(ov3647_init_qtr_settings)/sizeof(ov3647_config_struct_t); idx++)
		{
			if (ov3647_i2c_write_b(ov3647_client->addr,ov3647_init_qtr_settings[idx].reg,
                                        ov3647_init_qtr_settings[idx].val) < 0)
				return rc;
		}
		for (idx = 0; idx < sizeof(ov3647_qtr_full_settings)/sizeof(ov3647_config_struct_t); idx++)
		{
			if (ov3647_i2c_write_b(ov3647_client->addr,ov3647_qtr_full_settings[idx].reg,
                                        ov3647_qtr_full_settings[idx].val) < 0)
				return rc;
		}
		ov3647_ctrl->curr_res  = FULL_SIZE;
		ov3647_ctrl->total_lines_per_frame = (OV3647_FULL_HEIGHT + OV3647_VER_FULL_BLK_LINES) * ov3647_ctrl->pict_fps_divider / 0x400;

      break;
	

	default:
		rc = -EFAULT;
		break;
	}/* endof switch(mode) */

	ov3647_i2c_write_b(ov3647_client->addr,0x2A,((ov3647_ctrl->total_lines_per_frame & 0xFF00) >> 8));
	ov3647_i2c_write_b(ov3647_client->addr,0x2B,(ov3647_ctrl->total_lines_per_frame & 0x00FF));

	if (ov3647_test(ov3647_ctrl->set_test) < 0)
		return rc;
	//mdelay((Q8 * 1000)/ov3647_ctrl->fps);

	current_r1_value = 0x1FF;
	current_rd4_value = 0xFF;
	current_r93_value = 0xFF;
	CDBG("ov3647_setting finishes\n");
	return rc;
} /*endof  ov3647_setting*/


static int32_t ov3647_video_config(enum sensor_mode_t mode)
{
	int32_t rc = 0;
	ov3647_ctrl->sensormode = mode;
	if( (ov3647_ctrl->curr_res != ov3647_ctrl->prev_res) && (!ov3647_setting(SENSOR_PREVIEW_MODE))  )	
		return rc;
	else {
		 ov3647_ctrl->curr_res = ov3647_ctrl->prev_res;
		}
}/*end of ov354_video_config*/

static int32_t ov3647_snapshot_config(enum sensor_mode_t mode)
{
	int32_t rc = 0;
	ov3647_ctrl->sensormode = mode;

	 if ( (ov3647_ctrl->curr_res != ov3647_ctrl->pict_res) && (!ov3647_setting(SENSOR_SNAPSHOT_MODE)) ) 	
			return rc;
	 else {
		 ov3647_ctrl->curr_res = ov3647_ctrl->pict_res;
		}
 }/*end of ov3647_snapshot_config*/

static int32_t ov3647_raw_snapshot_config(enum sensor_mode_t mode)
{
	int32_t rc = 0;
	ov3647_ctrl->sensormode = mode;
	if ( (ov3647_ctrl->curr_res != ov3647_ctrl->pict_res) && (!ov3647_setting(SENSOR_SNAPSHOT_MODE)) ) 	
	{
		return rc;
	}
	else {
		ov3647_ctrl->curr_res = ov3647_ctrl->pict_res;
	}/* Update sensor resolution */

}/*end of ov3647_raw_snapshot_config*/

static int32_t ov3647_power_down(void)
{
	return 0;
}



static int ov3647_sensor_init_done(struct msm_camera_sensor_info *data)
{
	gpio_direction_output(data->sensor_reset, 0);
	gpio_free(data->sensor_reset);
	return 0;
}

static int ov3647_probe_init_sensor(struct msm_camera_sensor_info *data)
{
	int32_t rc = 0;
	unsigned short chipidl, chipidh;

	rc = gpio_request(data->sensor_reset, "ov3647");
	if (!rc)
		gpio_direction_output(data->sensor_reset, 1);
	else
		goto init_probe_done;

	mdelay(20);

	/* 3. Read sensor Model ID: */
	if (ov3647_i2c_read_b(ov3647_client->addr,
		OV3647_PIDH_REG, &chipidh) < 0)
		goto init_probe_fail;

    if (ov3647_i2c_read_b(ov3647_client->addr,
		OV3647_PIDL_REG, &chipidl) < 0)
		goto init_probe_fail;

	CDBG("ov3647 model_id = 0x%x  0x%x\n", chipidh, chipidl);

	/* 4. Compare sensor ID to OV3647 ID: */
	if (chipidh != OV3647_PID || chipidl < OV3647_VER) {
		rc = -ENODEV;
		goto init_probe_fail;
	}

	mdelay(OV3647_RESET_DELAY_MSECS);

  goto init_probe_done;

init_probe_fail:
	gpio_direction_output(data->sensor_reset, 0);
	gpio_free(data->sensor_reset);
init_probe_done:
	CDBG(" ov3647_probe_init_sensor finishes\n");
	return rc;
}

int ov3647_sensor_open_init(struct msm_camera_sensor_info *data)
{

	CDBG("Calling ov3647_sensor_open_init\n");
	int32_t  rc;
	int i;
	uint16_t ov3647_nl_region_boundary1 = 3;
	uint16_t ov3647_nl_region_code_per_step1 = 60;  //10 bit
	uint16_t ov3647_nl_region_boundary2 = 5;
	uint16_t ov3647_nl_region_code_per_step2 = 32;   //10 bit
	uint16_t ov3647_l_region_code_per_step = 22;


	ov3647_ctrl = kzalloc(sizeof(struct ov3647_ctrl_t), GFP_KERNEL);
	if (!ov3647_ctrl) {
		CDBG("ov3647_init failed!\n");
		rc = -ENOMEM;
		goto init_done;
	}

	ov3647_ctrl->fps_divider = 1 * 0x00000400;
	ov3647_ctrl->pict_fps_divider = 1 * 0x00000400;
	ov3647_ctrl->set_test = TEST_OFF;
	ov3647_ctrl->prev_res = QTR_SIZE;
	ov3647_ctrl->pict_res = FULL_SIZE;
	ov3647_ctrl->curr_res = INVALID_SIZE;
	ov3647_ctrl->total_lines_per_frame = 989;
	if (data)
		ov3647_ctrl->sensordata = data;

	/* enable mclk first */
	msm_camio_clk_rate_set(OV3647_DEFAULT_CLOCK_RATE);
	mdelay(20);

	msm_camio_camif_pad_reg_reset();
	mdelay(20);

	rc = ov3647_probe_init_sensor(data);
	if (rc < 0)
		goto init_fail;
	
	if (ov3647_ctrl->prev_res == QTR_SIZE)
		rc = ov3647_setting(SENSOR_PREVIEW_MODE);
	else
		rc = ov3647_setting(SENSOR_SNAPSHOT_MODE);
		
	ov3647_ctrl->fps = 30*Q8;
	ov3647_ctrl->total_lines_per_frame = 989; //788;
	ov3647_line=1574;
	
	step_position_table[0] = 0;
	for(i=1; i <= OV3647_TOTAL_STEPS_NEAR_TO_FAR; i++)
	{
		if ( i <= ov3647_nl_region_boundary1)
		{
			step_position_table[i] = step_position_table[i-1] + ov3647_nl_region_code_per_step1;
		}
		else if ( i <= ov3647_nl_region_boundary2)
		{
			step_position_table[i] = step_position_table[i-1] + ov3647_nl_region_code_per_step2;
		}
		else
		{
			step_position_table[i] = step_position_table[i-1] + ov3647_l_region_code_per_step;
		}
	}
	 /* generate test pattern */
	if (ov3647_test(ov3647_ctrl->set_test) < 0)
			return rc;

	if (rc < 0)
		
		goto init_fail;
	else
		goto init_done;
	    /* reset the driver state */
		init_fail:
			CDBG(" init_fail \n");
			kfree(ov3647_ctrl);
		init_done:
			CDBG("init_done \n");
			return rc;
}/*endof ov3647_sensor_open_init*/

static int ov3647_init_client(struct i2c_client *client)
{
	/* Initialize the MSM_CAMI2C Chip */
	init_waitqueue_head(&ov3647_wait_queue);
	return 0;
}


static int32_t ov3647_set_sensor_mode(enum sensor_mode_t mode,
	enum sensor_resolution_t res)
{
	int32_t rc = 0;

	switch (mode) {
	case SENSOR_PREVIEW_MODE:
		rc = ov3647_video_config(mode);
		break;

	case SENSOR_SNAPSHOT_MODE:
		rc = ov3647_snapshot_config(mode);
		break;

	case SENSOR_RAW_SNAPSHOT_MODE:
		rc = ov3647_raw_snapshot_config(mode);
		break;
				
	default:
		rc = -EINVAL;
		break;
	}
	return rc;
}

int ov3647_sensor_config(void __user *argp)
{
	struct sensor_cfg_data_t cdata;
	long   rc = 0;

	if (copy_from_user(&cdata,
				(void *)argp,
				sizeof(struct sensor_cfg_data_t)))
		return -EFAULT;

	down(&ov3647_sem);

  CDBG("ov3647_sensor_config: cfgtype = %d\n",
	  cdata.cfgtype);
		switch (cdata.cfgtype) {
		case CFG_GET_PICT_FPS:
				ov3647_get_pict_fps(
				cdata.cfg.gfps.prevfps,
				&(cdata.cfg.gfps.pictfps));

			if (copy_to_user((void *)argp,
				&cdata,
				sizeof(struct sensor_cfg_data_t)))
				rc = -EFAULT;
			break;

		case CFG_GET_PREV_L_PF:
			cdata.cfg.prevl_pf =
			ov3647_get_prev_lines_pf();

			if (copy_to_user((void *)argp,
				&cdata,
				sizeof(struct sensor_cfg_data_t)))
				rc = -EFAULT;
			break;

		case CFG_GET_PREV_P_PL:
			cdata.cfg.prevp_pl =
				ov3647_get_prev_pixels_pl();

			if (copy_to_user((void *)argp,
				&cdata,
				sizeof(struct sensor_cfg_data_t)))
				rc = -EFAULT;
			break;

		case CFG_GET_PICT_L_PF:
			cdata.cfg.pictl_pf =
				ov3647_get_pict_lines_pf();

			if (copy_to_user((void *)argp,
				&cdata,
				sizeof(struct sensor_cfg_data_t)))
				rc = -EFAULT;
			break;

		case CFG_GET_PICT_P_PL:
			cdata.cfg.pictp_pl =
				ov3647_get_pict_pixels_pl();

			if (copy_to_user((void *)argp,
				&cdata,
				sizeof(struct sensor_cfg_data_t)))
				rc = -EFAULT;
			break;

		case CFG_GET_PICT_MAX_EXP_LC:
			cdata.cfg.pict_max_exp_lc =
				ov3647_get_pict_max_exp_lc();

			if (copy_to_user((void *)argp,
				&cdata,
				sizeof(struct sensor_cfg_data_t)))
				rc = -EFAULT;
			break;

		case CFG_SET_FPS:
		case CFG_SET_PICT_FPS:
			rc = ov3647_set_fps(&(cdata.cfg.fps));
			break;

		case CFG_SET_EXP_GAIN:
			rc =
				ov3647_write_exp_gain(
					cdata.cfg.exp_gain.gain,
					cdata.cfg.exp_gain.line);
			break;

		case CFG_SET_PICT_EXP_GAIN:
			rc =
				ov3647_set_pict_exp_gain(
					cdata.cfg.exp_gain.gain,
					cdata.cfg.exp_gain.line);
			break;

		case CFG_SET_MODE:
			rc = ov3647_set_sensor_mode(cdata.mode,
						cdata.rs);
			break;

		case CFG_PWR_DOWN:
			rc = ov3647_power_down();
			break;

		case CFG_MOVE_FOCUS:
			rc =
				ov3647_move_focus(
					cdata.cfg.focus.dir,
					cdata.cfg.focus.steps);
			break;

		case CFG_SET_DEFAULT_FOCUS:
			rc =
				ov3647_set_default_focus(
					cdata.cfg.focus.steps);
			break;

		case CFG_SET_EFFECT:
			rc = ov3647_set_default_focus(
						cdata.cfg.effect);
			break;

		default:
			rc = -EFAULT;
			break;
		}

	up(&ov3647_sem);

	return rc;
}

int ov3647_sensor_release(void)
{
	int rc = -EBADF;

	down(&ov3647_sem);

	ov3647_power_down();

	gpio_direction_output(ov3647_ctrl->sensordata->sensor_reset,
			0);
	gpio_free(ov3647_ctrl->sensordata->sensor_reset);

	kfree(ov3647_ctrl);

	up(&ov3647_sem);
	CDBG("ov3647_release completed!\n");
	return rc;
}

static int ov3647_probe(struct i2c_client *client,
	const struct i2c_device_id *id)
{
	int rc = 0;
	if (!i2c_check_functionality(client->adapter, I2C_FUNC_I2C)) {
		rc = -ENOTSUPP;
		goto probe_failure;
	}

	ov3647_sensorw =
		kzalloc(sizeof(struct ov3647_work_t), GFP_KERNEL);

	if (!ov3647_sensorw) {
		rc = -ENOMEM;
		goto probe_failure;
	}

	i2c_set_clientdata(client, ov3647_sensorw);
	ov3647_init_client(client);
	ov3647_client = client;
	ov3647_client->addr = ov3647_client->addr >> 1;
	mdelay(50);

	return 0;

probe_failure:
	kfree(ov3647_sensorw);
	ov3647_sensorw = NULL;
	return rc;
}

static int __exit ov3647_remove(struct i2c_client *client)
{
	struct ov3647_work_t *sensorw = i2c_get_clientdata(client);
	free_irq(client->irq, sensorw);
	ov3647_client = NULL;
	kfree(sensorw);
	return 0;
}

static const struct i2c_device_id ov3647_id[] = {
	{ "ov3647", 0},
	{ }
};

static struct i2c_driver ov3647_driver = {
	.id_table = ov3647_id,
	.probe  = ov3647_probe,
	.remove = __exit_p(ov3647_remove),
	.driver = {
		.name = "ov3647",
	},
};

static int32_t ov3647_init(void)
{
	int32_t rc = 0;

	rc = i2c_add_driver(&ov3647_driver);
	if (IS_ERR_VALUE(rc))
		goto init_failure;
	return rc;

init_failure:
	CDBG("ov3647_init failed\n");
	return rc;
}

void ov3647_exit(void)
{
	i2c_del_driver(&ov3647_driver);
}

int ov3647_probe_init(void *dev, void *ctrl)
{
	CDBG("ov3647_probe_init called\n");
	int rc = 0;
	struct msm_camera_sensor_info *info =
		(struct msm_camera_sensor_info *)dev;

	struct msm_sensor_ctrl_t *s = (struct msm_sensor_ctrl_t *)ctrl;
	rc = ov3647_init();
	if (rc < 0)
		goto probe_done;

	/* enable mclk first */
	msm_camio_clk_rate_set(OV3647_DEFAULT_CLOCK_RATE);
	mdelay(20);

	rc = ov3647_probe_init_sensor(info);
	if (rc < 0)
		goto probe_done;
	s->s_init = ov3647_sensor_open_init;
	s->s_release = ov3647_sensor_release;
	s->s_config  = ov3647_sensor_config;
	ov3647_sensor_init_done(info);
	CDBG("ov3647_probe_init done\n");
probe_done:
	return rc;
}

