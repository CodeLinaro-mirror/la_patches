Apply the following two patches in this order:
0001-msm-pm8058-pm8901-Change-regulator-settings-before-s.patch
0001-mfd-pmic8058-disable-SMPL-in-SLEEP_CNTL-register-for.patch
