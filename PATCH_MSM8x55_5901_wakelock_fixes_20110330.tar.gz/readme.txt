Please apply patches in the following order:
1) 0001-wait-Add-wait_io_event_interruptible-and-friends.patch
2) 0002-wait_event_interruptible_timeout-when-waiting-on-the.patch
3) 0001-msm-kgsl-add-wakelock-while-gpu-is-busy.patch
