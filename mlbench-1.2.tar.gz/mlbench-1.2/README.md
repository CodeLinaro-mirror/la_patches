# ML-Bench
***a versatile and scalable machine-learning benchmark***

## Prerequisites

### gemmlowp

Download gemmlowp such that the following directory is available during build

    third_party/gemmlowp

### Compilation

Run

    make


#### Cross-compiler Prefix

By default, the compiler used is ```g++```. However, while running ```make```, the environment variable ```CROSS_PREFIX``` could be set to to use a different compiler

## How to run
    ml_bench -i models/network.txt -n 5


    -i <network model descriptor; required parameter>
    -n <iterations; optional parameter, default value 1>
    -o <output_file; optional parameter for dumping o/p of final layer>

## Testing ml-bench

### run LeNet model on MNIST database

go to ```tests/mnist``` and run the following scripts

    ./scripts/fetch_mnist.sh # fetch the mnist database
    ./scripts/process_mnist.py # process the raw images
    ./scripts/run_mlbench.sh # run the images through mlbench; output shown on stdout

**NOTE**

If you have a pre-trained LeNet caffe model and wish to use that, then you can refer to [this document](tests/mnist/README.md)

## Input file format

Each input file is a binary file that is a collection of the following struct

    {
        float delta;
        int offset;
        int num_bytes;
        unsigned char data[];
    }

Each such struct is placed at a 16-byte aligned offset in the binary file.

**NOTE** The first three members of the struct are of size 4 bytes each, so apart from the char[] array, each tensor will have 12 additional bytes

One can use the ```scripts/bin_generator.py``` script to generate a binary file.

The input file to the above script should contain the data tensors in the following example format

    # example tensor for mlbench
    tensor
    delta=0.00024023080865542094
    offset=149
    bufsize=64
    159
    109
    137
    175
    ...

Lines starting with ```#``` are ignored

The tensors expected by the different layers(in order) are as follows-

| Layer                         | Tensors              |
|-------------------------------|----------------------|
| convolution                   | weight, bias, output |
| fully-connected/inner-product | weight, bias, output |
| softmax                       | output               |
| relu                          | output               |
| pool                          | output               |

**NOTE** : output tensors are expected to have a bufsize of 0

Multiple tensors can be placed into the same input file and the ```bin_generator.py``` script will encode and place each of them at a 16-byte aligned offset in order. Care must be taken to provide the correct offset in the network-descriptor file.

