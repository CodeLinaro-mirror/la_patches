/*
 *    Copyright (c) 2018, The Linux Foundation. All rights reserved.
 *
 *    Redistribution and use in source and binary forms, with or without
 *    modification, are permitted provided that the following conditions are
 *    met:
 *        * Redistributions of source code must retain the above copyright
 *          notice, this list of conditions and the following disclaimer.
 *        * Redistributions in binary form must reproduce the above
 *          copyright notice, this list of conditions and the following
 *          disclaimer in the documentation and/or other materials provided
 *          with the distribution.
 *        * Neither the name of The Linux Foundation nor the names of its
 *          contributors may be used to endorse or promote products derived
 *          from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED
 *    WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT
 *    ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 *    CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 *    SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 *    BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 *    OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
 *    IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include <cstddef>
#include <string>
#include <vector>
#include <iostream>
#include "ForwardPassOp.h"
#include "OpConv.h"
#include "OpPool.h"
#include "OpFcnn.h"
#include "OpSoftmax.h"
#include "OpRelu.h"
#include "../utils/StringUtils.h"


void ForwardPassOp::getDimVec(std::vector<std::string> v) {
    std::string sizeStr = StringUtils::getSizeStr(v);
    for(size_t i = 0; i < StringUtils::getNumDimsFromSizeStr(sizeStr); i++) {
        dimVec.push_back(StringUtils::getDimNFromSizeStr(i, sizeStr, PO_HWCN));
    }
}

void ForwardPassOp::getStrideVec(std::vector<std::string> v) {
    std::string sizeStr = StringUtils::getStrideStr(v);
    for(size_t i = 0; i < StringUtils::getNumStridesFromSizeStr(sizeStr); i++) {
        strideVec.push_back(StringUtils::getStrideNFromSizeStr(i, sizeStr, PO_HWCN));
    }
}

ForwardPassOp* ForwardPassOp::Create(OpType type, std::vector<std::string> params) {
    if (type == OT_Conv)
        return new OpConv(params);
    else if (type == OT_Pool)
        return new OpPool(params);
    else if (type == OT_Fcnn)
        return new OpFcnn(params);
    else if (type == OT_Softmax)
        return new OpSoftmax(params);
    else if (type == OT_Relu)
        return new OpRelu(params);
    else return nullptr;
}

ForwardPassOp::~ForwardPassOp() = default;

void ForwardPassOp::randomize() {
}

void ForwardPassOp::forwardPropagate(std::shared_ptr<Tensor> inTensor, std::shared_ptr<Tensor> outTensor) {
}

void ForwardPassOp::allocMem(std::shared_ptr<Tensor> inTensor, std::shared_ptr<Tensor> outTensor){
}

void ForwardPassOp::setVerbose(int v) {
    verbose = v;
}

void ForwardPassOp::populateFromFile(std::string s, int i) {
}

void ForwardPassOp::delayedInit(PopulateMode, std::shared_ptr<Tensor> outTensor) {
}
