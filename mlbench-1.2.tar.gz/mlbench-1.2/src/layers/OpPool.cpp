/*
 *    Copyright (c) 2018, The Linux Foundation. All rights reserved.
 *
 *    Redistribution and use in source and binary forms, with or without
 *    modification, are permitted provided that the following conditions are
 *    met:
 *        * Redistributions of source code must retain the above copyright
 *          notice, this list of conditions and the following disclaimer.
 *        * Redistributions in binary form must reproduce the above
 *          copyright notice, this list of conditions and the following
 *          disclaimer in the documentation and/or other materials provided
 *          with the distribution.
 *        * Neither the name of The Linux Foundation nor the names of its
 *          contributors may be used to endorse or promote products derived
 *          from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED
 *    WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT
 *    ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 *    CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 *    SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 *    BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 *    OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
 *    IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include <iostream>
#include <cassert>
#include <algorithm>
#include <numeric>
#include <climits>
#include <cmath>
#include "OpPool.h"

#ifndef OP_POOL_ASSERTS
#define OP_POOL_ASSERTS 0
#endif

OpPool::~OpPool() = default;

OpPool::OpPool(std::vector<std::string> s) {
    getDimVec(s);
    sizeH = dimVec[0];
    sizeW = dimVec[1];
    getStrideVec(s);
    getPoolType(s);
    if (poolType == PT_None) {
        std::cerr << "Pool type is not supported" << std::endl;
        assert(false);
    }
}

void OpPool::forwardPropagate(std::shared_ptr<Tensor> inTensor, std::shared_ptr<Tensor> outTensor) {
    size_t numCols = inTensor->dimVec[2];
#if OP_POOL_ASSERTS
    assert(numCols == outTensor->dimVec[2]);
#endif
    size_t inputHeight = inTensor->dimVec[0];
    size_t outputHeight = outTensor->dimVec[0];
#if OP_POOL_ASSERTS
    assert (outputHeight == (inputHeight/strideVec[0]));
#endif
    size_t inputWidth = inTensor->dimVec[1];
    size_t outputWidth = outTensor->dimVec[1];
#if OP_POOL_ASSERTS
    assert (outputWidth == (inputWidth/strideVec[1]));
#endif
    std::vector<unsigned char> poolVec(sizeH * sizeW);
    float pooledValF = 0.0f;
    float deltaFactor = inTensor->delta/outTensor->delta;
    int poolVecItr = 0;
    unsigned char pooledVal = 0;
    size_t input_H_Start, input_W_Start, input_H_Stop, input_W_Stop, outputOffset;
    for (size_t C = 0; C < numCols; ++C) {
        for (size_t H = 0; H < outputHeight; ++H) {
            for (size_t W = 0; W < outputWidth; ++W) {
                input_H_Start = H*strideVec[0];
                input_W_Start = W*strideVec[1];
                input_H_Stop = input_H_Start + sizeH;
                input_W_Stop = input_W_Start + sizeW;
                poolVecItr = 0;
                for (size_t IH = input_H_Start; IH < input_H_Stop; ++IH) {
                    for (size_t IW = input_W_Start; IW < input_W_Stop; ++IW) {
                        poolVec[poolVecItr++] = ((*(inTensor->byteVec))[C*inputWidth*inputHeight + IH*(inputWidth) + IW]);
                    }
                }
                if (poolType == PT_MaxPool) {
                    pooledValF = *std::max_element(std::begin(poolVec), std::end(poolVec));
                }
                else if (poolType == PT_AvgPool) {
                    pooledValF = std::accumulate(poolVec.begin(), poolVec.end(), 0.0f) / poolVec.size();
                }
                outputOffset = C*outputHeight*outputWidth + H*outputWidth + W;
                pooledValF = (deltaFactor*(pooledValF-inTensor->offset))+outTensor->offset;
                pooledValF = std::min(pooledValF, 255.0f);
                pooledValF = std::max(pooledValF, 0.0f);
                pooledVal = static_cast<unsigned char>(roundf(pooledValF));
                (*(outTensor->byteVec))[outputOffset] = pooledVal;
            }
        }
    }
    if (verbose) {
        std::cout << "OpPool: " << std::endl;
        std::cout << "Input Tensor:" << std::endl;
        inTensor->print();
        std::cout << "Output Tensor:" << std::endl;
        outTensor->print();
    }
}

void OpPool::getPoolType(std::vector<std::string> v) {
    std::string key = "pool_type:";
    std::string sizeStr;
    for (std::string s : v) {
        if (s.find(key) != std::string::npos) {
            sizeStr = s.erase(0, key.length());
        }
    }
    if (sizeStr.find("max") != std::string::npos)
        poolType = PT_MaxPool;
    else if (sizeStr.find("avg") != std::string::npos)
        poolType = PT_AvgPool;
    else
        poolType = PT_None;
}

void OpPool::populateFromFile(std::string initFileName, int initFileOffset) {
    delayedInitParams = std::make_shared<Tensor>(std::vector<size_t >{1});
    delayedInitParams->populateFromFile(initFileName, initFileOffset, true);
}

void OpPool::delayedInit(PopulateMode populateMode, std::shared_ptr<Tensor> t) {
    if (populateMode == PopulateMode::PM_File) {
        t->delta = delayedInitParams->delta;
        t->offset = delayedInitParams->offset;
    }
}

