/*
 *    Copyright (c) 2018, The Linux Foundation. All rights reserved.
 *
 *    Redistribution and use in source and binary forms, with or without
 *    modification, are permitted provided that the following conditions are
 *    met:
 *        * Redistributions of source code must retain the above copyright
 *          notice, this list of conditions and the following disclaimer.
 *        * Redistributions in binary form must reproduce the above
 *          copyright notice, this list of conditions and the following
 *          disclaimer in the documentation and/or other materials provided
 *          with the distribution.
 *        * Neither the name of The Linux Foundation nor the names of its
 *          contributors may be used to endorse or promote products derived
 *          from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED
 *    WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT
 *    ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 *    CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 *    SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 *    BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 *    OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
 *    IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include <iostream>
#include "OpFcnn.h"
#include "../network/GraphNode.h"

OpFcnn::~OpFcnn() = default;

OpFcnn::OpFcnn(std::vector<std::string> v) {
    getDimVec(v);
    weight = std::make_shared<Tensor>(dimVec);
    bias = std::make_shared<Tensor>(std::vector<size_t>{dimVec[1]});
}

void OpFcnn::forwardPropagate(std::shared_ptr<Tensor> inTensor, std::shared_ptr<Tensor> outTensor) {
    kernels::GEMM_MAT inputGemmMat;
    if (inTensor->dimVec.size() == 3)
        inputGemmMat = inTensor->getGemmMat(FlattenMode::FM_3D_to_ColVec);
    else {
        inputGemmMat = inTensor->getGemmMat();
        std::cerr << "Unexpected tensor size " << inTensor->dimVec.size() << std::endl;
    }
    kernels::GEMM_MAT weightGemmMat = weight->getGemmMat(FlattenMode::FM_2D_CR);
    kernels::GEMM_MAT outputGemmMat = outTensor->getGemmMat(FlattenMode::FM_3D_to_ColVec, kernels::BIAS_ADD::COLUMN);
    kernels::GEMM_MAT biasGemmMat = bias->getGemmMat(FlattenMode::FM_3D_to_ColVec);
    kernels::low_precision_matrix_multiply(weightGemmMat, inputGemmMat, biasGemmMat, outputGemmMat);
    if (verbose) {
        std::cout << "OpFcnn: " << std::endl;
        std::cout << "Weight Tensor:" << std::endl;
        weight->print();
        std::cout << "Bias Tensor:" << std::endl;
        bias->print();
        std::cout << "Input Tensor:" << std::endl;
        inTensor->print();
        std::cout << "Output Tensor:" << std::endl;
        outTensor->print();
    }
}

void OpFcnn::randomize() {
    weight->randomize();
    bias->randomize();
}

void OpFcnn::populateFromFile(std::string initFileName, int initFileOffset) {
    weight->populateFromFile(initFileName, initFileOffset);
    initFileOffset += 12;
    initFileOffset += weight->numBytes;
    initFileOffset = Tensor::roundToNext16(initFileOffset);
    bias->populateFromFile(initFileName, initFileOffset);
    initFileOffset += 12;
    initFileOffset += bias->numBytes;
    initFileOffset = Tensor::roundToNext16(initFileOffset);
    delayedInitParams = std::make_shared<Tensor>(std::vector<size_t >{1});
    delayedInitParams->populateFromFile(initFileName, initFileOffset, true);
}

void OpFcnn::delayedInit(PopulateMode populateMode, std::shared_ptr<Tensor> t) {
    if (populateMode == PopulateMode::PM_File) {
        t->delta = delayedInitParams->delta;
        t->offset = delayedInitParams->offset;
    }
}

