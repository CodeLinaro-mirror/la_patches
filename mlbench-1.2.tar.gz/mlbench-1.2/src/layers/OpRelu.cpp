/*
 *    Copyright (c) 2018, The Linux Foundation. All rights reserved.
 *
 *    Redistribution and use in source and binary forms, with or without
 *    modification, are permitted provided that the following conditions are
 *    met:
 *        * Redistributions of source code must retain the above copyright
 *          notice, this list of conditions and the following disclaimer.
 *        * Redistributions in binary form must reproduce the above
 *          copyright notice, this list of conditions and the following
 *          disclaimer in the documentation and/or other materials provided
 *          with the distribution.
 *        * Neither the name of The Linux Foundation nor the names of its
 *          contributors may be used to endorse or promote products derived
 *          from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED
 *    WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT
 *    ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 *    CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 *    SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 *    BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 *    OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
 *    IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include <cstddef>
#include <iostream>
#include <cassert>
#include <cmath>
#include "OpRelu.h"
#include "../utils/StringUtils.h"

#ifndef OP_RELU_ASSERTS
#define OP_RELU_ASSERTS 1
#endif

OpRelu::OpRelu(std::vector<std::string> v) {
    getMin(v);
    getMax(v);
}

OpRelu::~OpRelu() = default;

void OpRelu::getMin(std::vector<std::string> v) {
    std::string key = "min:";
    std::string sizeStr;
    for (std::string s : v) {
        if (s.find(key) != std::string::npos) {
            sizeStr = s.erase(0, key.length());
        }
    }
    reluMin = StringUtils::StringToFloat(sizeStr);
}

void OpRelu::getMax(std::vector<std::string> v) {
    std::string key = "max:";
    std::string sizeStr;
    for (std::string s : v) {
        if (s.find(key) != std::string::npos) {
            sizeStr = s.erase(0, key.length());
        }
    }
    reluMax = StringUtils::StringToFloat(sizeStr);
}

void OpRelu::forwardPropagate(std::shared_ptr<Tensor> inTensor, std::shared_ptr<Tensor> outTensor) {
    float f;
    unsigned char c;
#if OP_RELU_ASSERTS
    assert (inTensor->dimVec.size() == outTensor->dimVec.size());
    for (size_t i = 0; i < inTensor->dimVec.size(); ++i) {
        assert(inTensor->dimVec[i] == outTensor->dimVec[i]);
    }
#endif
    for (size_t i = 0; i < inTensor->numBytes; ++i) {
        f = ((inTensor->delta) * ((*(inTensor->byteVec))[i] - (inTensor->offset)));
        f = std::max(reluMin, std::min(reluMax, f));
        c = static_cast<unsigned char>(roundf((f / (outTensor->delta)) + outTensor->offset));
        (*(outTensor->byteVec))[i] = c;
    }
    if (verbose) {
        std::cout << "OpRelu: " << std::endl;
        std::cout << "Input Tensor:" << std::endl;
        inTensor->print();
        std::cout << "Output Tensor:" << std::endl;
        outTensor->print();
    }
}

void OpRelu::populateFromFile(std::string initFileName, int initFileOffset) {
    delayedInitParams = std::make_shared<Tensor>(std::vector<size_t >{1});
    delayedInitParams->populateFromFile(initFileName, initFileOffset, true);
}

void OpRelu::delayedInit(PopulateMode populateMode, std::shared_ptr<Tensor> t) {
    if (populateMode == PopulateMode::PM_File) {
        t->delta = delayedInitParams->delta;
        t->offset = delayedInitParams->offset;
    }
}

