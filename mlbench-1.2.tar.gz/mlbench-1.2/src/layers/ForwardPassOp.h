/*
 *    Copyright (c) 2018, The Linux Foundation. All rights reserved.
 *
 *    Redistribution and use in source and binary forms, with or without
 *    modification, are permitted provided that the following conditions are
 *    met:
 *        * Redistributions of source code must retain the above copyright
 *          notice, this list of conditions and the following disclaimer.
 *        * Redistributions in binary form must reproduce the above
 *          copyright notice, this list of conditions and the following
 *          disclaimer in the documentation and/or other materials provided
 *          with the distribution.
 *        * Neither the name of The Linux Foundation nor the names of its
 *          contributors may be used to endorse or promote products derived
 *          from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED
 *    WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT
 *    ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 *    CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 *    SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 *    BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 *    OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
 *    IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#ifndef NN_BENCH_FORWARDPASSOP_H
#define NN_BENCH_FORWARDPASSOP_H

#include "OpType.h"
#include "../utils/PackOrder.h"
#include "../utils/Tensor.h"
#include <vector>

class ForwardPassOp {
public:
    static ForwardPassOp* Create(OpType type, std::vector<std::string>);
    std::vector<size_t> dimVec;
    std::vector<size_t> strideVec;
    void getDimVec(std::vector<std::string>);
    void getStrideVec(std::vector<std::string>);
    virtual ~ForwardPassOp();
    virtual void forwardPropagate(std::shared_ptr<Tensor>, std::shared_ptr<Tensor>);
    virtual void allocMem(std::shared_ptr<Tensor>, std::shared_ptr<Tensor>);
    virtual void randomize();
    int verbose = 0;
    void setVerbose(int);
    virtual void populateFromFile(std::string, int);
    virtual void delayedInit(PopulateMode, std::shared_ptr<Tensor>);
    std::shared_ptr<Tensor> delayedInitParams;
};


#endif //NN_BENCH_FORWARDPASSOP_H
