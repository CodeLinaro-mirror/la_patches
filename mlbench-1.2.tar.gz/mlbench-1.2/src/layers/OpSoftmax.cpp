/*
 *    Copyright (c) 2018, The Linux Foundation. All rights reserved.
 *
 *    Redistribution and use in source and binary forms, with or without
 *    modification, are permitted provided that the following conditions are
 *    met:
 *        * Redistributions of source code must retain the above copyright
 *          notice, this list of conditions and the following disclaimer.
 *        * Redistributions in binary form must reproduce the above
 *          copyright notice, this list of conditions and the following
 *          disclaimer in the documentation and/or other materials provided
 *          with the distribution.
 *        * Neither the name of The Linux Foundation nor the names of its
 *          contributors may be used to endorse or promote products derived
 *          from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED
 *    WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT
 *    ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 *    CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 *    SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 *    BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 *    OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
 *    IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include <iostream>
#include <cassert>
#include <cmath>
#include <algorithm>
#include <numeric>
#include "OpSoftmax.h"

#ifndef OP_SOFTMAX_ASSERTS
#define OP_SOFTMAX_ASSERTS 1
#endif

OpSoftmax::~OpSoftmax() = default;

OpSoftmax::OpSoftmax(std::vector<std::string>) {
}

void OpSoftmax::allocMem(std::shared_ptr<Tensor> inTensor, std::shared_ptr<Tensor> outTensor) {
    expVec = std::make_shared<std::vector<float> >(inTensor->numBytes);
}

void OpSoftmax::forwardPropagate(std::shared_ptr<Tensor> inTensor, std::shared_ptr<Tensor> outTensor) {
#if OP_SOFTMAX_ASSERTS
    assert (inTensor->dimVec.size() == outTensor->dimVec.size());
    for (size_t i = 0; i < inTensor->dimVec.size(); ++i) {
        assert(inTensor->dimVec[i] == outTensor->dimVec[i]);
    }
#endif
    int maxByte = *std::max_element(std::begin(*(inTensor->byteVec)), std::end(*(inTensor->byteVec)));
    std::transform(inTensor->byteVec->begin(), inTensor->byteVec->end(), expVec->begin(),
                   [&](unsigned char c){ return expf(inTensor->delta*((float)c-inTensor->offset-maxByte+inTensor->offset));});
    float denominator = std::accumulate(expVec->begin(), expVec->end(), 0.0f);
    std::transform(expVec->begin(), expVec->end(), outTensor->byteVec->begin(), [&](float f) {
        return static_cast<unsigned char>(std::max(0.0f,
                                                   std::min(255.0f,
                                                            roundf(
                                                                (f/denominator/outTensor->delta)+outTensor->offset)
                                                   )));});
    if (verbose) {
        std::cout << "OpSoftmax: " << std::endl;
        std::cout << "Input Tensor:" << std::endl;
        inTensor->print();
        std::cout << "Output Tensor:" << std::endl;
        outTensor->print();
    }
}

void OpSoftmax::populateFromFile(std::string initFileName, int initFileOffset) {
    delayedInitParams = std::make_shared<Tensor>(std::vector<size_t >{1});
    delayedInitParams->populateFromFile(initFileName, initFileOffset, true);
}

void OpSoftmax::delayedInit(PopulateMode populateMode, std::shared_ptr<Tensor> t) {
    if (populateMode == PopulateMode::PM_File) {
        t->delta = delayedInitParams->delta;
        t->offset = delayedInitParams->offset;
    }
}

