/*
 *    Copyright (c) 2018, The Linux Foundation. All rights reserved.
 *
 *    Redistribution and use in source and binary forms, with or without
 *    modification, are permitted provided that the following conditions are
 *    met:
 *        * Redistributions of source code must retain the above copyright
 *          notice, this list of conditions and the following disclaimer.
 *        * Redistributions in binary form must reproduce the above
 *          copyright notice, this list of conditions and the following
 *          disclaimer in the documentation and/or other materials provided
 *          with the distribution.
 *        * Neither the name of The Linux Foundation nor the names of its
 *          contributors may be used to endorse or promote products derived
 *          from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED
 *    WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT
 *    ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 *    CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 *    SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 *    BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 *    OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
 *    IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include <iostream>
#include <cassert>
#include "OpConv.h"

#ifndef OP_CONV_ASSERTS
#define OP_CONV_ASSERTS 0
#endif

OpConv::~OpConv() = default;

OpConv::OpConv(std::vector<std::string> v) {
    getDimVec(v);
    weight = std::make_shared<Tensor>(dimVec);
    bias = std::make_shared<Tensor>(std::vector<size_t>{dimVec[3]});
    getStrideVec(v);
    strideH = strideVec[0];
    strideW = strideVec[1];
}

void OpConv::allocMem(std::shared_ptr<Tensor> inTensor, std::shared_ptr<Tensor> outTensor){
    kernels::GEMM_MAT outputGemmMat = outTensor->getGemmMat(FlattenMode::FM_3D_to_Conv2D_Out, kernels::BIAS_ADD::ROW);
    size_t outputRows = outputGemmMat.rows;
    size_t outputColumns = outputGemmMat.columns;
    size_t lhsRows, lhsColumns, rhsRows, rhsColumns;
    lhsRows = outputRows;
    rhsColumns = outputColumns;
    rhsRows = lhsColumns = weight->dimVec[0] * weight->dimVec[1] * weight->dimVec[2];
    std::vector<size_t> lhsDim{lhsRows, lhsColumns};
    std::vector<size_t> rhsDim{rhsRows, rhsColumns};
    inPrime = std::make_shared<Tensor>(rhsDim);
}

void OpConv::forwardPropagate(std::shared_ptr<Tensor> inTensor, std::shared_ptr<Tensor> outTensor) {
    kernels::GEMM_MAT outputGemmMat = outTensor->getGemmMat(FlattenMode::FM_3D_to_Conv2D_Out, kernels::BIAS_ADD::ROW);
    size_t outputRows = outputGemmMat.rows;
    size_t outputColumns = outputGemmMat.columns;
    size_t lhsRows, lhsColumns, rhsRows, rhsColumns;
    lhsRows = outputRows;
    rhsColumns = outputColumns;
    rhsRows = lhsColumns = weight->dimVec[0] * weight->dimVec[1] * weight->dimVec[2];
    std::vector<size_t> lhsDim{lhsRows, lhsColumns};
    std::vector<size_t> rhsDim{rhsRows, rhsColumns};
    // LHS - weight
    kernels::GEMM_MAT weightGemmMat = weight->getGemmMat(FlattenMode::FM_4D_to_2D_conv_lhs);
    // RHS - inPrime
    inPrime->delta = inTensor->delta;
    inPrime->offset = inTensor->offset;
    size_t inputSliceSize = weight->dimVec[0] * weight->dimVec[1] * weight->dimVec[2];
    std::vector<unsigned char> lineVecOfInputSlice(inputSliceSize);
    size_t outputPos, inputPos, H_start, H_end, W_start, W_end, lineVecOfInputSliceOffset;
    for (size_t OH = 0; OH < outTensor->dimVec[0]; ++OH) {
        for (size_t OW = 0; OW < outTensor->dimVec[1]; ++OW) {
            H_start = OH;
            H_end = H_start + weight->dimVec[0] - 1;
            W_start = OW;
            W_end = W_start + weight->dimVec[1] - 1;
            lineVecOfInputSliceOffset = 0;
            for (size_t C = 0; C < weight->dimVec[2]; ++C) {
                for (size_t H = H_start; H <= H_end; ++H) {
                    for (size_t W = W_start; W <= W_end; ++W) {
                        outputPos = lineVecOfInputSliceOffset;
#if OP_CONV_ASSERTS
                        assert(outputPos < inputSliceSize);
#endif
                        inputPos = C * (inTensor->dimVec[0] * inTensor->dimVec[1]) + H * (inTensor->dimVec[1]) + W;
#if OP_CONV_ASSERTS
                        assert(inputPos < inTensor->numBytes);
#endif
                        lineVecOfInputSlice[outputPos] = (*(inTensor->byteVec))[inputPos];
                        lineVecOfInputSliceOffset++;
                    }
                }
            }
            std::copy(lineVecOfInputSlice.begin(), lineVecOfInputSlice.end(),
                      inPrime->byteVec->begin()+(OH*outTensor->dimVec[1]+OW)*inputSliceSize);
        }
    }
    kernels::GEMM_MAT inputGemmMat = inPrime->getGemmMat();
    kernels::GEMM_MAT biasGemmMat = bias->getGemmMat();
    kernels::low_precision_matrix_multiply(weightGemmMat, inputGemmMat, biasGemmMat, outputGemmMat);
    if (verbose) {
        std::cout << "OpConv: " << std::endl;
        std::cout << "Weight Tensor:" << std::endl;
        weight->print();
        std::cout << "Bias Tensor:" << std::endl;
        bias->print();
        std::cout << "Input Tensor:" << std::endl;
        inTensor->print();
        std::cout << "Output Tensor:" << std::endl;
        outTensor->print();
    }
}

void OpConv::randomize() {
    weight->randomize();
    bias->randomize();
}

void OpConv::populateFromFile(std::string initFileName, int initFileOffset) {
    weight->populateFromFile(initFileName, initFileOffset);
    initFileOffset += 12;
    initFileOffset += weight->numBytes;
    initFileOffset = Tensor::roundToNext16(initFileOffset);
    bias->populateFromFile(initFileName, initFileOffset);
    initFileOffset += 12;
    initFileOffset += bias->numBytes;
    initFileOffset = Tensor::roundToNext16(initFileOffset);
    delayedInitParams = std::make_shared<Tensor>(std::vector<size_t >{1});
    delayedInitParams->populateFromFile(initFileName, initFileOffset, true);
}

void OpConv::delayedInit(PopulateMode populateMode, std::shared_ptr<Tensor> t) {
    if (populateMode == PopulateMode::PM_File) {
        t->delta = delayedInitParams->delta;
        t->offset = delayedInitParams->offset;
    }
}

