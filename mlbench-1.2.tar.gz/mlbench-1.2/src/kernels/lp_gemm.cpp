/*
 *    Copyright (c) 2018, The Linux Foundation. All rights reserved.
 *
 *    Redistribution and use in source and binary forms, with or without
 *    modification, are permitted provided that the following conditions are
 *    met:
 *        * Redistributions of source code must retain the above copyright
 *          notice, this list of conditions and the following disclaimer.
 *        * Redistributions in binary form must reproduce the above
 *          copyright notice, this list of conditions and the following
 *          disclaimer in the documentation and/or other materials provided
 *          with the distribution.
 *        * Neither the name of The Linux Foundation nor the names of its
 *          contributors may be used to endorse or promote products derived
 *          from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED
 *    WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT
 *    ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 *    CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 *    SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 *    BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 *    OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
 *    IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include "mlbench_kernel.h"
#include <iostream>

#include "../third_party/gemmlowp/public/gemmlowp.h"
#include "../third_party/gemmlowp/public/output_stages.h"

#define GEMM_MAX_THREADS 1

gemmlowp::GemmContext gb_gemm_context;

template<typename T> T math_round(T v) {
    return int(v + 0.5);
}

void quantize_multiplier_smaller_than_one(float gemm_real_multiplier,
                                      std::int32_t *quantized_multiplier,
                                      int *right_shift) {
    assert(gemm_real_multiplier > 0.f);
    assert(gemm_real_multiplier < 1.f);
    int shift = 0;
    // Get multiplier into range  [1/2, 1).
    while (gemm_real_multiplier < 0.5f) {
        gemm_real_multiplier *= 2.0f;
        shift++;
    }
    // convert to fixed-point number.
    auto quantized = static_cast<std::int64_t>(math_round(gemm_real_multiplier * (1ll << 31)));
    assert(quantized <= (1ll << 31));
    // special case : multiplier close to 1
    if (quantized == (1ll << 31)) {
        quantized /= 2;
        shift--;
    }
    assert(shift >= 0);
    assert(quantized <= std::numeric_limits<std::int32_t>::max());
    *quantized_multiplier = static_cast<std::int32_t>(quantized);
    *right_shift = shift;
}

static void calibrate_bias(uint8_t *bias,
                           int count,
                           float bias_delta,
                           int bias_offset,
                           float scale, std::vector<std::int32_t> &bias_vector_data) {
    // Bias in 32-bit form to get added to GEMMLOWP accumulator
    for (int i = 0; i < count; i++) {
        float real_bias = (bias[i] + bias_offset) * bias_delta;
        float acc_calibrated_bias = real_bias / scale;
        bias_vector_data[i] = static_cast<std::int32_t>(roundf(acc_calibrated_bias));
    }
}

void kernels::low_precision_matrix_multiply(const GEMM_MAT &lhs_mat, const GEMM_MAT &rhs_mat, const GEMM_MAT &bias,
                                            GEMM_MAT &result_mat) {
    gb_gemm_context.set_max_num_threads(GEMM_MAX_THREADS);
    gemmlowp::MapOrder matrix_order = gemmlowp::MapOrder::RowMajor;
    const gemmlowp::MatrixMap<const uint8_t, gemmlowp::MapOrder::RowMajor> lhs(lhs_mat.buf, lhs_mat.rows,
                                                                               lhs_mat.columns);
    const gemmlowp::MatrixMap<const uint8_t, gemmlowp::MapOrder::ColMajor> rhs(rhs_mat.buf, rhs_mat.rows,
                                                                               rhs_mat.columns);
    gemmlowp::MatrixMap<uint8_t, gemmlowp::MapOrder::RowMajor> result(result_mat.buf, lhs_mat.rows, rhs_mat.columns);
    const float real_multiplier = lhs_mat.delta * rhs_mat.delta / result_mat.delta;
    int right_shift = 0;
    std::int32_t quantized_multiplier = 0;
    quantize_multiplier_smaller_than_one(real_multiplier, &quantized_multiplier, &right_shift);
    // Output stage for Real Multiplier
    gemmlowp::OutputStageQuantizeDownInt32ToUint8ScaleByFixedPoint quantize_down_stage;
    quantize_down_stage.result_offset_after_shift = result_mat.offset;
    quantize_down_stage.result_fixedpoint_multiplier = quantized_multiplier;
    quantize_down_stage.result_shift = right_shift;
    gemmlowp::OutputStageSaturatingCastToUint8 saturating_cast_stage;

    if (result_mat.bias_add_type == kernels::BIAS_ADD::ROW) {
        std::vector<std::int32_t> bias_vector(result_mat.columns);
        calibrate_bias(bias.buf,
                       result_mat.columns,
                       bias.delta,
                       -bias.offset,
                       lhs_mat.delta * rhs_mat.delta,
                       bias_vector);
        typedef gemmlowp::VectorMap<std::int32_t, gemmlowp::VectorShape::Row> RowVectorMap;
        RowVectorMap row_vector_map(bias_vector.data(), result_mat.columns);
        gemmlowp::OutputStageBiasAddition<RowVectorMap> row_bias_addition_stage;
        row_bias_addition_stage.bias_vector = row_vector_map;
        const auto &output_pipeline = std::make_tuple(row_bias_addition_stage,
                                                      quantize_down_stage,
                                                      saturating_cast_stage);
        gemmlowp::GemmWithOutputPipeline<std::uint8_t, std::uint8_t, gemmlowp::DefaultL8R8BitDepthParams>(
            &gb_gemm_context,
            lhs,
            rhs,
            &result,
            -lhs_mat.offset,
            -rhs_mat.offset,
            output_pipeline);
    }
    else if (result_mat.bias_add_type == kernels::BIAS_ADD::COLUMN) {
        std::vector<std::int32_t> bias_vector(result_mat.rows);
        calibrate_bias(bias.buf,
                       result_mat.rows,
                       bias.delta,
                       -bias.offset,
                       lhs_mat.delta * rhs_mat.delta,
                       bias_vector);
        typedef gemmlowp::VectorMap<std::int32_t, gemmlowp::VectorShape::Col> ColVectorMap;
        ColVectorMap col_vector_map(bias_vector.data(), result_mat.rows);
        gemmlowp::OutputStageBiasAddition<ColVectorMap> col_bias_addition_stage;
        col_bias_addition_stage.bias_vector = col_vector_map;
        const auto &output_pipeline = std::make_tuple(col_bias_addition_stage,
                                                      quantize_down_stage,
                                                      saturating_cast_stage);
        gemmlowp::GemmWithOutputPipeline<std::uint8_t, std::uint8_t, gemmlowp::DefaultL8R8BitDepthParams>(
            &gb_gemm_context,
            lhs,
            rhs,
            &result,
            -lhs_mat.offset,
            -rhs_mat.offset,
            output_pipeline);

    } else {

        const auto &output_pipeline = std::make_tuple(quantize_down_stage,
                                                      saturating_cast_stage);
        gemmlowp::GemmWithOutputPipeline<std::uint8_t, std::uint8_t, gemmlowp::DefaultL8R8BitDepthParams>(
            &gb_gemm_context,
            lhs,
            rhs,
            &result,
            -lhs_mat.offset,
            -rhs_mat.offset,
            output_pipeline);
    }
}

