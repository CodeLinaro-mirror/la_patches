/*
 *    Copyright (c) 2018, The Linux Foundation. All rights reserved.
 *
 *    Redistribution and use in source and binary forms, with or without
 *    modification, are permitted provided that the following conditions are
 *    met:
 *        * Redistributions of source code must retain the above copyright
 *          notice, this list of conditions and the following disclaimer.
 *        * Redistributions in binary form must reproduce the above
 *          copyright notice, this list of conditions and the following
 *          disclaimer in the documentation and/or other materials provided
 *          with the distribution.
 *        * Neither the name of The Linux Foundation nor the names of its
 *          contributors may be used to endorse or promote products derived
 *          from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED
 *    WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT
 *    ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 *    CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 *    SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 *    BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 *    OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
 *    IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#ifndef LPGEMM_KERNEL_H
#define LPGEMM_KERNEL_H

#include <cstdint>
#include <cstddef>

namespace kernels {
    struct softmax_args {
        uint8_t *buf;
        int32_t size;
        int32_t depth;
        int32_t offset;
        float delta;
    };
    using Softmax_Input = softmax_args;
    using Softmax_Output = softmax_args;
    enum class BIAS_ADD {
        ROW = 0x50,
        COLUMN,
        NONE
    };
    struct lpgemm_args {
        size_t rows;
        size_t columns;
        unsigned char *buf;
        unsigned char offset;
        float delta;
        BIAS_ADD bias_add_type;
    };
    using GEMM_MAT = lpgemm_args;
    void low_precision_matrix_multiply(const GEMM_MAT &lhs, const GEMM_MAT &rhs, const GEMM_MAT &bias,
                                       GEMM_MAT &result);
    void convolution();
    void max_pool();
    void relu();
    void softmax(const Softmax_Input &input, Softmax_Output &output);
}

#endif //LPGEMM_KERNEL_H
