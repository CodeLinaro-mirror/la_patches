/*
 *    Copyright (c) 2018, The Linux Foundation. All rights reserved.
 *
 *    Redistribution and use in source and binary forms, with or without
 *    modification, are permitted provided that the following conditions are
 *    met:
 *        * Redistributions of source code must retain the above copyright
 *          notice, this list of conditions and the following disclaimer.
 *        * Redistributions in binary form must reproduce the above
 *          copyright notice, this list of conditions and the following
 *          disclaimer in the documentation and/or other materials provided
 *          with the distribution.
 *        * Neither the name of The Linux Foundation nor the names of its
 *          contributors may be used to endorse or promote products derived
 *          from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED
 *    WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT
 *    ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 *    CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 *    SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 *    BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 *    OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
 *    IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include <iostream>
#include <fstream>
#include <cstring>
#include <chrono>
#include <numeric>
#include "network/NeuralNetwork.h"
#include "utils/StringUtils.h"

int main(int argc, char** argv) {
    int verbose = StringUtils::checkExistenceInCmdLine(argc, argv, "-v");
    std::string outFilename = StringUtils::extractStringFromCmdLine(argc, argv, "-o");
    std::string netDescriptorFile = StringUtils::extractStringFromCmdLine(argc, argv, "-i");
    int status = 0;
    int totalIters = StringUtils::extractIntFromCmdLine(argc, argv, "-n", 1);
    std::vector<double> timeVec;
    status = NeuralNetwork::getInstance().init(netDescriptorFile);
    if (status) {
        std::cerr << "NeuralNetwork init failed" << std::endl;
        return -1;
    }
    NeuralNetwork::getInstance().setVerbose(verbose);
    NeuralNetwork::getInstance().build();
    for (int run = 0; run < totalIters; ++run) {
        auto start = std::chrono::system_clock::now();
        NeuralNetwork::getInstance().execute();
        auto end = std::chrono::system_clock::now();
        std::chrono::duration<double> diff = end-start;
        timeVec.push_back(diff.count());
    }
    double totalTime = std::accumulate(timeVec.begin(), timeVec.end(), 0.0);
    if (!outFilename.empty()) {
        NeuralNetwork::getInstance().storeOutput(outFilename); //output from last run is stored
    }
    NeuralNetwork::getInstance().destroy();
    if (verbose) {
        std::cout << "Note that this is a debug run(-v)"
                  << ", and timing stats would be bloated"
                  << std::endl;
    }
    std::cout << "Inferences=" << totalIters
              << ", Total_time(s)=" <<  totalTime
              << ", Time(s)/inference=" << totalTime/totalIters
              << ", Inferences/sec=" << totalIters/totalTime
              << std::endl;
    return 0;
}
