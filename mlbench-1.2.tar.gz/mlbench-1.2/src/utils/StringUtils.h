/*
 *    Copyright (c) 2018, The Linux Foundation. All rights reserved.
 *
 *    Redistribution and use in source and binary forms, with or without
 *    modification, are permitted provided that the following conditions are
 *    met:
 *        * Redistributions of source code must retain the above copyright
 *          notice, this list of conditions and the following disclaimer.
 *        * Redistributions in binary form must reproduce the above
 *          copyright notice, this list of conditions and the following
 *          disclaimer in the documentation and/or other materials provided
 *          with the distribution.
 *        * Neither the name of The Linux Foundation nor the names of its
 *          contributors may be used to endorse or promote products derived
 *          from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED
 *    WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT
 *    ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 *    CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 *    SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 *    BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 *    OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
 *    IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#ifndef NN_BENCH_STRINGUTILS_H
#define NN_BENCH_STRINGUTILS_H

#include <string>
#include <vector>
#include "PackOrder.h"

class StringUtils {
public:
    std::string delimiter = "x";
    static int StringToInt(std::string);
    static float StringToFloat(std::string);
    static size_t getNumDimsFromSizeStr(std::string);
    static size_t getDimNFromSizeStr(size_t, std::string, PackOrder);
    static size_t getStrideNFromSizeStr(size_t, std::string, PackOrder);
    static size_t getNumStridesFromSizeStr(std::string);
    static std::string getSizeStr(std::vector<std::string> v);
    static std::string getStrideStr(std::vector<std::string> v);
    static std::string extractInitFileNameFromStr(std::string);
    static int extractInitFileOffsetFromStr(std::string);
    static std::string extractStringFromCmdLine(int, char**, std::string);
    static int extractIntFromCmdLine(int, char**, std::string, int = 0);
    static int checkExistenceInCmdLine(int, char**, std::string);
};

#endif //NN_BENCH_STRINGUTILS_H
