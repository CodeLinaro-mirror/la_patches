/*
 *    Copyright (c) 2018, The Linux Foundation. All rights reserved.
 *
 *    Redistribution and use in source and binary forms, with or without
 *    modification, are permitted provided that the following conditions are
 *    met:
 *        * Redistributions of source code must retain the above copyright
 *          notice, this list of conditions and the following disclaimer.
 *        * Redistributions in binary form must reproduce the above
 *          copyright notice, this list of conditions and the following
 *          disclaimer in the documentation and/or other materials provided
 *          with the distribution.
 *        * Neither the name of The Linux Foundation nor the names of its
 *          contributors may be used to endorse or promote products derived
 *          from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED
 *    WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT
 *    ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 *    CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 *    SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 *    BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 *    OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
 *    IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include <iostream>
#include <sstream>
#include <vector>
#include <climits>
#include <iomanip>
#include <random>
#include <fstream>
#include "Tensor.h"
#include "randSeed.h"

Tensor::Tensor(std::vector<size_t> dims) {
    packorder = PackOrder::PO_NCHW;
    size_t bytes = 1;
    dimVec = dims;
    for (auto dim : dims)
        bytes *= dim;
    numBytes = bytes;
    byteVec = std::make_shared<std::vector<unsigned char> >(bytes);
}

Tensor::~Tensor() = default;

static unsigned int randSeed = ML_BENCH_RAND_SEED;
static std::default_random_engine generator {static_cast<long unsigned int>(randSeed)};
static std::uniform_int_distribution<int> distribution(0, UCHAR_MAX);

void Tensor::randomize() {
    for (int i=0; i < numBytes; ++i) {
        (*byteVec)[i] = static_cast<unsigned char> (distribution(generator));
    }
}

kernels::GEMM_MAT Tensor::getGemmMat(FlattenMode flattenMode, kernels::BIAS_ADD biasAdd) {
    kernels::GEMM_MAT ret;
    ret.buf = &((*byteVec)[0]);
    ret.offset = offset;
    ret.delta = delta;
    if (flattenMode == FlattenMode::FM_NONE) {
        ret.columns = dimVec[1];
        ret.rows = dimVec[0];
    } else if (flattenMode == FlattenMode::FM_3D_to_RowVec) {
        ret.columns = numBytes;
        ret.rows = 1;
    } else if (flattenMode == FlattenMode::FM_3D_to_ColVec) {
        ret.columns = 1;
        ret.rows = numBytes;
    } else if (flattenMode == FlattenMode::FM_3D_to_Conv2D_Out) {
        ret.rows = dimVec[2];
        ret.columns = dimVec[0] * dimVec[1];
    } else if (flattenMode == FlattenMode::FM_2D_CR) {
        ret.rows = dimVec[1];
        ret.columns = dimVec[0];
    } else if (flattenMode == FlattenMode::FM_4D_to_2D_conv_lhs) {
        ret.rows = dimVec[3];
        ret.columns = dimVec[0] * dimVec[1] * dimVec[2];
    }
    ret.bias_add_type = biasAdd;
    return ret;
}

void Tensor::print() {
    // Print the dimensions
    std::cout << "dimension(s) = <";
    std::cout.flush();
    for (auto dim : dimVec)
        std::cout << dim << " ";
    std::cout << ">" << std::endl;
    std::cout.flush();
    //--

    // Print the total number of bytes
    std::cout << "numBytes:" << numBytes << std::endl;
    std::cout.flush();
    //--

    // Print delta
    std::cout << "delta:" << delta << std::endl;
    std::cout.flush();
    //--

    // Print offset
    std::cout << "offset:" << offset << std::endl;
    std::cout.flush();
    //--

    // Print all the elements of the byte-array
    int numDims = dimVec.size();
    size_t iter = 0;
    std::cout << "[N][C][H][W]: <val_uint8> : <val_float>" << std::endl;
    for (int N = 0; N < (numDims > 3 ? dimVec[3] : 1); ++N) {
        for (int C = 0; C < (numDims > 2 ? dimVec[2] : 1); ++C) {
            for (int H = 0; H < (numDims > 1 ? dimVec[1] : 1); ++H) {
                for (int W = 0; W < (numDims > 0 ? dimVec[0] : 1); ++W) {
                    std::cout << "[" << N << "][" <<  C << "][" << H << "][" << W << "]: ";
                    int v_uint8 = (((uint32_t)(UCHAR_MAX)) & (*byteVec)[iter++]);
                    std::cout << v_uint8 << " : " << delta*((float)v_uint8 - offset) << std::endl;
                    std::cout.flush();
                }
            }
        }
    }
    //--
}

void Tensor::populateFromFile(std::string infilename, int fileOffset, bool noBufferRead) {
    // Open the file
    std::stringstream sstream;
    std::ifstream infile;
    infile.open(infilename, std::ios_base::in);
    if (infile.fail()) {
        std::cerr << "File open failed" << std::endl;
        throw(ERR_NN_BENCH_FILE_OPEN_FAILED);
    }
    // get length of file:
    infile.seekg (0, std::ios::end);
    unsigned long long length = infile.tellg();
    infile.seekg (0, std::ios::beg);
    // check if file has enough info for our consumption
    if ((fileOffset + numBytes + 4 + 4 + 1) > length) {
        std::cerr << "Invalid offset" << std::endl;
        throw(ERR_NN_BENCH_FILE_OFFSET_INVALID);
    }
    infile.seekg(fileOffset, std::ios::beg);
    // read delta
    infile.read(reinterpret_cast<char*>(&delta), 4);
    // read offset
    infile.read(reinterpret_cast<char*>(&offset), 4);
    if (noBufferRead == false) {
        // read the size of byte array
        int bytesInFile = 0;
        infile.read(reinterpret_cast<char*>(&bytesInFile), 4);
        if (bytesInFile != numBytes) {
            std::cerr << "Unexpected number of bytes in file buffer;"
                      << " expected=" << numBytes
                      << ", file=" << bytesInFile
                      << std::endl;
#if THROW_ERR_ON_FILE_BUFFER_SIZE_MISMATCH
            throw(ERR_NN_BENCH_FILE_BUFFER_SIZE_MISMATCH);
#endif // THROW_ERR_ON_FILE_BUFFER_SIZE_MISMATCH
        }
        // read the bytes
        infile.read((char*)((*byteVec).data()), numBytes);
    }
    // close the file
    if (infile.is_open()) {
        infile.close();
    }
}

int Tensor::roundToNext16(int i) {
    int round = 16;
    return ((i%round) == 0 ? i : i+(round-(i%round)));
}

void Tensor::dumpToFile(std::string outFilename) {
    // Open the file
    std::stringstream sstream;
    std::ofstream outfile;
    outfile.open(outFilename, std::ios_base::out);
    if (outfile.fail()) {
        std::cerr << "File open failed" << std::endl;
        throw(ERR_NN_BENCH_FILE_OPEN_FAILED);
    }
    // write the elements
    for (int i = 0; i < numBytes; ++i) {
        outfile << i << "," << delta*((*byteVec)[i] - offset) << std::endl;
    }
    // close the file
    outfile.close();
}
