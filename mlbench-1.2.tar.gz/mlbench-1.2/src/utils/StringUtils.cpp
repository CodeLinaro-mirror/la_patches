/*
 *    Copyright (c) 2018, The Linux Foundation. All rights reserved.
 *
 *    Redistribution and use in source and binary forms, with or without
 *    modification, are permitted provided that the following conditions are
 *    met:
 *        * Redistributions of source code must retain the above copyright
 *          notice, this list of conditions and the following disclaimer.
 *        * Redistributions in binary form must reproduce the above
 *          copyright notice, this list of conditions and the following
 *          disclaimer in the documentation and/or other materials provided
 *          with the distribution.
 *        * Neither the name of The Linux Foundation nor the names of its
 *          contributors may be used to endorse or promote products derived
 *          from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED
 *    WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT
 *    ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 *    CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 *    SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 *    BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 *    OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
 *    IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include "StringUtils.h"
#include "PackOrder.h"
#include <sstream>
#include <vector>

int StringUtils::StringToInt(std::string in) {
    std::stringstream s(in);
    int ret = 0;
    s >> ret;
    return ret;
}

float StringUtils::StringToFloat(std::string in) {
    std::stringstream s(in);
    float ret = 0;
    s >> ret;
    return ret;
}


size_t StringUtils::getNumDimsFromSizeStr(std::string s) {
    std::string delimiter = "x";
    size_t pos = 0;
    std::string token;
    std::vector<std::string> tokenVec;
    while ((pos = s.find(delimiter)) != std::string::npos) {
        token = s.substr(0, pos);
        tokenVec.push_back(token);
        s.erase(0, pos + delimiter.length());
    }
    tokenVec.push_back(s);
    return tokenVec.size();
}

size_t StringUtils::getDimNFromSizeStr(size_t dim, std::string s, PackOrder packOrder){
    std::string delimiter = "x";
    size_t pos = 0;
    std::string token;
    std::vector<std::string> tokenVec;
    while ((pos = s.find(delimiter)) != std::string::npos) {
        token = s.substr(0, pos);
        tokenVec.push_back(token);
        s.erase(0, pos + delimiter.length());
    }
    tokenVec.push_back(s);
    return static_cast<size_t>(StringUtils::StringToInt(tokenVec[dim]));
}
size_t StringUtils::getStrideNFromSizeStr(size_t dim, std::string s, PackOrder packOrder) {
    std::string delimiter = "x";
    size_t pos = 0;
    std::string token;
    std::vector<std::string> tokenVec;
    while ((pos = s.find(delimiter)) != std::string::npos) {
        token = s.substr(0, pos);
        tokenVec.push_back(token);
        s.erase(0, pos + delimiter.length());
    }
    tokenVec.push_back(s);
    return static_cast<size_t>(StringUtils::StringToInt(tokenVec[dim]));
}

size_t StringUtils::getNumStridesFromSizeStr(std::string s) {
    std::string delimiter = "x";
    size_t pos = 0;
    std::string token;
    std::vector<std::string> tokenVec;
    while ((pos = s.find(delimiter)) != std::string::npos) {
        token = s.substr(0, pos);
        tokenVec.push_back(token);
        s.erase(0, pos + delimiter.length());
    }
    tokenVec.push_back(s);
    return tokenVec.size();
}

std::string StringUtils::getSizeStr(std::vector<std::string> v) {
    std::string key = "size:";
    std::string sizeStr;
    for (std::string s : v) {
        if (s.find(key) != std::string::npos) {
            sizeStr = s.erase(0, key.length());
            return sizeStr;
        }
    }
    return "";
}

std::string StringUtils::getStrideStr(std::vector<std::string> v) {
    std::string key = "stride:";
    std::string sizeStr;
    for (std::string s : v) {
        if (s.find(key) != std::string::npos) {
            sizeStr = s.erase(0, key.length());
            return sizeStr;
        }
    }
    return "";
}

std::string StringUtils::extractInitFileNameFromStr(std::string s) {
    std::string key = "init:filename:";
    size_t lpos;
    lpos = s.find(key);
    size_t posSpace, posEnd;
    s.erase(0, lpos + key.length());
    posSpace = s.find(" ");
    posEnd = s.find(">");
    return s.substr(0, std::min(posSpace, posEnd));
}

int StringUtils::extractInitFileOffsetFromStr(std::string s) {
    std::string key = "init:offset:";
    size_t lpos;
    lpos = s.find(key);
    size_t posSpace, posEnd;
    s.erase(0, lpos + key.length());
    posSpace = s.find(" ");
    posEnd = s.find(">");
    return StringToInt(s.substr(0, std::min(posSpace, posEnd)));
}

std::string StringUtils::extractStringFromCmdLine(int argc, char** argv, std::string pattern) {
    for (int i = 0; i < argc; i++){
        std::string s(argv[i]);
        if ((s == pattern) && (i != (argc - 1))) {
            return std::string(argv[i+1]);
        }
    }
    return "";
}

int StringUtils::extractIntFromCmdLine(int argc, char** argv, std::string pattern, int defaultRet) {
    std::string retStr = StringUtils::extractStringFromCmdLine(argc, argv, pattern);
    if (!retStr.empty()) {
        return StringUtils::StringToInt(retStr);
    }
    return defaultRet;
}

int StringUtils::checkExistenceInCmdLine(int argc, char** argv, std::string pattern) {
    for (int i = 0; i < argc; i++){
        std::string s(argv[i]);
        if (s == pattern) {
            return 1;
        }
    }
    return 0;
}

