/*
 *    Copyright (c) 2018, The Linux Foundation. All rights reserved.
 *
 *    Redistribution and use in source and binary forms, with or without
 *    modification, are permitted provided that the following conditions are
 *    met:
 *        * Redistributions of source code must retain the above copyright
 *          notice, this list of conditions and the following disclaimer.
 *        * Redistributions in binary form must reproduce the above
 *          copyright notice, this list of conditions and the following
 *          disclaimer in the documentation and/or other materials provided
 *          with the distribution.
 *        * Neither the name of The Linux Foundation nor the names of its
 *          contributors may be used to endorse or promote products derived
 *          from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED
 *    WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT
 *    ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 *    CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 *    SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 *    BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 *    OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
 *    IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#ifndef NN_BENCH_TENSOR_H
#define NN_BENCH_TENSOR_H

#include <cstring>
#include <vector>
#include "PackOrder.h"
#include "../kernels/mlbench_kernel.h"
#include <memory>
#include "errorCodes.h"

enum FlattenMode {
    FM_3D_to_RowVec,
    FM_3D_to_ColVec,
    FM_3D_to_Conv2D_Out,
    FM_2D_CR, // cols x rows
    FM_4D_to_2D_conv_lhs,
    FM_NONE
};

enum PopulateMode {
    PM_Rand,
    PM_File,
    PM_NONE
};

class Tensor {
public:
    PackOrder packorder;
    std::vector<size_t> dimVec;
    std::shared_ptr <std::vector<unsigned char> > byteVec;
    explicit Tensor(std::vector<size_t>);
    ~Tensor();
    void randomize();
    float delta = (2.0f) / 255;
    int32_t offset = 128;
    kernels::GEMM_MAT getGemmMat(FlattenMode = FlattenMode::FM_NONE,
                                 kernels::BIAS_ADD = kernels::BIAS_ADD::NONE);
    size_t numBytes;
    void print();
    void populateFromFile(std::string, int, bool noBufferRead = false);
    void dumpToFile(std::string);
    static int roundToNext16(int);
};


#endif //NN_BENCH_TENSOR_H
