/*
 *    Copyright (c) 2018, The Linux Foundation. All rights reserved.
 *
 *    Redistribution and use in source and binary forms, with or without
 *    modification, are permitted provided that the following conditions are
 *    met:
 *        * Redistributions of source code must retain the above copyright
 *          notice, this list of conditions and the following disclaimer.
 *        * Redistributions in binary form must reproduce the above
 *          copyright notice, this list of conditions and the following
 *          disclaimer in the documentation and/or other materials provided
 *          with the distribution.
 *        * Neither the name of The Linux Foundation nor the names of its
 *          contributors may be used to endorse or promote products derived
 *          from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED
 *    WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT
 *    ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 *    CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 *    SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 *    BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 *    OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
 *    IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#ifndef NN_BENCH_NEURALNETWORK_H
#define NN_BENCH_NEURALNETWORK_H

#include <string>
#include <vector>
#include <iostream>
#include <memory>

#include "GraphNode.h"
#include "GraphEdge.h"


class NeuralNetwork
{
private:
    std::vector <std::shared_ptr<GraphNode> > nodeVec;
    std::vector <std::shared_ptr<GraphEdge> > edgeVec;
    NeuralNetwork() {
    }
    ~NeuralNetwork() {
    }
    std::string fileToStr(const std::string filename, int* status);
    void populateGraphNodesFromStr(std::string, int* status);
    void populateGraphEdgesFromStr(std::string, int* status);
    int verbose = 0;
public:
    NeuralNetwork(NeuralNetwork const&)  = delete;
    void operator=(NeuralNetwork const&) = delete;
    int init(std::string);
    int build();
    int execute();
    void destroy();
    static NeuralNetwork& getInstance() {
        static NeuralNetwork instance;
        return instance;
    }
    std::shared_ptr<Tensor> getTensorRef(std::string);
    void setVerbose(int);
    void storeOutput(std::string);
};


#endif //NN_BENCH_NEURALNETWORK_H
