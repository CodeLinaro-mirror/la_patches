/*
 *    Copyright (c) 2018, The Linux Foundation. All rights reserved.
 *
 *    Redistribution and use in source and binary forms, with or without
 *    modification, are permitted provided that the following conditions are
 *    met:
 *        * Redistributions of source code must retain the above copyright
 *          notice, this list of conditions and the following disclaimer.
 *        * Redistributions in binary form must reproduce the above
 *          copyright notice, this list of conditions and the following
 *          disclaimer in the documentation and/or other materials provided
 *          with the distribution.
 *        * Neither the name of The Linux Foundation nor the names of its
 *          contributors may be used to endorse or promote products derived
 *          from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED
 *    WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT
 *    ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 *    CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 *    SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 *    BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 *    OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
 *    IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include <iostream>
#include <vector>
#include "GraphEdge.h"
#include "GraphNode.h"
#include "../utils/StringUtils.h"

bool GraphEdge::isEdge(std::string in) {
    const std::string key = "edge";
    if (in.substr(0, in.find(key)).empty()) {
        size_t locStart, locStop;
        locStart = in.find('<');
        locStop = in.find('>');
        if ( (locStart != std::string::npos) && (locStop != std::string::npos) && ((locStart+1) <= (locStop-1))) {
            return true;
        }
    }
    return false;
}

std::string GraphEdge::getInputNodeName(std::string s) {
    std::string key = "input:";
    size_t lpos;
    lpos = s.find(key);
    size_t posSpace, posEnd;
    s.erase(0, lpos + key.length());
    posSpace = s.find(" ");
    posEnd = s.find(">");
    return s.substr(0, std::min(posSpace, posEnd));
}

std::string GraphEdge::getOutputNodeName(std::string s) {
    std::string key = "output:";
    size_t lpos;
    lpos = s.find(key);
    size_t posSpace, posEnd;
    s.erase(0, lpos + key.length());
    posSpace = s.find(" ");
    posEnd = s.find(">");
    return s.substr(0, std::min(posSpace, posEnd));
}

OpType GraphEdge::extractTypeFromEdgeParam(std::string s) {
    std::string key = "type:";
    size_t lpos;
    lpos = s.find(key);
    size_t posSpace, posEnd;
    s.erase(0, lpos + key.length());
    posSpace = s.find(" ");
    posEnd = s.find(">");
    std::string opTypeStr = s.substr(0, std::min(posSpace, posEnd));
    OpType retVal;
    if (opTypeStr == "conv")
        retVal = OT_Conv;
    else if (opTypeStr == "pool")
        retVal = OT_Pool;
    else if (opTypeStr == "fcnn")
        retVal = OT_Fcnn;
    else if (opTypeStr == "softmax")
        retVal = OT_Softmax;
    else if (opTypeStr == "relu")
        retVal = OT_Relu;
    else
        retVal = OT_NULL;
    return retVal;
}

std::vector<std::string> GraphEdge::extractParamsFromEdgeParam(std::string s) {
    std::vector<std::string> retVec;
    std::string key = "param:";
    size_t lpos = s.find(key);
    while (lpos != std::string::npos) {
        size_t posSpace, posEnd;
        s.erase(0, lpos + key.length());
        posSpace = s.find(" ");
        posEnd = s.find(">");
        retVec.push_back(s.substr(0, std::min(posSpace, posEnd)));
        s.erase(0, std::min(posSpace, posEnd)+1);
        lpos = s.find(key);
    }
    return retVec;
}

GraphEdge::GraphEdge(std::string in) {
    PackOrder packOrder = PO_HWCN;
    inputNode = getInputNodeName(in);
    outputNode = getOutputNodeName(in);
    name = inputNode + "->" + outputNode;
    op = std::shared_ptr<ForwardPassOp>(ForwardPassOp::Create(extractTypeFromEdgeParam(in), extractParamsFromEdgeParam(in)));
    if (GraphNode::needsRandInit(in)) {
        populateMode = PopulateMode::PM_Rand;
        op->randomize();
    } else if (GraphNode::needsFileInit(in)) {
        populateMode = PopulateMode::PM_File;
        std::string initFileName = StringUtils::extractInitFileNameFromStr(in);
        int initFileOffset = StringUtils::extractInitFileOffsetFromStr(in);
        op->populateFromFile(initFileName, initFileOffset);
    }
}

GraphEdge::~GraphEdge() = default;
