/*
 *    Copyright (c) 2018, The Linux Foundation. All rights reserved.
 *
 *    Redistribution and use in source and binary forms, with or without
 *    modification, are permitted provided that the following conditions are
 *    met:
 *        * Redistributions of source code must retain the above copyright
 *          notice, this list of conditions and the following disclaimer.
 *        * Redistributions in binary form must reproduce the above
 *          copyright notice, this list of conditions and the following
 *          disclaimer in the documentation and/or other materials provided
 *          with the distribution.
 *        * Neither the name of The Linux Foundation nor the names of its
 *          contributors may be used to endorse or promote products derived
 *          from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED
 *    WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT
 *    ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 *    CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 *    SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 *    BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 *    OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
 *    IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include <iostream>
#include <vector>
#include "GraphNode.h"
#include "../utils/PackOrder.h"
#include "../utils/StringUtils.h"

bool GraphNode::isNode(std::string in) {
    const std::string key = "node";
    if (in.substr(0, in.find(key)).empty()) {
        size_t locStart, locStop;
        locStart = in.find('<');
        locStop = in.find('>');
        if ( (locStart != std::string::npos) && (locStop != std::string::npos) && ((locStart+1) <= (locStop-1))) {
            return true;
        }
    }
    return false;
}

std::string GraphNode::extractSizeFromNodeParam(std::string in) {
    std::string key = "size:";
    size_t posKey = in.find(key);
    size_t posEnd = in.find('>');
    size_t posSpace = in.find(' ');
    return in.substr(posKey+key.size(), std::min(posEnd, posSpace));
}

std::string GraphNode::extractNameFromNodeParam(std::string s) {
    std::string key = "name:";
    size_t lpos;
    lpos = s.find(key);
    size_t posSpace, posEnd;
    s.erase(0, lpos + key.length());
    posSpace = s.find(" ");
    posEnd = s.find(">");
    return s.substr(0, std::min(posSpace, posEnd));
}

GraphNode::GraphNode(std::string in) {
    PackOrder packOrder = PO_NHWC;
    name = extractNameFromNodeParam(in);
    std::string sizeParam = extractSizeFromNodeParam(in);
    numDims = StringUtils::getNumDimsFromSizeStr(sizeParam);
    for (int dim = 0; dim < numDims; ++dim){
        dimSizeVec.push_back(StringUtils::getDimNFromSizeStr(dim, sizeParam, packOrder));
    }
    tensor = std::make_shared<Tensor>(dimSizeVec);
    if (needsRandInit(in)) {
        tensor->randomize();
    } else if (needsFileInit(in)) {
        // get filename and offset
        std::string initFileName = StringUtils::extractInitFileNameFromStr(in);
        int initFileOffset = StringUtils::extractInitFileOffsetFromStr(in);
        tensor->populateFromFile(initFileName, initFileOffset);
    }
}

GraphNode::~GraphNode() = default;

bool GraphNode::needsRandInit(std::string s) {
    if (s.find("init:rand") != std::string::npos) {
        return true;
    }
    return false;
}

bool GraphNode::needsFileInit(std::string s) {
    if (s.find("init:file") != std::string::npos) {
        return true;
    }
    return false;
}
