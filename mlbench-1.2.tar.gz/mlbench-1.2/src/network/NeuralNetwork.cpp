/*
 *    Copyright (c) 2018, The Linux Foundation. All rights reserved.
 *
 *    Redistribution and use in source and binary forms, with or without
 *    modification, are permitted provided that the following conditions are
 *    met:
 *        * Redistributions of source code must retain the above copyright
 *          notice, this list of conditions and the following disclaimer.
 *        * Redistributions in binary form must reproduce the above
 *          copyright notice, this list of conditions and the following
 *          disclaimer in the documentation and/or other materials provided
 *          with the distribution.
 *        * Neither the name of The Linux Foundation nor the names of its
 *          contributors may be used to endorse or promote products derived
 *          from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED
 *    WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT
 *    ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 *    CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 *    SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 *    BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 *    OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
 *    IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include <sstream>
#include <fstream>
#include "NeuralNetwork.h"
#include "../utils/errorCodes.h"

int NeuralNetwork::init(const std::string filename) {
    int status = 0;
    std::string fileStr = fileToStr(filename, &status);
    populateGraphNodesFromStr(fileStr, &status);
    populateGraphEdgesFromStr(fileStr, &status);
    return ERR_NN_BENCH_SUCCESS;
}

int NeuralNetwork::build() {
    for (auto edge : edgeVec) {
        try {
            edge->op->setVerbose(verbose);
            edge->op->allocMem(getTensorRef(edge->inputNode), getTensorRef(edge->outputNode));
            edge->op->delayedInit(edge->populateMode, getTensorRef(edge->outputNode));
        }
        catch (...) {
            std::cerr << "Exception caught while building edge: " << edge->name << std::endl;
        }
    }
    return ERR_NN_BENCH_SUCCESS;
}

int NeuralNetwork::execute() {
    for (auto edge : edgeVec) {
        try {
            edge->op->forwardPropagate(getTensorRef(edge->inputNode), getTensorRef(edge->outputNode));
        }
        catch (...) {
            std::cerr << "Exception caught while executing edge: " << edge->name << std::endl;
        }
    }
    return ERR_NN_BENCH_SUCCESS;
}

std::string NeuralNetwork::fileToStr(const std::string infilename, int* status){
    std::stringstream sstream;
    std::ifstream infile;
    infile.open(infilename, std::ios_base::in);
    if (infile.fail()) {
        std::cout << "File open failed" << std::endl;
        *status = ERR_NN_BENCH_FILE_OPEN_FAILED;
    }
    if (infile.good())
        sstream << infile.rdbuf();
    if (infile.is_open()) {
        infile.close();
    }
    return sstream.str();
}

void NeuralNetwork::populateGraphNodesFromStr(std::string in, int *status) {
    std::stringstream istream(in);
    std::string line;
    while (std::getline(istream, line)) {
        if (GraphNode::isNode(line)){
            size_t startPos = line.find('<');
            size_t stopPos = line.find('>');
            size_t numChars = stopPos - startPos - 1;
            std::string nodeContents = line.substr();
            this->nodeVec.push_back (std::make_shared<GraphNode> (line.substr(startPos+1, numChars)));
        }
    }
}

void NeuralNetwork::populateGraphEdgesFromStr(std::string in, int *status) {
    std::stringstream istream(in);
    std::string line;
    while (std::getline(istream, line)) {
        if (GraphEdge::isEdge(line)) {
            size_t startPos = line.find('<');
            size_t stopPos = line.find('>');
            size_t numChars = stopPos - startPos - 1;
            std::string nodeContents = line.substr();
            this->edgeVec.push_back (std::make_shared<GraphEdge> (line.substr(startPos+1, numChars)));
        }
    }
}

std::shared_ptr<Tensor> NeuralNetwork::getTensorRef(std::string nodeName) {
    for (auto node : nodeVec) {
        if (nodeName == node->name) {
            return node->tensor;
        }
    }
    std::vector<size_t> zeroSizeVec(0);
    return std::make_shared<Tensor>(zeroSizeVec);
}

void NeuralNetwork::destroy() {
    nodeVec.clear();
    edgeVec.clear();
}

void NeuralNetwork::setVerbose(int in) {
    verbose = in;
}

void NeuralNetwork::storeOutput(std::string outFilename) {
    try {
        nodeVec.back()->tensor->dumpToFile(outFilename);
    }
    catch (...) {
        std::cerr << "Exception caught while trying to write output" << std::endl;
    }
}

