## LeNet model for MNIST

### Network architecture

The network architecture is defined in ```models/lenet_model.txt```

### Network parameters

The network parameters are extracted from a trained caffe Lenet model using ```<MLBENCH_ROOT>/scripts/extract_caffe_params.py```

The process of parameter extraction requires a trained caffe model

If ```MLB_CAFFE_ROOT``` is your caffe src root directory, then after following all prerequisites, if
 
```./examples/mnist/train_lenet.sh```

is run, it will produce the following

```$MLB_CAFFE_ROOT/examples/mnist/lenet.prototxt```
 

```$MLB_CAFFE_ROOT/examples/mnist/lenet_iter_10000.caffemodel```

From the above, parameters can be extracted as follows

    ../../scripts/extract_caffe_params.py -i input_image_list -m <path-to-caffemodel> -p <path-to-prototxt> -o models/lenet_param.txt 
    
where
 
```input_image_list``` can be created by running ```./scripts/create_input_list.sh```


