#!/bin/sh

# ------------------------------------------------------------------------------
# Copyright (c) 2018, The Linux Foundation. All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are
# met:
#     * Redistributions of source code must retain the above copyright
#       notice, this list of conditions and the following disclaimer.
#     * Redistributions in binary form must reproduce the above
#       copyright notice, this list of conditions and the following
#       disclaimer in the documentation and/or other materials provided
#       with the distribution.
#     * Neither the name of The Linux Foundation nor the names of its
#       contributors may be used to endorse or promote products derived
#       from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED
# WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT
# ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
# BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
# WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
# OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
# IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# ------------------------------------------------------------------------------


MODEL_FOLDER_NAME="models"
OUTPUT_FOLDER_NAME="output"
PROCESSED_INPUT_FOLDER="processed_bin"
LABEL_FOLDER="processed_inputs"
MLBENCH_EXE="../../../ml_bench"

# Create the lenet parameter binary if it doesn't exist
if [ ! -f ${MODEL_FOLDER_NAME}/lenet_param.bin ];then
	../../scripts/bin_generator.py -i ${MODEL_FOLDER_NAME}/lenet_param.txt -o ${MODEL_FOLDER_NAME}/lenet_param.bin
fi

# create the folder where mlbench outputs will be stored
mkdir -p ${OUTPUT_FOLDER_NAME}

# switch to the models folder
cd ${MODEL_FOLDER_NAME}

echo 'filename,mlbench_label,golden_label'
for f in `find ../${PROCESSED_INPUT_FOLDER} -name 'mnist_test_image_*bin' -type f | sort`; do
	INPUT_BASENAME=$(echo ${f%.*} | sed "s/.*\///")
	# the output file
	OUTFILE="../${OUTPUT_FOLDER_NAME}/${INPUT_BASENAME}.out"
	# create a symlink to the input file
	rm -f input.bin
	ln -sf $f ./input.bin
	# the actual ml-bench call
	${MLBENCH_EXE} -i lenet_model.txt -o ${OUTFILE} > /dev/null
	# check what label ml-bench calculated
	mlbench_label=$(cat ${OUTFILE} | sort -k 2 -t , -r | head -n 1 | cut -d ',' -f 1)
	# check the actual label from golden_label file
	golden_label=$(grep ${INPUT_BASENAME} ../${LABEL_FOLDER}/mnist_test_image_golden* | cut -d ',' -f 2)
	# print the results
	echo ${INPUT_BASENAME},${mlbench_label},$golden_label
done
