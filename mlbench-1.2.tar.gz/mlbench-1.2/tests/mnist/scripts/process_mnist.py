#!/usr/bin/env python

# ------------------------------------------------------------------------------
# Copyright (c) 2018, The Linux Foundation. All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are
# met:
#     * Redistributions of source code must retain the above copyright
#       notice, this list of conditions and the following disclaimer.
#     * Redistributions in binary form must reproduce the above
#       copyright notice, this list of conditions and the following
#       disclaimer in the documentation and/or other materials provided
#       with the distribution.
#     * Neither the name of The Linux Foundation nor the names of its
#       contributors may be used to endorse or promote products derived
#       from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED
# WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT
# ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
# BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
# WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
# OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
# IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# ------------------------------------------------------------------------------

import struct
import os
import sys
sys.path.insert(0, os.path.join('..', '..', 'scripts'))
from bin_generator import mlb_binary_encode

# debug output controls
PRINT_LABELS = 0
PRINT_IMAGES = 0

OUTPUT_RAW_FOLDER    = 'processed_inputs'
OUTPUT_BIN_FOLDER    = 'processed_bin'
DOWNLOADS_FOLDER     = 'downloads'
RAW_IMAGE_FILE_PEFIX = 'mnist_test_image_'

# Reference:
# http://yann.lecun.com/exdb/mnist/

# create the output folder(s)
for out_dir in [OUTPUT_RAW_FOLDER, OUTPUT_BIN_FOLDER]:
    if not os.path.exists(out_dir):
        os.makedirs(out_dir)

# open the label file
label_file = os.path.join(DOWNLOADS_FOLDER, 't10k-labels-idx1-ubyte')
fd = open(label_file)

# read the magic# and number of items
magic = struct.unpack('>i', (fd.read(4)))[0]
num_items = struct.unpack('>i', (fd.read(4)))[0]

if PRINT_LABELS: print 'magic = ' + str(magic)
if PRINT_LABELS: print 'num_items = ' + str(num_items)

# read all the labels(each is a ubyte)
labelArr = []
for i in range(num_items):
    label = struct.unpack('B', fd.read(1))[0]
    if PRINT_LABELS: print str(i) + ':' + str(label)
    labelArr.append(label)

# close the label file
fd.close()

# open the raw-image file
image_file = os.path.join(DOWNLOADS_FOLDER, 't10k-images-idx3-ubyte')
fd = open(image_file)

# read the magic# and number of items
magic = struct.unpack('>i', (fd.read(4)))[0]
num_items = struct.unpack('>i', (fd.read(4)))[0]

# read the number of rows and columns(i know its going to be 28!)
num_rows = struct.unpack('>i', (fd.read(4)))[0]
num_cols = struct.unpack('>i', (fd.read(4)))[0]

if PRINT_IMAGES: print 'magic = ' + str(magic)
if PRINT_IMAGES: print 'num_items = ' + str(num_items)
if PRINT_IMAGES: print 'num_rows = ' + str(num_rows)
if PRINT_IMAGES: print 'num_cols = ' + str(num_cols)

# we will create a golden label file
# - but delet it first if it exists
golden_label_file = os.path.join(OUTPUT_RAW_FOLDER, RAW_IMAGE_FILE_PEFIX + 'golden_labels')
if os.path.isfile(golden_label_file):
    os.remove(golden_label_file)

for i in range(num_items):
    image = []
    for row in range(num_rows):
        for col in range(num_cols):
            pixel = struct.unpack('B', fd.read(1))[0]
            image.append(pixel)
    # dump the raw values into a file
    outputFilename = os.path.join(OUTPUT_RAW_FOLDER, RAW_IMAGE_FILE_PEFIX + str(str(i).zfill(5)))
    of = open(outputFilename, 'w')
    of.write('# input for MNIST image ' + str(str(i).zfill(5)) + '\n')
    of.write('delta=1' + '\n')
    of.write('offset=0' + '\n')
    of.write('bufsize=' + str(num_rows*num_cols) + '\n')
    for p in range(len(image)):
        of.write(str(image[p]) + '\n')
    of.close()

    # convert the tensor values into mlb-binary format
    mlb_binary_encode(outputFilename, os.path.join(OUTPUT_BIN_FOLDER, RAW_IMAGE_FILE_PEFIX + str(str(i).zfill(5))) + '.bin')

    # store the filename and its correct label
    lf = open(golden_label_file, 'a')
    lf.write(outputFilename + ',' + str(labelArr[i]) + '\n')
    lf.close()

# close the raw-image file
fd.close()

