#!/usr/bin/env python

# ------------------------------------------------------------------------------
# Copyright (c) 2018, The Linux Foundation. All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are
# met:
#     * Redistributions of source code must retain the above copyright
#       notice, this list of conditions and the following disclaimer.
#     * Redistributions in binary form must reproduce the above
#       copyright notice, this list of conditions and the following
#       disclaimer in the documentation and/or other materials provided
#       with the distribution.
#     * Neither the name of The Linux Foundation nor the names of its
#       contributors may be used to endorse or promote products derived
#       from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED
# WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT
# ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
# BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
# WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
# OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
# IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# ------------------------------------------------------------------------------


import argparse
import caffe
import numpy as np
import os
import sys

EXCLUDE_LAYER_NAMES = ["data"]

# a counter to keep track of global offsets
binary_offset = 0

class Quantizer:
    def __init__(self):
        self.delta  = 0
        self.offset = 0
    def set_quantization_params(self, input_min, input_max):
        fmin = min(input_min, 0.0)
        fmax = max(input_max, 0.0)
        self.delta = (fmax - fmin) / (255.0)
        self.offset = min(max((-1.0)*(fmin/self.delta), 0.0), 255.0)
    def quantize(self, f):
        return((f/self.delta) + self.offset)

def update_offset(tblob):
    global binary_offset
    x = (tblob.bufsize + 12)
    if (x%16) != 0:
        x += (16 - (x%16))
    binary_offset += x

class MLB_Tensor_Blob:
    def __init__(self):
        self.name    = ""
        self.type    = ""
        self.delta   = 0
        self.offset  = 0
        self.bufsize = 0
        self.params  = []
        self.op_min  = sys.float_info.max
        self.op_max  = sys.float_info.min
        self.min_max = False
    def set_op_min(self, num):
        if num < self.op_min:
            self.op_min = num
    def set_op_max(self, num):
        if num > self.op_max:
            self.op_max = num
    def __repr__(self):
        ret =  "# "       + str(self.name) + "_" + self.type + " offset=" + str(binary_offset) + '\n'
        ret += "tensor"   + '\n'
        if (self.min_max):
            # Get the q-params
            q = Quantizer()
            q.set_quantization_params(self.op_min, self.op_max)
            self.delta = q.delta
            self.offset = q.offset
        ret += "delta="   + str(self.delta)   + '\n'
        ret += "offset="  + str(int(round(self.offset)))  + '\n'
        ret += "bufsize=" + str(self.bufsize) + '\n'
        ret += '\n'.join(str(x) for x in self.params)
        ret += '\n'
        update_offset(self)
        return ret

def get_np_arr_from_file(filename, mode):
    delta   = 0.0
    offset  = 0
    bufsize = 0
    bufmode = 0
    lNum = 0
    valArr = []
    if not os.path.isfile(filename):
        sys.stderr.write('input file not found: ' + filename + '\n')
        return 
    with open(filename) as fd:
        for line in fd:
            if not line.strip(): continue # skip empty lines
            if line.lstrip()[0] == '#': continue # skip comment lines
            if line.lower().strip().find('delta') != -1:
                delta = float(line.split('=')[1].strip())
                continue
            if line.lower().strip().find('offset') != -1:
                offset = int(line.split('=')[1].strip())
                continue
            if line.lower().strip().find('bufsize') != -1:
                bufsize = int(line.split('=')[1].strip())
                lNum = 0
                bufmode = 1
                continue
            if bufmode == 1:
                if lNum < bufsize:
                    valArr.append((int(line)-offset)*delta)
                    lNum += 1
    return np.array(valArr)

if __name__ == "__main__":

    # Parse cmdline arguments
    parser = argparse.ArgumentParser('Extract Caffe net parameters')
    parser.add_argument('-m', dest='modelFile', type=str, required=True,  help='Path to Caffe model file')
    parser.add_argument('-p', dest='netFile',   type=str, required=True,  help='Path to Caffe netlist')
    parser.add_argument('-i', dest='inputList', type=str, required=False, help='List of inputs to determine o/p q-params')
    parser.add_argument('-o', dest='outFile',   type=str, required=False, help='Output file to dump params')

    args = parser.parse_args()

    # Create Caffe Net
    net = caffe.Net(args.netFile, 1, weights=args.modelFile)

    #output parameter file
    op_file_name = "model_params.txt" if args.outFile is None else args.outFile
    fp = open(op_file_name, 'w')

    # Read and dump blobs
    layer_name_list = [] # list to hold all layer names
    layer_tblob_dict = {}

    # parse through the net object to get all layer names
    for name in net.layer_dict.keys():
        if name.lower() not in EXCLUDE_LAYER_NAMES:
            layer_name_list.append(name)
            layer_tblob_dict[name] = []
            layer_tblob_dict[name].append(MLB_Tensor_Blob())
            layer_tblob_dict[name][0].name = name
            layer_tblob_dict[name][0].type = "output"

    # parse through net object's params dict to get layer weights/biases
    for name, blobs in net.params.iteritems():
        for i in range(len(blobs)):
            # Create a Tensor_Blob class object
            tblob = MLB_Tensor_Blob()
            tblob.name = name

            # determine whether we're dealing with weight or bias
            if i == 0: tblob.type = "weight" # Weights
            if i == 1: tblob.type = "bias"   # Biases
            else:pass

            # Get the q-params
            q = Quantizer()
            q.set_quantization_params(blobs[i].data.min(),blobs[i].data.max())
            it = np.nditer(blobs[i].data, op_flags=['readwrite'])
            tblob.delta = q.delta
            tblob.offset = q.offset

            # quantize the array values from float to 8b
            for x in it:
                x[...] = int(round(q.quantize(x)))
            tblob.params = (blobs[i].data.astype(np.uint8,casting='unsafe')).flatten()
            tblob.bufsize = len(tblob.params)

            layer_tblob_dict[name].append(tblob)

    # Create Caffe Net
    # unfortunately this needs to be done again as the previous net object
    # no longer produces correct results
    net = caffe.Net(args.netFile, 1, weights=args.modelFile)
    # check if the user has passed a list of input files
    if args.inputList != None:
        print "reading inputs from " + args.inputList
        with open(args.inputList) as fd:
            for line in fd:
                if not line.strip(): continue # skip empty lines
                if line.lstrip()[0] == '#': continue # skip comment lines
                line = line.strip()
                input_arr = get_np_arr_from_file(line, 'text')
                shape_vec = []
                for x in net.blobs['data'].shape:
                    shape_vec.append(x)
                net.blobs['data'].reshape(1, shape_vec[1], shape_vec[2], shape_vec[3])
                net.blobs['data'].data[...] = input_arr.reshape(1, shape_vec[1], shape_vec[2], shape_vec[3])
                for layer in net.layer_dict.keys():
                    if layer in EXCLUDE_LAYER_NAMES: continue
                    layer_op = net.forward(end=layer)
                    layer_tblob_dict[layer][0].min_max = True
                    layer_tblob_dict[layer][0].set_op_min(np.min(layer_op.values()).item())
                    layer_tblob_dict[layer][0].set_op_max(np.max(layer_op.values()).item())
    else:
        print "[WARNING] no input list provided, all o/p quantization parameters will be 0"

    # write the tensor-blobs to output
    for name in layer_name_list:
        idx_list = [0] if len(layer_tblob_dict[name]) == 1 else [1, 2, 0]
        for idx in idx_list:
            fp.write(str(layer_tblob_dict[name][idx]) + '\n')
    fp.close()
