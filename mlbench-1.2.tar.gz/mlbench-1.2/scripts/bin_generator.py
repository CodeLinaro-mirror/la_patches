#!/usr/bin/env python

# ------------------------------------------------------------------------------
# Copyright (c) 2018, The Linux Foundation. All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are
# met:
#     * Redistributions of source code must retain the above copyright
#       notice, this list of conditions and the following disclaimer.
#     * Redistributions in binary form must reproduce the above
#       copyright notice, this list of conditions and the following
#       disclaimer in the documentation and/or other materials provided
#       with the distribution.
#     * Neither the name of The Linux Foundation nor the names of its
#       contributors may be used to endorse or promote products derived
#       from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED
# WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT
# ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
# BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
# WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
# OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
# IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# ------------------------------------------------------------------------------


import struct
import sys
import argparse
import os

DEBUG = 0 # control output verbosity

def mlb_binary_encode(inputFile, outputFile):
    # Open the file
    try:
        fp = open(inputFile, 'r')
    except IOError:
        sys.stderr.write('cannot open input file: ' + inputFile + '\n')
        return
    fp.close()

    # read the contents of input file
    with open(inputFile) as fd:
        outfile = outputFile
        if os.path.exists(outfile): os.remove(outfile)
        bufmode = 0
        lNum = 0
        delta = 0.0
        offset = 0
        bufsize = 0
        valArr = []
        needflush = 0
        for line in fd:
            if DEBUG: print 'line=' + line.strip()
            if DEBUG: print 'DD: bufmode=' + str(bufmode) + ', lNum=' + str(lNum) + ', bufsize=' + str(bufsize)
            if not line.strip(): continue # skip empty lines
            if line.lstrip()[0] == '#': continue # skip comment lines
            if line.lower().strip().find('delta') != -1:
                delta = float(line.split('=')[1].strip())
            if line.lower().strip().find('offset') != -1:
                offset = int(line.split('=')[1].strip())
            if line.lower().strip().find('bufsize') != -1:
                bufsize = int(line.split('=')[1].strip())
                lNum = 0
                bufmode = 1
            if (bufmode == 1) and (lNum > 0) and (lNum <= bufsize):
                valArr.append(int(line.strip()))
            if (bufmode == 1): lNum += 1
            if (lNum > bufsize):
                if DEBUG: print '[needflush] lnum = ' + str(lNum) + ' bufsize=' + str(bufsize)
                needflush = 1
            if (needflush == 1) and (bufmode == 1):
                bufmode = 0
                lNum = 0
                if DEBUG: print '[FLUSH]: entered flush'
                if DEBUG: print 'TensorStats: Delta    = ' + str(delta)
                if DEBUG: print 'TensorStats: Offset   = ' + str(offset)
                if DEBUG: print 'TensorStats: numBytes = ' + str(bufsize)
                if DEBUG: print 'TensorStats: len(valArr) = ' + str(len(valArr))
                # append bytes to valArr (multiple of 16)
                arrlen = len(valArr)
                if ((arrlen+4+4+4) % 16) != 0:
                    diff = 16 - ((arrlen+4+4+4)%16)
                    for i in range(diff):
                        if DEBUG: print "appendloop i=" + str(i)
                        valArr.append(0)
                po = 'f' + 'ii' + 'B'*len(valArr)
                arrstruct = struct.pack(po, delta, offset, bufsize, *valArr)
                ofd = open(outfile, "ab")
                ofd.write(arrstruct)
                ofd.close()
                needflush = bufmode = 0
                valArr = []
    return

if __name__ == "__main__":
    # parse the command line args
    parser = argparse.ArgumentParser()
    parser.add_argument('-i', dest='inputFile', type=str, required=True, help="input filename containing the tensor parameters")
    parser.add_argument('-o', dest='outputFile', type=str, required=False, help="output filename which will have tensors encoded as binary")
    args = parser.parse_args()
    if args.outputFile is None:
        args.outputFile = args.inputFile + '.bin'
    mlb_binary_encode(args.inputFile, args.outputFile)

