#Init
#unzip HY11-N4190-5.zip
tar -xzvf PATCH_MSM8660_1087Release_Fluid_open_source_patches_20110315.tar.gz

export PATCH_MAINLINED_PATH=PATCH_MSM8660_1087Release_Fluid_open_source_patches_20110315/patches_mainlined
export PROPRIETARY_FOLDER_PATH=HY11-N4190-5_1.0.85/LINUX/android/vendor/qcom/proprietary

#gather non-proprietary patches to one folder
mkdir patches
cp -r ${PATCH_MAINLINED_PATH}/* patches

#Define base directory
export CAF_BASE=`pwd`

mkdir 8660_1087_caf
cd 8660_1087_caf
export CAF_BUILD_BASE=`pwd`
repo init -u git://codeaurora.org/platform/manifest.git -b gingerbread_rel -m M8660AAABQNLYA1087.xml
repo sync -j4

source build/envsetup.sh

choosecombo 1 1 msm8660_surf eng

repo start work --all

#Start applying patches
croot
cd kernel
git reset --hard 98019f7e6455fe679db02df1a0eeb7acc7f155e1

croot
cd external/dhcpcd
git am --ignore-whitespace $CAF_BASE/patches/external/dhcpcd/*.patch

croot
cd system/core/rootdir
git am --ignore-whitespace $CAF_BASE/patches/system/core/rootdir/*.patch

croot
cd device/qcom/msm8660_surf
git am --ignore-whitespace $CAF_BASE/patches/device/qcom/msm8660_surf/*.patch


#Apply proprietary folder
croot
mkdir vendor/qcom/proprietary
cp -r $CAF_BASE/${PROPRIETARY_FOLDER_PATH}/* vendor/qcom/proprietary

#Cleanup created folders
#rm -rf $CAF_BASE/patches
#rm -rf $CAF_BASE/${PATCH_MAINLINED_PATH}

#Change file props to run build scrips
chmod 755 vendor/qcom/proprietary/common/scripts/*

make -j4
