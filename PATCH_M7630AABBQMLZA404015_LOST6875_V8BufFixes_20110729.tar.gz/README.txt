1. apply Webkit_Remove_the_v8_leading_structure_from_the_V8_repository.patch in /external/webkit

2. apply V8FixesAndNewDirectoryStructure.patch in /external/v8 (baseline M7630AABBQMLZA404015)
e.g. patch -p1 -i V8FixesAndNewDirectoryStructure.patch
