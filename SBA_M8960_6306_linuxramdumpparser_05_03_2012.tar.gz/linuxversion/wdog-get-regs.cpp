/* Copyright (c) 2011-2012, Code Aurora Forum. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 and
 * only version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include <iostream>
#include <fstream>
#include <vector>
#include <map>
#include <string>
#include <stdlib.h>
#include <limits.h>

#include <cstring>
#include <cstdlib>
#include <sys/stat.h>
#include "unwind.h"

#include "linuxstructs.h"
#include "unwind.h"

#define dfprintf

using namespace std;
#define MAX_STACK_WALKBACK 128
#define MAX_PROCESSES 1000

#define IMEM_DEBUG_LOC 0x658
void (*arm_unwind_backtrace)(unsigned int, unsigned int, unsigned int)
	= unwind_backtrace;

typedef unsigned int uint32;
unsigned int get_virt_print(unsigned int phys_address);

char nmpath[] = "./arm-eabi-nm";
char gdbpath[] = "./arm-eabi-gdb";
char gdbcmds[] = "./cmds.txt";
#define PATHDELIM "/"
#define PATHDELIMCHAR '/'

uint32 current_c0;
uint32 current_c1;
uint32 ebi_start;
unsigned int chip = -1;
int nosymbols = 0;

char *ebi1cs1 = NULL, *ebics0 = NULL;
char *imem_c = NULL;

#define BM(msb, lsb)    (((((unsigned int)-1) << (31-msb)) >> (31-msb+lsb)) << lsb)
#define BVALSEL(msb, lsb, val)     ((val & BM(msb,lsb)) >> lsb)

static int offset_tasks, offset_comm, offset_stack,
	offset_thread_group, offset_pid, offset_state, offset_exit_state;;
char vmlinux_cmd[1024];
char vmlinuxpath[1024], ebics0_path[1024], ebi1cs1_path[1024];

unsigned int rev_lookup(const char *symname, unsigned int *size = NULL);
unsigned int get_real_offset(unsigned int offset);
fstream *open_ebi(unsigned int offset);

unsigned int page_offset = PAGE_OFFSET;
unsigned int phys_offset = PHYS_OFFSET;
unsigned int linuxversion;
int wdog;

int more_than_512mb_ram = 0;
int one_ebi_file = 0;
struct unwind_idx *unwind_table;
struct unwind_idx *end_unwind_table;
int custom_phys_offset = 0;
unsigned int in_panic;
unsigned int imem_offset;
string outputdir;
FILE *outputpath;

typedef  unsigned int uint32_t;


#define sprintf_s snprintf
#define char char
#define _TCHAR char

struct offset_rec {
	string sym;
	string mem;
	unsigned int offset;
	unsigned int szof;
};

struct range_struct {
	unsigned int begin;
	unsigned int end;
};

struct special_sym {
	int type;
	char symname[256];
	char symtype[256];
	int address;
};

vector <special_sym> spinlocks;
vector <special_sym> mutexes;

struct ramfile_s {
	fstream *f;
	struct range_struct range;
	struct stat *stFileInfo;
	char ramfile_name[1024];
};

vector<ramfile_s> ramfiles;

struct hw_info {
	unsigned int hw_ascii_id;
	unsigned int hw_id;
	unsigned ebi_begin;
	unsigned int assumed_phys_offset;
	unsigned int assumed_imem_debug_offset;
	unsigned int imemc_begin;
};

struct hw_info hw_ids[] = {
	{0x30363638, 8660, 0x40000000, 0x40200000, 0x2a05f658, 0x2a05f000},
	{0x30363938, 8960, 0x80000000, 0x80200000, 0x2a03f658, 0x2a03f000},
	{0x34363038, 8064, 0x80000000, 0x80200000, 0x2a03f658, 0x2a03f000},
	{0x35313639, 9615, 0x40000000, 0x40800000, 0x0, 0x0},
};

#define TEMP_NAME "tempsdfwekrhewl2394728937.txt"
#define TEMP_NAME_RESULT "offsets79642340.txt"
#define SYSMAPFILE "Sysmap.x1234"
#define SYSMAPOUT "sysmapout.txt"

map <string, int> offsetmap;

offset_rec offsets_required_2_6_35[] = {
	{"init_task", "comm", 0},
	{"init_task", "pid", 0},
	{"init_task", "tasks", 0},
	{"init_task", "stack", 0},
	{"init_task", "thread_group", 0},
	{"init_task", "state", 0},
	{"init_task", "exit_state", 0},
	{"((struct workqueue_struct *)0x0)", "cpu_wq", 0},
	{"((struct workqueue_struct *)0x0)", "name", 0},
	{"((struct cpu_workqueue_struct *)0x0)", "worklist", 0},
	{"((struct cpu_workqueue_struct *)0x0)", "current_work", 0},
	{"((struct work_struct *)0x0)", "func", 0},
	{"((struct work_struct *)0x0)", "entry", 0},
	{"((struct cpu_workqueue_struct *)0x0)", "thread", 0},
	{"((struct irq_chip *)0x0)", "name", 0},
	{"irq_desc", "kstat_irqs", 0},
	{"((struct irqaction *)0x0)", "name", 0},
	{"irq_desc", "action", 0},
	{"irq_desc", "chip", 0},
	{"irq_desc", "irq_count", 0},
	{"irq_desc", "irq", 0},
	{"irq_desc", "handle_irq", 0},
	{"((struct vfsmount *)0x0)", "mnt_mountpoint", 0},
	{"((struct dentry *)0x0)", "d_subdirs", 0},
	{"((struct super_block *)0x0)", "s_root", 0},
	{"((struct vfsmount *)0x0)", "mnt_sb", 0},
	{"((struct delayed_work *)0x0)", "timer"},
	{"((struct timer_list *)0x0)", "expires"},
	{"sizeof(irq_desc[0])", "", 0, 1},
};

offset_rec offsets_required_2_6_38[] = {
	{"init_task", "comm", 0},
	{"init_task", "pid", 0},
	{"init_task", "tasks", 0},
	{"init_task", "stack", 0},
	{"init_task", "thread_group", 0},
	{"init_task", "state", 0},
	{"init_task", "exit_state", 0},
	{"((struct irq_chip *)0x0)", "name", 0},
	{"irq_desc", "kstat_irqs", 0},
	{"((struct irqaction *)0x0)", "name", 0},
	{"irq_desc", "action", 0},
	{"irq_desc", "chip", 0},
	{"irq_desc", "irq_count", 0},
	{"irq_desc", "irq", 0},
	{"irq_desc", "handle_irq", 0},
	{"((struct vfsmount *)0x0)", "mnt_mountpoint", 0},
	{"((struct dentry *)0x0)", "d_subdirs", 0},
	{"((struct super_block *)0x0)", "s_root", 0},
	{"((struct vfsmount *)0x0)", "mnt_sb", 0},
	{"((struct work_struct *)0x0)", "func"},
	{"((struct work_struct *)0x0)", "entry"},
	{"((struct task_struct *)0x0)", "comm"},
	{"((struct worker *)0x0)", "entry"},
	{"((struct worker *)0x0)", "task"},
	{"((struct worker *)0x0)", "scheduled"},
	{"((struct global_cwq *)0x0)", "busy_hash"},
	{"((struct global_cwq *)0x0)", "idle_list"},
	{"((struct worker *)0x0)", "current_work"},
	{"((struct worker *)0x0)", "hentry"},
	{"((struct workqueue_struct *)0x0)", "cpu_wq"},
	{"((struct delayed_work *)0x0)", "timer"},
	{"((struct timer_list *)0x0)", "expires"},
	{"((struct global_cwq *)0x0)", "worklist"},
	{"sizeof(irq_desc[0])", "", 0, 1},
};

offset_rec offsets_required_30[] = {
        {"init_task", "comm", 0},
        {"init_task", "pid", 0},
        {"init_task", "tasks", 0},
        {"init_task", "stack", 0},
        {"init_task", "thread_group", 0},
        {"init_task", "state", 0},
        {"init_task", "exit_state", 0},
        {"((struct irq_chip *)0x0)", "name", 0},
        {"irq_desc", "kstat_irqs", 0},
        {"((struct irqaction *)0x0)", "name", 0},
        {"irq_desc", "action", 0},
        {"irq_desc", "irq_data", 0},
        {"irq_desc", "irq_count", 0},
        {"irq_desc", "handle_irq", 0},
        {"((struct irq_data *)0x0)", "chip", 0},
        {"((struct irq_data *)0x0)", "irq", 0},
        {"((struct vfsmount *)0x0)", "mnt_mountpoint", 0},
        {"((struct dentry *)0x0)", "d_subdirs", 0},
        {"((struct super_block *)0x0)", "s_root", 0},
        {"((struct vfsmount *)0x0)", "mnt_sb", 0},
        {"((struct work_struct *)0x0)", "func"},
        {"((struct work_struct *)0x0)", "entry"},
        {"((struct task_struct *)0x0)", "comm"},
        {"((struct worker *)0x0)", "entry"},
        {"((struct worker *)0x0)", "task"},
        {"((struct worker *)0x0)", "scheduled"},
        {"((struct global_cwq *)0x0)", "busy_hash"},
        {"((struct global_cwq *)0x0)", "idle_list"},
        {"((struct worker *)0x0)", "current_work"},
        {"((struct worker *)0x0)", "hentry"},
		{"((struct cpu_workqueue_struct *)0x0)", "delayed_works"},
		{"((struct workqueue_struct *)0x0)", "cpu_wq"},
		{"((struct delayed_work *)0x0)", "timer"},
		{"((struct timer_list *)0x0)", "expires"},
		{"((struct global_cwq *)0x0)", "worklist"},
		{"sizeof(irq_desc[0])", "", 0, 1},
};

enum msm_cpu {
	MSM_CPU_UNKNOWN = 0,
	MSM_CPU_7X01,
	MSM_CPU_7X25,
	MSM_CPU_7X27,
	MSM_CPU_8X50,
	MSM_CPU_8X50A,
	MSM_CPU_7X30,
	MSM_CPU_8X55,
	MSM_CPU_8X60 = 8660,
	MSM_CPU_8960 = 8960,
	MSM_CPU_7X27A,
	FSM_CPU_9XXX,
	MSM_CPU_7X25A,
	MSM_CPU_7X25AA,
	MSM_CPU_8064 = 8064,
	MSM_CPU_8930 = 8960,
	MSM_CPU_7X27AA,
	MSM_CPU_9615 = 9615,
	MSM_CPU_COPPER,
	MSM_CPU_8627,
	MSM_CPU_8625 = 9615,
};

struct cpu_info {
	int id;
	int cpu;
	const char *cpuname;
};

static cpu_info cpu_of_id[] =
{

	/* 7x01 IDs */
	{1,  MSM_CPU_7X01, "MSM_CPU_7X01"},
	{16, MSM_CPU_7X01, "MSM_CPU_7X01"},
	{17, MSM_CPU_7X01, "MSM_CPU_7X01"},
	{18, MSM_CPU_7X01, "MSM_CPU_7X01"},
	{19, MSM_CPU_7X01, "MSM_CPU_7X01"},
	{23, MSM_CPU_7X01, "MSM_CPU_7X01"},
	{25, MSM_CPU_7X01, "MSM_CPU_7X01"},
	{26, MSM_CPU_7X01, "MSM_CPU_7X01"},
	{32, MSM_CPU_7X01, "MSM_CPU_7X01"},
	{33, MSM_CPU_7X01, "MSM_CPU_7X01"},
	{34, MSM_CPU_7X01, "MSM_CPU_7X01"},
	{35, MSM_CPU_7X01, "MSM_CPU_7X01"},

	/* 7x25 IDs */
	{20, MSM_CPU_7X25, "MSM_CPU_7X25"},
	{21, MSM_CPU_7X25, "MSM_CPU_7X25"}, /* 7225 */
	{24, MSM_CPU_7X25, "MSM_CPU_7X25"}, /* 7525 */
	{27, MSM_CPU_7X25, "MSM_CPU_7X25"}, /* 7625 */
	{39, MSM_CPU_7X25, "MSM_CPU_7X25"},
	{40, MSM_CPU_7X25, "MSM_CPU_7X25"},
	{41, MSM_CPU_7X25, "MSM_CPU_7X25"},
	{42, MSM_CPU_7X25, "MSM_CPU_7X25"},
	{62, MSM_CPU_7X25, "MSM_CPU_7X25"}, /* 7625-1 */
	{63, MSM_CPU_7X25, "MSM_CPU_7X25"}, /* 7225-1 */
	{66, MSM_CPU_7X25, "MSM_CPU_7X25"}, /* 7225-2 */


	/* 7x27 IDs */
	{43, MSM_CPU_7X27, "MSM_CPU_7X27"},
	{44, MSM_CPU_7X27, "MSM_CPU_7X27"},
	{61, MSM_CPU_7X27, "MSM_CPU_7X27"},
	{67, MSM_CPU_7X27, "MSM_CPU_7X27"}, /* 7227-1 */
	{68, MSM_CPU_7X27, "MSM_CPU_7X27"}, /* 7627-1 */
	{69, MSM_CPU_7X27, "MSM_CPU_7X27"}, /* 7627-2 */


	/* 8x50 IDs */
	{30, MSM_CPU_8X50, "MSM_CPU_8X50"},
	{36, MSM_CPU_8X50, "MSM_CPU_8X50"},
	{37, MSM_CPU_8X50, "MSM_CPU_8X50"},
	{38, MSM_CPU_8X50, "MSM_CPU_8X50"},

	/* 7x30 IDs */
	{59, MSM_CPU_7X30, "MSM_CPU_7X30"},
	{60, MSM_CPU_7X30, "MSM_CPU_7X30"},

	/* 8x55 IDs */
	{74, MSM_CPU_8X55, "MSM_CPU_8X55"},
	{75, MSM_CPU_8X55, "MSM_CPU_8X55"},
	{85, MSM_CPU_8X55, "MSM_CPU_8X55"},

	/* 8x60 IDs */
	{70, MSM_CPU_8X60, "MSM_CPU_8X60"},
	{71, MSM_CPU_8X60, "MSM_CPU_8X60"},
	{86, MSM_CPU_8X60, "MSM_CPU_8X60"},

	/* 8960 IDs */
	{87, MSM_CPU_8960, "MSM_CPU_8960"},

	/* 7x25A IDs */
	{88, MSM_CPU_7X25A, "MSM_CPU_7X25A"},
	{89, MSM_CPU_7X25A, "MSM_CPU_7X25A"},
	{96, MSM_CPU_7X25A, "MSM_CPU_7X25A"},

	/* 7x27A IDs */
	{90, MSM_CPU_7X27A, "MSM_CPU_7X27A"},
	{91, MSM_CPU_7X27A, "MSM_CPU_7X27A"},
	{92, MSM_CPU_7X27A, "MSM_CPU_7X27A"},
	{97, MSM_CPU_7X27A, "MSM_CPU_7X27A"},

	/* FSM9xxx ID */
	{94, FSM_CPU_9XXX, "FSM_CPU_9XXX"},
	{95, FSM_CPU_9XXX, "FSM_CPU_9XXX"},

	/*  7x25AA ID */
	{98, MSM_CPU_7X25AA, "MSM_CPU_7X25AA"},
	{99, MSM_CPU_7X25AA, "MSM_CPU_7X25AA"},
	{100, MSM_CPU_7X25AA, "MSM_CPU_7X25AA"},

	/*  7x27AA ID */
	{101, MSM_CPU_7X27AA, "MSM_CPU_7X27AA"},
	{102, MSM_CPU_7X27AA, "MSM_CPU_7X27AA"},
	{103, MSM_CPU_7X27AA, "MSM_CPU_7X27AA"},

	/* 9x15 ID */
	{104, MSM_CPU_9615, "MSM_CPU_9615"},
	{105, MSM_CPU_9615, "MSM_CPU_9615"},
	{106, MSM_CPU_9615, "MSM_CPU_9615"},
	{107, MSM_CPU_9615, "MSM_CPU_9615"},

	/* 8064 IDs */
	{109, MSM_CPU_8064, "MSM_CPU_8064"},
	{130, MSM_CPU_8064, "MSM_CPU_8064"},

	/* 8930 IDs */
	{116, MSM_CPU_8930, "MSM_CPU_8930"},
	{117, MSM_CPU_8930, "MSM_CPU_8930"},
	{118, MSM_CPU_8930, "MSM_CPU_8930"},
	{119, MSM_CPU_8930, "MSM_CPU_8930"},

	/* 8627 IDs */
	{120, MSM_CPU_8627, "MSM_CPU_8627"},
	{121, MSM_CPU_8627, "MSM_CPU_8627"},

	/* 8660A ID */
	{122, MSM_CPU_8960, "MSM_CPU_8960"},

	/* 8260A ID */
	{123, MSM_CPU_8960, "8260A"},

	/* 8060A ID */
	{124, MSM_CPU_8960, "8060A"},

	/* Copper IDs */
	{126, MSM_CPU_COPPER, "COPPER"},

	/* 8625 IDs */
	{127, MSM_CPU_8625, "MSM_CPU_8625"},
	{128, MSM_CPU_8625, "MSM_CPU_8625"},
	{129, MSM_CPU_8625, "MSM_CPU_8625"},

	/* Uninitialized IDs are not known to run Linux.
	   MSM_CPU_UNKNOWN is set to 0 to ensure these IDs are
	   considered as unknown CPU. */
};

#define BUILD_ID_LENGTH 32

struct socinfo_v1 {
	uint32_t format;
	uint32_t id;
	uint32_t version;
	char build_id[BUILD_ID_LENGTH];
};


offset_rec *offsets_required = NULL;
unsigned int offsets_required_size;

void fill_offset_map()
{
	fstream f1((outputdir+TEMP_NAME).c_str(), ios::out), f2;
	char gdb_cmd[4096];
	char gdbline[4096], *off;
	unsigned long offset;

	for(int i = 0; i < offsets_required_size; i++) {
		if(offsets_required[i].szof)
			f1 << "print " << offsets_required[i].sym << endl;
		else f1 << "print &" << offsets_required[i].sym << "." << offsets_required[i].mem << endl;
	}
	f1.close();

	sprintf_s(gdb_cmd, 1024, "%s -x %s --batch %s > %s",
			 gdbpath, (outputdir+TEMP_NAME).c_str(), vmlinuxpath, (outputdir+TEMP_NAME_RESULT).c_str());

	system(gdb_cmd);

	f2.open((outputdir+TEMP_NAME_RESULT).c_str(), ios::in);

	int i = 0;
	while(!f2.eof())
	{
		f2.getline(gdbline, 1024);

		if(!(strnlen(gdbline, 1024)>0))
			break;
		int x = strnlen(gdbline, 1024);

		while(gdbline[x]!=' ')
			x--;
		off = gdbline + x;

		if(!offsets_required[i].szof)
		offset = strtoul(off, NULL, 16);
		else offset = strtoul(off, NULL, 10);

		if(!offsets_required[i].szof)
			offset -= rev_lookup(offsets_required[i].sym.c_str());
		offsets_required[i].offset = offset;
		i++;
	}

	f2.clear();
	f2.close();
	return;
}

unsigned int get_offset_struct(const char *sym, const char *member, int szof = 0)
{
	fstream f1, f2;
	char gdb_cmd[4096];
	char gdbline[4096], *off;
	unsigned long offset;

	for(int i = 0; i < offsets_required_size; i++) {
		if( (offsets_required[i].sym.compare(sym)==0)
			&& (offsets_required[i].mem.compare(member)==0) )
				return offsets_required[i].offset;
	}

	f1.open((outputdir+TEMP_NAME).c_str(), ios::out);
	f1 << endl << "print &" << sym << "." << member << endl;
	f1.close();

	sprintf_s(gdb_cmd, 1024, "%s -x %s --batch %s > %s",
			 gdbpath, TEMP_NAME, vmlinuxpath, TEMP_NAME_RESULT);

	system(gdb_cmd);

	f2.open(TEMP_NAME_RESULT, ios::in);

	f2.getline(gdbline, 1024);

	int x = strnlen(gdbline, 1024);

	while(gdbline[x]!=' ')
		x--;
	off = gdbline + x;

	if(!szof)
		offset = strtoul(off, NULL, 16);
	else offset = strtoul(off, NULL, 10);

	if(!szof)
		offset -= rev_lookup(sym);

	f2.close();

	dfprintf(outputpath, "OFFSET (%s.%s): %lx, %lx", sym, member, offset, rev_lookup(sym));

	return offset;
}

struct sysmap_entry {
	unsigned int addr;
	char type[2];
	char symbol[256];
};

struct msm_watchdog_dump {
	uint32_t magic;
	uint32_t curr_cpsr;
	uint32_t usr_r0;
	uint32_t usr_r1;
	uint32_t usr_r2;
	uint32_t usr_r3;
	uint32_t usr_r4;
	uint32_t usr_r5;
	uint32_t usr_r6;
	uint32_t usr_r7;
	uint32_t usr_r8;
	uint32_t usr_r9;
	uint32_t usr_r10;
	uint32_t usr_r11;
	uint32_t usr_r12;
	uint32_t usr_r13;
	uint32_t usr_r14;
	uint32_t irq_spsr;
	uint32_t irq_r13;
	uint32_t irq_r14;
	uint32_t svc_spsr;
	uint32_t svc_r13;
	uint32_t svc_r14;
	uint32_t abt_spsr;
	uint32_t abt_r13;
	uint32_t abt_r14;
	uint32_t und_spsr;
	uint32_t und_r13;
	uint32_t und_r14;
	uint32_t fiq_spsr;
	uint32_t fiq_r8;
	uint32_t fiq_r9;
	uint32_t fiq_r10;
	uint32_t fiq_r11;
	uint32_t fiq_r12;
	uint32_t fiq_r13;
	uint32_t fiq_r14;
};

typedef struct tzbsp_dump_cpu_ctx_s
{
	uint32 mon_lr;
	uint32 mon_spsr;
	uint32 usr_r0;
	uint32 usr_r1;
	uint32 usr_r2;
	uint32 usr_r3;
	uint32 usr_r4;
	uint32 usr_r5;
	uint32 usr_r6;
	uint32 usr_r7;
	uint32 usr_r8;
	uint32 usr_r9;
	uint32 usr_r10;
	uint32 usr_r11;
	uint32 usr_r12;
	uint32 usr_r13;
	uint32 usr_r14;
	uint32 irq_spsr;
	uint32 irq_r13;
	uint32 irq_r14;
	uint32 svc_spsr;
	uint32 svc_r13;
	uint32 svc_r14;
	uint32 abt_spsr;
	uint32 abt_r13;
	uint32 abt_r14;
	uint32 und_spsr;
	uint32 und_r13;
	uint32 und_r14;
	uint32 fiq_spsr;
	uint32 fiq_r8;
	uint32 fiq_r9;
	uint32 fiq_r10;
	uint32 fiq_r11;
	uint32 fiq_r12;
	uint32 fiq_r13;
	uint32 fiq_r14;
} tzbsp_dump_cpu_ctx_t;

typedef struct tzbsp_dump_buf_s
{
	uint32 sc_status[2];
	tzbsp_dump_cpu_ctx_t sc_ns[2];
	tzbsp_dump_cpu_ctx_t sec;
} tzbsp_dump_buf_t;

#define TZBSP_CPU_COUNT				  0x2
#define V2TZBSP_DUMP_CTX_MAGIC        0x44434151
#define V2TZBSP_DUMP_CTX_VERSION      1
#define V2TZBSP_SC_STATUS_NS_BIT      0x01
#define V2TZBSP_SC_STATUS_WDT         0x02
#define V2TZBSP_SC_STATUS_SGI         0x04
#define V2TZBSP_SC_STATUS_WARM_BOOT   0x08

typedef struct tzbsp_dump_buf_s_v2_2core
{
  uint32 magic;
  uint32 version;
  uint32 cpu_count;
  uint32 sc_status[2];
  tzbsp_dump_cpu_ctx_t sc_ns[2];
  tzbsp_dump_cpu_ctx_t sec;
  uint32 wdt0_sts[2];
} tzbsp_dump_buf_t_v2_2core;

typedef struct tzbsp_dump_buf_s_v2_4core
{
  uint32 magic;
  uint32 version;
  uint32 cpu_count;
  uint32 sc_status[4];
  tzbsp_dump_cpu_ctx_t sc_ns[4];
  tzbsp_dump_cpu_ctx_t sec;
  uint32 wdt0_sts[4];
} tzbsp_dump_buf_t_v2_4core;

int which_reg_version;

tzbsp_dump_buf_t reg_dump_v1;
tzbsp_dump_buf_t_v2_2core reg_dump_v2_2core;
tzbsp_dump_buf_t_v2_4core reg_dump_v2_4core;

void do_exit(int code)
{
	unlink((outputdir+SYSMAPFILE).c_str());
	unlink((outputdir+SYSMAPOUT).c_str());
	unlink((outputdir+TEMP_NAME).c_str());
	unlink((outputdir+TEMP_NAME_RESULT).c_str());
	exit(code);
}

unsigned int get_current(unsigned int sp)
{
	return (sp & ~(THREAD_SIZE - 1));
}

int big_debug = 0;

void *read_struct(void *buf, int size, fstream *file, int offset)
{
	offset = get_real_offset(offset);

	if(file==NULL) {
		fprintf(outputpath, "INVALID ADDRESS. OPEN_EBI RETURNED ZERO. ABORTING.\n");
		do_exit(-1);
	}

	file->seekg(offset, ios::beg);

	if(file->eof() || file->fail() || file->bad())
		return NULL;

	file->read((char *)buf, size);

	if(file->fail() || file->bad())
		return NULL;

	return buf;
}

vector<sysmap_entry> symbol_table;

char * lookup(unsigned int addr, int *offset = NULL)
{
	if(symbol_table.empty())
		return NULL;

	if(addr == 0) return NULL;

	if(addr > symbol_table[symbol_table.size()-1].addr) return NULL;
	if(addr < symbol_table[0].addr) return NULL;

	int low = 0;
	int high = symbol_table.size()-1;

	int mid = (low+high)/2;
	int premid = 0;

	while(!(addr >= symbol_table[mid].addr
		&& addr < symbol_table[mid+1].addr)) {

		if(addr < symbol_table[mid].addr)
			high = mid - 1;

		if(addr > symbol_table[mid].addr)
			low = mid + 1;

		mid = (high+low)/2;

		if(mid==premid)
			return NULL;
		premid = mid;
	}

	if(offset) *offset = addr - symbol_table[mid].addr;

	if(symbol_table[mid].type[0] == 'T' || symbol_table[mid].type[0] == 't')
		return symbol_table[mid].symbol;
	else
		return NULL;
}

char * linlookup(unsigned int addr, int *offset = NULL)
{
	if(symbol_table.empty())
		return NULL;

	if(addr == 0)
		return NULL;

	if(addr > symbol_table[symbol_table.size()-1].addr)
		return NULL;
	if(addr < symbol_table[0].addr)
		return NULL;

	for(unsigned int k = 0; k < symbol_table.size()-1; k++) {
		if(addr >= symbol_table[k].addr
			&& addr < symbol_table[k+1].addr) {

		if(offset)
			*offset = addr - symbol_table[k].addr;

		if(symbol_table[k].type[0]=='T' ||
				symbol_table[k].type[0]=='t')
			return symbol_table[k].symbol;
		}
	}
	return NULL;
}

unsigned int rev_lookup(const char *symname, unsigned int *size)
{
	if(symbol_table.empty())
		return 0;

	if(symname == NULL)
		return 0;

	for(unsigned int k = 0; k < symbol_table.size()-1; k++) {
		if(!strncmp(symbol_table[k].symbol, symname, 256)) {
			dfprintf(outputpath, "Symbol matched (%s matched to input %s). Address = %x\n", symbol_table[k].symbol, symname, symbol_table[k].addr);
			if(size) *size = symbol_table[k+1].addr - symbol_table[k].addr;
			return symbol_table[k].addr;
		}
	}
	return 0;
}

unsigned int rev_lookup_prefix(const char *symname_prefix, int prefix_len, unsigned int *size = 0)
{
	if(symbol_table.empty())
		return 0;

	if(symname_prefix == NULL)
		return 0;

	for(unsigned int k = 0; k < symbol_table.size()-1; k++) {
		if(!strncmp(symbol_table[k].symbol, symname_prefix, prefix_len)) {
			if(size) *size = symbol_table[k+1].addr - symbol_table[k].addr;
			return symbol_table[k].addr;
		}
	}
	return 0;
}

#define MAX_STACK_READ 256

void dump_single_stack(unsigned int spaddr, FILE *fp = NULL)
{
	int i, offset;
	fstream *ebifile = open_ebi(spaddr);

	if(!ebifile) return;

	unsigned int stack[MAX_STACK_READ] = {0};

	read_struct(&stack, MAX_STACK_READ, ebifile, spaddr);

	for(i = 0; i < MAX_STACK_WALKBACK; i++) {
		offset = 0;
		if(lookup(stack[i], &offset)) {
			if(offset) {
				if(fp)
				fprintf(fp, "[%08X] %08X -- %s+0x%x\n", VIRT(spaddr) + (4*i), stack[i], lookup(stack[i], &offset), offset);
				else fprintf(outputpath, "[%08X] %08X -- %s+0x%x\n", VIRT(spaddr) + (4*i), stack[i], lookup(stack[i], &offset), offset);
			}

		}
	}
}

void get_offsets()
{
	offset_tasks = get_offset_struct("init_task", "tasks");
	offset_comm = get_offset_struct("init_task", "comm");
	offset_stack = get_offset_struct("init_task", "stack");
	offset_thread_group = get_offset_struct("init_task", "thread_group");
	offset_pid = get_offset_struct("init_task", "pid");
	offset_state = get_offset_struct("init_task", "state");
	offset_exit_state = get_offset_struct("init_task", "exit_state");

	unlink((outputdir+SYSMAPFILE).c_str());
}

int check_for_panic_stack(unsigned int sp, struct thread_info *thread, const char *taskname) {

	unsigned int pc=0, psize=0, lr, spx;
	unsigned int panic_addr = rev_lookup("panic", &psize);

	if(!open_ebi(PHY(sp)))
		return 0;

	for(unsigned int i=sp; i<=(sp+0x4000); i+=4) {
		read_struct(&pc, 4, open_ebi(PHY(i)), PHY(i));
		read_struct(&lr, 4, open_ebi(PHY(i+4)), PHY(i+4));
		read_struct(&spx, 4, open_ebi(PHY(i+8)), PHY(i+8));
		if(pc >= panic_addr && (pc <= (panic_addr + psize))) {
			fprintf(outputpath, "-------------------------------------------------\n");
			fprintf(outputpath, "[!] KERNEL PANIC detected!\n");
			fprintf(outputpath, "-------------------------------------------------\n");
			fprintf(outputpath, "Faulting process discovered. Name: %s, attempting to retrieve stack now: spx=%x, pc=%x\n", taskname, (i+4), pc);
			unwind_backtrace(i+4, 0, pc);

			fstream fp((outputdir+"regs_panic.cmm").c_str(), ios::out);

			if(fp.is_open()) {
				fp << "r.s pc " << pc << "." << endl;
				fp << "r.s r13 " << i+4 << "." << endl;
			}

			fp.close();

			in_panic = 1;
			return 1;
		}
	}

	for(unsigned int i=sp; i>=(sp-0x4000); i-=4) {
		read_struct(&pc, 4, open_ebi(PHY(i)), PHY(i));
		read_struct(&lr, 4, open_ebi(PHY(i+4)), PHY(i+4));
		read_struct(&spx, 4, open_ebi(PHY(i+8)), PHY(i+8));
		if(pc >= panic_addr && (pc <= (panic_addr + psize))) {
			fprintf(outputpath, "-------------------------------------------------\n");
			fprintf(outputpath, "[!] KERNEL PANIC detected!\n");
			fprintf(outputpath, "-------------------------------------------------\n");
			fprintf(outputpath, "Faulting process discovered. Name: %s, attempting to retrieve stack now: spx=%x, pc=%x\n", taskname, (i+4), pc);
			unwind_backtrace(i+4, 0, pc);

			fstream fp((outputdir+"regs_panic.cmm").c_str(), ios::out);

			if(fp.is_open()) {
				fp << "r.s pc " << pc << "." << endl;
				fp << "r.s r13 " << i+4 << "." << endl;
			}

			fp.close();

			in_panic = 1;
			return 1;
		}
	}

	return 0;
}

void dump_thread_group(unsigned int init_thread_group, int pr)
{
	char thread_task_name[16];
	unsigned int orig_thread_group, next_thread_start, next_thread_comm, next_thread_pid, next_thread_stack;
	unsigned int thread_task_pid, addr_stack;
	unsigned int next_thread_state, next_thread_exit_state;
	unsigned int task_state, task_exit_state;
	struct thread_info threadinfo;
	static int tgindex = 1;
	int i = 0;

	dfprintf(outputpath, "%s: step 1 (%x), phy=%x\n", __FUNCTION__, init_thread_group, PHY(init_thread_group));

	orig_thread_group = init_thread_group;
	int count = 0;
	do {

		if(count++>100) {
			fprintf(outputpath, "Too many members in this thread group!\n");
			return;
		}

		FILE *f;

		if(pr) {

			f = fopen((outputdir+"raw_stack_dumps.txt").c_str(), "a");

			if(f==0) {
				fprintf(outputpath, "[F] Couldn't open raw stack dumps file.\n");
				do_exit(-1);
			}
		}
		next_thread_start = init_thread_group - offset_thread_group;

		if(!PHY(next_thread_start)) {
			fprintf(outputpath, "[W] Possibly corrupt process list.\n");
			return;
		}

		next_thread_comm = PHY(next_thread_start + offset_comm);
		next_thread_pid = PHY(next_thread_start + offset_pid);
		next_thread_stack = PHY(next_thread_start + offset_stack);
		next_thread_state = PHY(next_thread_start + offset_state);
		next_thread_exit_state = PHY(next_thread_start + offset_exit_state);

		dfprintf(outputpath, "%s: step 2 (%x), PHY(%x)\n", __FUNCTION__, next_thread_start, PHY(next_thread_start));

		if (!open_ebi(next_thread_comm))
			return;

		read_struct(thread_task_name, 16, open_ebi(next_thread_comm), next_thread_comm);
		if(!(thread_task_name[0] >= 'a' && thread_task_name[0] <= 'z')
			&& !(thread_task_name[0] >= 'A' && thread_task_name[0] <= 'Z')
			&& !(thread_task_name[0] >= '0' && thread_task_name[0] <= '9')) {
			thread_task_name[15]= '\0';
			if(pr)
				fprintf(outputpath, "[W] Possibly corrupt process list. (process name = %s)\n", thread_task_name);
			return;
		}
		dfprintf(outputpath, "%s: step 2.1\n", __FUNCTION__);
		read_struct((char *)&thread_task_pid, 4, open_ebi(next_thread_pid), next_thread_pid);
		dfprintf(outputpath, "%s: step 2.2 (%x), phy=%x\n", __FUNCTION__, next_thread_state, PHY(next_thread_state));
		read_struct((char *)&task_state, 4, open_ebi(next_thread_state), next_thread_state);
		dfprintf(outputpath, "%s: step 2.3\n", __FUNCTION__);
		read_struct((char *)&task_exit_state, 4, open_ebi(next_thread_exit_state), next_thread_exit_state);
		dfprintf(outputpath, "%s: step 2.4\n", __FUNCTION__);
		read_struct((char *)&addr_stack, 4, open_ebi(next_thread_stack), next_thread_stack);

		dfprintf(outputpath, "%s: step 3\n", __FUNCTION__);

		if(!open_ebi(PHY(addr_stack))) {
			return;
		}

		dfprintf(outputpath, "%s: step 4(addr_stck = %x, phy = %x)\n", __FUNCTION__, addr_stack, PHY(addr_stack));

		read_struct(&threadinfo, sizeof(struct thread_info), open_ebi(PHY(addr_stack)), PHY(addr_stack));

		if(threadinfo.cpu > 3 || threadinfo.cpu < 0) return;

		dfprintf(outputpath, "%s: step 5\n", __FUNCTION__);

		if(i++==0)
			if(pr) fprintf(outputpath, "%d. Process: %s, cpu: %d, pid: %d, start: 0x%x\n==========================================================\n\n", tgindex++,
							thread_task_name, threadinfo.cpu, thread_task_pid, next_thread_start);

		dfprintf(outputpath, "%s: step 6\n", __FUNCTION__);

		if(pr) {
			fprintf(outputpath, "	Task name: %s, pid: %d, cpu: %d, \n	state: 0x%x, exit_state: 0x%x, stack_base: 0x%x\n", thread_task_name, thread_task_pid,
			threadinfo.cpu, task_state, task_exit_state, addr_stack);
			fprintf(outputpath, "	Stack: \n");
			arm_unwind_backtrace((threadinfo.cpu_context.sp), (threadinfo.cpu_context.fp), (threadinfo.cpu_context.pc));
			fprintf(outputpath, "----------------------------------------------------------\n");

			fprintf(f, "--------------------------\n");

			fprintf(f, "	Task name: %s, pid: %d, cpu: %d, \n	state: 0x%x, exit_state: 0x%x, stack_base: 0x%x\n", thread_task_name, thread_task_pid,
			threadinfo.cpu, task_state, task_exit_state, addr_stack);

			fprintf(f, "	Stack (sp = %x): \n", threadinfo.cpu_context.sp);

			dump_single_stack(PHY(threadinfo.cpu_context.sp), f);

		}

		dfprintf(outputpath, "%s: step 7, (%x, %x)\n", __FUNCTION__,  threadinfo.cpu_context.sp, PHY(threadinfo.cpu_context.sp));

		unsigned int panic_sp = 0;

		if(!pr && task_state==0) {
			check_for_panic_stack(addr_stack, &threadinfo, thread_task_name);
		}

		dfprintf(outputpath, "%s: step 8, (%x, %x)\n", __FUNCTION__,  threadinfo.cpu_context.sp, PHY(threadinfo.cpu_context.sp));
		unsigned int stack_value;
		int p=0;

		if(pr) {
			fprintf(f, "SP: 0x%08x", threadinfo.cpu_context.sp);
			for(int k = threadinfo.cpu_context.sp; k < threadinfo.cpu_context.sp+256; k+=4) {
				if(!open_ebi(PHY(k)))
					return;

				if(p % 8 == 0){
					fprintf(f, "\n", k);
					fprintf(f, "[%08x]: ", k);
				}
				p++;
				read_struct(&stack_value, 4, open_ebi(PHY(k)), PHY(k));
				fprintf(f, " %08x", stack_value);
				if(p>=256) break;
			}
		}

		dfprintf(outputpath, "%s: step 9, (%x, %x)\n", __FUNCTION__, threadinfo.cpu_context.sp, PHY(threadinfo.cpu_context.sp));

		if(pr) {
			fprintf(f, "--------------------------\n");
			fclose(f);
		}

		read_struct((char *)&init_thread_group, 4, open_ebi(PHY(next_thread_start)), PHY(next_thread_start + offset_thread_group));

	}while(init_thread_group != orig_thread_group);

	if(pr) fprintf(outputpath, "----------------------------------------------------------\n\n");

}

void do_dump_stacks(int pr = 1)
{
	unsigned int init_addr = rev_lookup("init_task");
	char init_task_name[16];
	char gdb_cmd[1024];
	unsigned int init_comm, init_pid, init_next_task, orig_init_next_task, cur_task, init_thread_group;
	int offset = 0;
	fstream *ebifile;
	unsigned int addr_stack, init_stack;
	unsigned int threadstack[256];
	struct thread_info threadinfo;
	char *lookupsym;
	int ret;

	if(pr) fprintf(outputpath, "\n");
	if(pr) fprintf(outputpath, "Extracting per-thread-group information now.\n");

	get_offsets();
	if(pr) fprintf(outputpath, "\n");

	dfprintf(outputpath, "INIT TASK is at %x\n", init_addr);

	init_comm = PHY(init_addr) + offset_comm;
	init_stack = PHY(init_addr) + offset_stack;
	init_next_task = PHY(init_addr) + offset_tasks;
	init_pid = PHY(init_addr) + offset_pid;
	init_thread_group = PHY(init_addr) + offset_thread_group;
	orig_init_next_task = VIRT(init_next_task);

	dfprintf(outputpath, "init_next_task: %x\n",init_next_task );
	dfprintf(outputpath, "init_thread_group: %x\n",init_thread_group );

	ebifile = open_ebi(init_comm);

	if(!ebifile || !ebifile->is_open()) {
		return;
	}

	int x = 0;
	do {
		if(!open_ebi(init_next_task)) {
			if(pr) fprintf(outputpath, "init_next_task: %x", init_next_task);
			if(pr) fprintf(outputpath, "[!] Process list corrupted. Aborting listing...\n");
			return;
		}


		dfprintf(outputpath, "Next task is %x...\n", VIRT(init_next_task));
		read_struct((char *)&init_next_task, 4, open_ebi(init_next_task), init_next_task);

		dfprintf(outputpath, "init_thread_group: %x PHY = %x\n",VIRT(init_thread_group), init_thread_group);
		dump_thread_group(VIRT(init_thread_group), pr);

		init_thread_group = (PHY(init_next_task) - offset_tasks) + offset_thread_group;
		init_next_task = PHY(init_next_task);

		if(x++ > MAX_PROCESSES) {
			if(pr) fprintf(outputpath, "Way too many processes. Aborting!\n");
			break;
		}
	}  while(VIRT(init_next_task) != orig_init_next_task);
}

void dump_logbuf()
{
	unsigned int logbuf_addr = rev_lookup("__log_buf");
	fstream *ebifile;
	unsigned int cnt = 0;
	char ch = 30;

	ebifile = open_ebi(PHY(logbuf_addr));

	if(!ebifile || !ebifile->is_open()) {
		fprintf(outputpath, "Aborting logbuf dump.\n");
		return;
	}

	read_struct(&ch, 1, ebifile, PHY(logbuf_addr));
	fprintf(outputpath, "%c", ch);
	while(cnt++<131072) {
		ebifile->read(&ch, 1);
		if(ch != 0) fprintf(outputpath, "%c", ch);
	}
}

unsigned int get_current_info_v2(unsigned long current)
{
	fstream *ebifile = open_ebi(current);
	struct thread_info ti0;

	if(ebifile==NULL) {
		fprintf(outputpath, "Couldn't get _current_ info on core.\n");
		return current;
	}
	read_struct(&ti0, sizeof(struct thread_info), ebifile, current);
	return PHY((unsigned int)ti0.task) + 0xb8;
}

void get_current_info()
{
	fstream *ebifile = open_ebi(current_c0);
	struct thread_info ti0;
	struct thread_info ti1;

	if(ebifile==NULL) {
		fprintf(outputpath, "Couldn't get _current_ info on core 0.\n");
		return;
	}
	read_struct(&ti0, sizeof(struct thread_info), ebifile, current_c0);

	ebifile = open_ebi(current_c1);

	if(!ebifile) {
		fprintf(outputpath, "Couldn't get _current_ info on core 1.\n");
		return;
	}

	read_struct(&ti1, sizeof(struct thread_info), ebifile, current_c1);

	current_c0 = PHY((unsigned int)ti0.task) + 0xb8;
	current_c1 = PHY((unsigned int)ti1.task) + 0xb8;
}

unsigned int global_page_table[4096];
unsigned int secondary_page_tables[4096][256];
unsigned int rev_page_tables[4096][256];

void store_page_tables()
{
	unsigned int regval = 0;
	unsigned int i, j;
	unsigned int l1_pte_ptr, l2_pte_ptr;
	unsigned int l1_pte, smi_entries=0;
	unsigned int l2_pt_desc, l2_pt_base, l2_pt_entry;
	unsigned int virt_address = 0x0;
	unsigned int l1_pte_counter;
	unsigned int msm_ttbr0 = 0;

	if(msm_ttbr0 == 0) {
		msm_ttbr0 = phys_offset + 0x4000;
		fprintf(outputpath, "Using default page table location!\n");
	} else msm_ttbr0 = PHY(msm_ttbr0);

	big_debug = 1;
	if(!open_ebi(msm_ttbr0))
		return;

	FILE *fp = fopen((outputdir+"pagetable.txt").c_str(), "w");

	if(!fp) {
		fprintf(outputpath, "Couldn't create pagetable.txt to write page tables!\n");
		return;
	}

	if(msm_ttbr0 != (phys_offset + 0x4000))
		read_struct(&msm_ttbr0, 4, open_ebi(msm_ttbr0), msm_ttbr0);
	big_debug = 0;
	fprintf(outputpath, "Translation table base = %x\n", msm_ttbr0 & 0xFFFFF000);

	msm_ttbr0 &= 0xFFFFF000;
	int gb_i=0, se_i=0;

	/* 4096 Level 1 entries each describing 1 mb of memory */
	for(i = msm_ttbr0; i < msm_ttbr0+(4096*4); i+=4) {
		l1_pte_ptr = i;
		dfprintf(outputpath, "l1_pte_ptr = %x\n", l1_pte_ptr);
		if(!open_ebi(l1_pte_ptr)) {
			fprintf(outputpath, "Incomplete page tables. Returning. (bad l1_pte_ptr = %x)\n", l1_pte_ptr);
			return;
		}
		if (i == msm_ttbr0) big_debug = 1;
		read_struct(&l1_pte, 4, open_ebi(l1_pte_ptr), l1_pte_ptr);

		dfprintf(outputpath, "l1_pte = %x\n", l1_pte);

		big_debug = 0;
		global_page_table[gb_i] = l1_pte;

		switch (l1_pte & 0x3) {

		case 0x0:
		case 0x3:
			for(int k=0; k<256; k++) {
				fprintf(fp, "%8.8X--%8.8X\n", virt_address, virt_address+0xfff);
				dfprintf(outputpath, "%8.8X--%8.8X\n", virt_address, virt_address+0xfff);
				virt_address+=0x1000;
			}
		break;

		case 0x2:
			if(!(l1_pte & 0x40000)) /* 1MB Section */
			{
				l1_pte_counter = l1_pte & 0xFFF00000;
				for(int k=0; k<256; k++) {
					fprintf(fp, "%8.8X--%8.8X\t", virt_address, virt_address+0xfff);
					dfprintf(outputpath, "%8.8X--%8.8X\t", virt_address, virt_address+0xfff);
					virt_address+=0x1000;
					fprintf(fp, "A:%8.8X--%8.8X\n", l1_pte_counter, l1_pte_counter + 0xfff);
					dfprintf(outputpath, "A:%8.8X--%8.8X\n", l1_pte_counter, l1_pte_counter + 0xfff);

					rev_page_tables[BVALSEL(31, 20, l1_pte_counter)][BVALSEL(19, 12, l1_pte_counter)] = virt_address - 0x1000;
					l1_pte_counter += 0x1000;
				}
			}
			else {  /* 16MB Supersection */
				fprintf(outputpath, "SUPERSECTION! Tell _this_ tool's owner NOW - SUPER IMPORTANT!\n");
				for(int k=0; k<256*16; k++) {
					virt_address+=0x1000;
				}
			}
		break;

		case 0x1:
		/* A Level 2 page table descriptor! */
		l2_pt_desc = l1_pte;
		l2_pt_base = l2_pt_desc & (~0x3ff);


		/*
		 * Now this is a horrible mess. We've encountered a bad PTE. I hate doing this, but I'm going to continue on.
		 * Anyone who tries to access the virtual address range in virt_address is going to have a bad day.
		 * If you're hitting this, please get someone to find out who's messing with the page tables,
		 * and have them FIX IT. Also, Trace32 Sim will ignore this badness and go about its merry way.
		 * 256 level 2 entries each describing
		 * a 4k page.
		 */
		if(!open_ebi(l2_pt_base)) {
				fprintf(fp, "\n");
				fprintf(outputpath, "[!!!] Bad Page Tables (l2_pt_base = %x) : %x to %x will be unavailable.\n", l2_pt_base, virt_address, virt_address + (256*0x1000));
				for (j = l2_pt_base; j < l2_pt_base+(256*4); j+=4) {
					secondary_page_tables[gb_i][se_i++] = 0x0;
					virt_address+=0x1000;
				}
				se_i=0;
				break;
			}

		/*
		 * 256 level 2 entries each describing
		 * a 4k page.
		 */
		for (j = l2_pt_base; j < l2_pt_base+(256*4); j+=4) {
			fprintf(fp, "%8.8X--%8.8X\t", virt_address, virt_address+0xfff);
			dfprintf(outputpath, "%8.8X--%8.8X\t", virt_address, virt_address+0xfff);
			virt_address+=0x1000;

			l2_pte_ptr = j;
			if(!open_ebi(l2_pte_ptr)) {
				fprintf(fp, "\n");
				fprintf(outputpath, "Incomplete page tables. Returning. (bad l2_pte_ptr = %x)\n", l2_pte_ptr);
				do_exit(-1);
			}

			read_struct(&l2_pt_entry, 4, open_ebi(l2_pte_ptr), l2_pte_ptr);
			secondary_page_tables[gb_i][se_i++] = l2_pt_entry;

			if(l2_pt_entry) {
				fprintf(fp, "A:%8.8X--%8.8X\n", (l2_pt_entry & ~0xFFF), (l2_pt_entry & ~0xFFF) + 0xfff);
				dfprintf(outputpath, "A:%8.8X--%8.8X\n", (l2_pt_entry & ~0xFFF), (l2_pt_entry & ~0xFFF) + 0xfff);
				rev_page_tables[BVALSEL(31, 20, l2_pt_entry & ~0xFFF)][BVALSEL(19, 13, l2_pt_entry & ~0xFFF)] = virt_address - 0x1000;
			} else fprintf(fp, "\n");
		}
		se_i=0;
		break;
		} //end of switch.
		gb_i++;
	}
}

unsigned int get_phys(unsigned int virt_address)
{
	unsigned int global_offset = BVALSEL(31, 20, virt_address);
	unsigned int l1_pte = *(global_page_table + global_offset);
	unsigned int bit18 = (l1_pte & 0x40000) >> 18;
	unsigned int onemb_entry;
	unsigned int l2_pte;
	unsigned int l2_offset, entry4kb, entry64kb;
	unsigned int ret = 0;

	switch(BVALSEL(1,0,l1_pte)) {

		case 0x1:
		l2_offset = BVALSEL(19,12, virt_address);
		l2_pte = secondary_page_tables[global_offset][l2_offset];

		switch(BVALSEL(1,0,l2_pte)) {
			case 0x2:
			case 0x3:
				entry4kb =
					(l2_pte & BM(31, 12)) + BVALSEL(11, 0, virt_address);
				ret = entry4kb;
			break;

			case 0x1:
				entry64kb =
						(l2_pte & BM(31, 16)) + BVALSEL(15, 0, virt_address);
				ret = entry64kb;
			break;
		}
		break;

		case 0x2:
		onemb_entry = BM(31, 20) & l1_pte;
		onemb_entry += BVALSEL(19, 0, virt_address);
		ret = onemb_entry;
		break;
	}
	return ret;
}

unsigned int get_virt_print(unsigned int phys_address)
{
	unsigned int i = BVALSEL(31,20,phys_address);
	unsigned int j = BVALSEL(19,12,phys_address);
	fprintf(outputpath, "VIRT(%x)[%x][%x]: %x\n", phys_address, BVALSEL(31,20,phys_address), BVALSEL(20,13,phys_address), rev_page_tables[i][j]);
	fprintf(outputpath, "rev_page_tables[i][j]: %x\n", rev_page_tables[i][j] + (phys_address & 0xFFF));
	return rev_page_tables[i][j] + (phys_address & 0xFFF);
}

unsigned int get_virt(unsigned int phys_address)
{
	unsigned int i = BVALSEL(31,20,phys_address);
	unsigned int j = BVALSEL(19,12,phys_address);
	return rev_page_tables[i][j] + (phys_address & 0xFFF);
}

void check_for_panic()
{
	unsigned int addr_in_panic = rev_lookup("in_panic");
	do_dump_stacks(0);
}

void dump_proc_flags(uint32 flags[], int size)
{
	fprintf(outputpath, "\n");
	for(int i=0; i<size; i++) {
		if(flags[i] & V2TZBSP_SC_STATUS_NS_BIT) {
			fprintf(outputpath, "Core %d was in the non secure world.\n", i);
		} else fprintf(outputpath, "Core %d was in the secure world.\n", i);

		if(flags[i] & V2TZBSP_SC_STATUS_SGI) {
			fprintf(outputpath, "Core %d received an SGI interrupt.\n", i);
		}

		if(flags[i] & V2TZBSP_SC_STATUS_WDT) {
			fprintf(outputpath, "Core %d received the watchdog interrupt.\n", i);
		}

		if(flags[i] & V2TZBSP_SC_STATUS_WARM_BOOT) {
			fprintf(outputpath, "Core %d has the warm boot flag set.\n", i);
		}
	}
}

void dump_wdt_status(uint32 status[], int size)
{
	fprintf(outputpath, "\n");
	for(int i=0; i<size; i++) {
		fprintf(outputpath, "Core %d WDT STATUS: %x\n", i, status[i]);
	}
}

void dump_bark_context_core_cmm(const char *fname, tzbsp_dump_cpu_ctx_t sc_ns)
{
	fstream fout_core((outputdir+fname).c_str(), ios::out);
	fout_core  << "r.s pc " << hex << "0x"  << sc_ns.mon_lr << "\n";
	fout_core  << "r.s spsr " << hex << "0x"  << sc_ns.mon_spsr << "\n";
	fout_core  << "r.s r0 " << hex << "0x"  << sc_ns.usr_r0 << "\n";
	fout_core  << "r.s r1 " << hex << "0x"  << sc_ns.usr_r1 << "\n";
	fout_core  << "r.s r2 " << hex << "0x"  << sc_ns.usr_r2 << "\n";
	fout_core  << "r.s r3 " << hex << "0x"  << sc_ns.usr_r3 << "\n";
	fout_core  << "r.s r4 " << hex << "0x"  << sc_ns.usr_r4 << "\n";
	fout_core  << "r.s r5 " << hex << "0x"  << sc_ns.usr_r5 << "\n";
	fout_core  << "r.s r6 " << hex << "0x"  << sc_ns.usr_r6 << "\n";
	fout_core  << "r.s r7 " << hex << "0x"  << sc_ns.usr_r7 << "\n";
	fout_core  << "r.s r8 " << hex << "0x"  << sc_ns.usr_r8 << "\n";
	fout_core  << "r.s r13_usr " << hex << "0x"  << sc_ns.usr_r13 << "\n";
	fout_core  << "r.s r14_usr " << hex << "0x"  << sc_ns.usr_r14 << "\n";

	fout_core  << "r.s r14_irq " << hex << "0x"  << sc_ns.irq_r14 << "\n";
	fout_core  << "r.s r13_irq " << hex << "0x"  << sc_ns.irq_r13 << "\n";

	fout_core  << "r.s r13 " << hex << "0x"  << sc_ns.svc_r13 << "\n";
	fout_core  << "r.s r14 " << hex << "0x"  << sc_ns.svc_r14 << "\n";

	fout_core  << "r.s r14_abt " << hex << "0x"  << sc_ns.abt_r14 << "\n";
	fout_core  << "r.s r13_abt " << hex << "0x"  << sc_ns.abt_r13 << "\n";

	fout_core  << "r.s r14_und " << hex << "0x"  << sc_ns.und_r14 << "\n";
	fout_core  << "r.s r13_und " << hex << "0x"  << sc_ns.und_r13 << "\n";

	fout_core  << "r.s r8_fiq " << hex << "0x"  << sc_ns.fiq_r8 << "\n";
	fout_core  << "r.s r9_fiq " << hex << "0x"  << sc_ns.fiq_r9 << "\n";
	fout_core  << "r.s r10_fiq " << hex << "0x"  << sc_ns.fiq_r10 << "\n";
	fout_core  << "r.s r11_fiq " << hex << "0x"  << sc_ns.fiq_r11 << "\n";
	fout_core  << "r.s r12_fiq " << hex << "0x"  << sc_ns.fiq_r12 << "\n";
	fout_core  << "r.s r13_fiq " << hex << "0x"  << sc_ns.fiq_r13 << "\n";
	fout_core  << "r.s r14_fiq " << hex << "0x"  << sc_ns.fiq_r14 << "\n";
	fout_core.close();
}

const char *print_mode(unsigned int psr)
{
	switch(psr & 0x1f)
	{
		case 0x10:
			return "User mode";
		case 0x11:
			return "FIQ mode";
		case 0x12:
			return "IRQ mode";
		case 0x13:
			return "Supervisor mode";
		case 0x17:
			return "Abort mode";
		case 0x1B:
			return "Undef mode";
		default:
			return "UNKNOWN";
	}
}

void do_new_tz_dump(tzbsp_dump_cpu_ctx_t sc_ns[], int size, int secure = 0)
{
	int i = 0, offset, core_sp, core_irq_sp, current;
	char *core_sym;
	char fname[100];

	if (secure)
		fprintf(outputpath, "\n:::::::::::::::: Secure Context ::::::::::::::::\n");

	for (i=0; i < size; i++) {
		sprintf(fname, "core%d_regs.cmm", i);
		dump_bark_context_core_cmm(fname, sc_ns[i]);

		core_sp = PHY(sc_ns[i].svc_r13);
		core_irq_sp = PHY(sc_ns[i].irq_r13);

		current = PHY(get_current(sc_ns[i].svc_r13));
		fprintf(outputpath, "\n");
		char *core0_sym = lookup(sc_ns[i].mon_lr, &offset);
		fprintf(outputpath, "\n");

		if(core0_sym)
			fprintf(outputpath, "CORE %d PC: %s+0x%02x <0x%08x>\n", i, core0_sym, offset, sc_ns[i].mon_lr);
		else fprintf(outputpath, "CORE %d PC: %s <0x%08x>\n", i, core0_sym, sc_ns[i].mon_lr);

		offset = 0;
		core0_sym = lookup(sc_ns[i].svc_r14, &offset);
		if(core0_sym)
			fprintf(outputpath, "CORE %d LR: %s+0x%02x <0x%08x>\n", i, core0_sym, offset, sc_ns[i].svc_r14);
		else
			fprintf(outputpath, "CORE %d LR: %s <0x%08x>\n", i, core0_sym, sc_ns[i].svc_r14);
		fprintf(outputpath, "CORE %d current task: %08x\n", i, VIRT(current));

		current = get_current_info_v2(current);

		fprintf(outputpath, "\n");

		if (!secure) {
		fprintf(outputpath, "Core %d ARM unwind stack:\n", i);
		arm_unwind_backtrace(sc_ns[i].svc_r13, 0, sc_ns[i].mon_lr);
		fprintf(outputpath, "CORE %d raw stack dump (starting at %08X): \n", i, VIRT(core_sp));
		dump_single_stack(core_sp);
		fprintf(outputpath, "\n");
		}

		offset = 0;
		if(!secure) fprintf(outputpath, "======== CORE %d (non secure context) ==========\n", i);
		core_sym = lookup(sc_ns[i].mon_lr, &offset);
		fprintf(outputpath, " Core %d's mon_lr = 0x%08X [%s+0x%04x]\n", i, sc_ns[i].mon_lr, core_sym, core_sym ? offset : 0);
		fprintf(outputpath, " Core %d's mon_spsr = 0x%08X (%s)\n", i, sc_ns[i].mon_spsr, print_mode(sc_ns[i].mon_spsr));
		fprintf(outputpath, " Core %d's usr_r0 = 0x%08X\n", i, sc_ns[i].usr_r0);
		fprintf(outputpath, " Core %d's usr_r1 = 0x%08X\n", i, sc_ns[i].usr_r1);
		fprintf(outputpath, " Core %d's usr_r2 = 0x%08X\n", i, sc_ns[i].usr_r2);
		fprintf(outputpath, " Core %d's usr_r3 = 0x%08X\n", i, sc_ns[i].usr_r3);
		fprintf(outputpath, " Core %d's usr_r4 = 0x%08X\n", i, sc_ns[i].usr_r4);
		fprintf(outputpath, " Core %d's usr_r5 = 0x%08X\n", i, sc_ns[i].usr_r5);
		fprintf(outputpath, " Core %d's usr_r6 = 0x%08X\n", i, sc_ns[i].usr_r6);
		fprintf(outputpath, " Core %d's usr_r7 = 0x%08X\n", i, sc_ns[i].usr_r7);
		fprintf(outputpath, " Core %d's usr_r8 = 0x%08X\n", i, sc_ns[i].usr_r8);
		fprintf(outputpath, " Core %d's usr_r9 = 0x%08X\n", i, sc_ns[i].usr_r9);
		fprintf(outputpath, " Core %d's usr_r10 = 0x%08X\n", i, sc_ns[i].usr_r10);
		fprintf(outputpath, " Core %d's usr_r11 = 0x%08X\n", i, sc_ns[i].usr_r11);
		fprintf(outputpath, " Core %d's usr_r12 = 0x%08X\n", i, sc_ns[i].usr_r12);
		fprintf(outputpath, " Core %d's usr_r13 = 0x%08X\n", i, sc_ns[i].usr_r13);
		fprintf(outputpath, " Core %d's usr_r14 = 0x%08X\n", i, sc_ns[i].usr_r14);
		fprintf(outputpath, " Core %d's irq_spsr = 0x%08X\n", i, sc_ns[i].irq_spsr);
		fprintf(outputpath, " Core %d's irq_r13 = 0x%08X\n", i, sc_ns[i].irq_r13);

		offset = 0;
		core_sym = lookup(sc_ns[i].irq_r14, &offset);
		fprintf(outputpath, " Core %d's irq_r14 = 0x%08X [%s+0x%04x]\n", i, sc_ns[i].irq_r14, core_sym, core_sym ? offset : 0);
		fprintf(outputpath, " Core %d's svc_spsr = 0x%08X\n", i, sc_ns[i].svc_spsr);
		fprintf(outputpath, " Core %d's svc_r13 = 0x%08X\n", i, sc_ns[i].svc_r13);

		offset = 0;
		core_sym = lookup(sc_ns[i].svc_r14, &offset);
		fprintf(outputpath, " Core %d's svc_r14 = 0x%08X [%s+0x%04x]\n", i, sc_ns[i].svc_r14, core_sym, core_sym ? offset : 0);
		fprintf(outputpath, " Core %d's abt_spsr = 0x%08X\n", i, sc_ns[i].abt_spsr);
		fprintf(outputpath, " Core %d's abt_r13 = 0x%08X\n", i, sc_ns[i].abt_r13);

		offset = 0;
		core_sym = lookup(sc_ns[i].abt_r14, &offset);
		fprintf(outputpath, " Core %d's abt_r14 = 0x%08X [%s+0x%04x]\n", i, sc_ns[i].abt_r14, core_sym, core_sym ? offset : 0);
		fprintf(outputpath, " Core %d's und_spsr = 0x%08X\n", i, sc_ns[i].und_spsr);
		fprintf(outputpath, " Core %d's und_r13 = 0x%08X\n", i, sc_ns[i].und_r13);

		offset = 0;
		core_sym = lookup(sc_ns[i].und_r14, &offset);
		fprintf(outputpath, " Core %d's und_r14 = 0x%08X [%s+0x%04x]\n", i, sc_ns[i].und_r14, core_sym, core_sym ? offset : 0);
		fprintf(outputpath, " Core %d's fiq_spsr = 0x%08X\n", i, sc_ns[i].fiq_spsr);
		fprintf(outputpath, " Core %d's fiq_r8 = 0x%08X\n", i, sc_ns[i].fiq_r8);
		fprintf(outputpath, " Core %d's fiq_r9 = 0x%08X\n", i, sc_ns[i].fiq_r9);
		fprintf(outputpath, " Core %d's fiq_r10 = 0x%08X\n", i, sc_ns[i].fiq_r10);
		fprintf(outputpath, " Core %d's fiq_r11 = 0x%08X\n", i, sc_ns[i].fiq_r11);
		fprintf(outputpath, " Core %d's fiq_r12 = 0x%08X\n", i, sc_ns[i].fiq_r12);
		fprintf(outputpath, " Core %d's fiq_r13 = 0x%08X\n", i, sc_ns[i].fiq_r13);
		fprintf(outputpath, " Core %d's fiq_r14 = 0x%08X\n", i, sc_ns[i].fiq_r14);
	}
	if (secure)
		fprintf(outputpath, ":::::::::::::: End Secure Context ::::::::::::::\n");
}

void do_fiq_bark_dump()
{
	msm_watchdog_dump mwd;
		int offset = 0;
		int dump_cpu_ctx_addr = rev_lookup("msm_dump_cpu_ctx");

		if(dump_cpu_ctx_addr)
			read_struct(&mwd, sizeof(mwd), open_ebi(PHY(dump_cpu_ctx_addr)), PHY(dump_cpu_ctx_addr));
		else {
			fprintf(outputpath, "Kernel fiq dump area not found!\n");
			return;
		}

		fprintf(outputpath, "[!] Kernel fiq dump area magic: %x, version: %d\n", mwd.magic >> 16, mwd.magic & 0xFFFF);

		if (mwd.magic) {
			fprintf(outputpath, "[!] Watchdog bark detected!\n", mwd.magic >> 16, mwd.magic & 0xFFFF);
		}

		char *pcsym = lookup(mwd.fiq_r14, &offset);

		fprintf(outputpath, "\n");
		fprintf(outputpath, "CPU context at bark time:\n");
		fprintf(outputpath, "PC: (fiq_r14) = 0x%x (%s+0x%x)\n", mwd.fiq_r14, pcsym, offset);
		fprintf(outputpath, "SP: (svc_r13) = 0x%x\n", mwd.svc_r13);
		fprintf(outputpath, "svc_spsr = 0x%x (%s)\n", mwd.svc_spsr, print_mode(mwd.svc_spsr));
		fprintf(outputpath, "usr_r0 = 0x%x\n", mwd.usr_r0);
		fprintf(outputpath, "usr_r1 = 0x%x\n", mwd.usr_r1);
		fprintf(outputpath, "usr_r2 = 0x%x\n", mwd.usr_r2);
		fprintf(outputpath, "usr_r3 = 0x%x\n", mwd.usr_r3);
		fprintf(outputpath, "usr_r4 = 0x%x\n", mwd.usr_r4);
		fprintf(outputpath, "usr_r5 = 0x%x\n", mwd.usr_r5);
		fprintf(outputpath, "usr_r6 = 0x%x\n", mwd.usr_r6);
		fprintf(outputpath, "usr_r7 = 0x%x\n", mwd.usr_r7);
		fprintf(outputpath, "usr_r8 = 0x%x\n", mwd.usr_r8);
		fprintf(outputpath, "abt_r13 = 0x%x\n", mwd.abt_r13);
		fprintf(outputpath, "abt_r14 = 0x%x\n", mwd.abt_r14);
		fprintf(outputpath, "abt_spsr = 0x%x\n", mwd.abt_spsr);
		fprintf(outputpath, "und_r13 = 0x%x\n", mwd.und_r13);
		fprintf(outputpath, "und_r14 = 0x%x\n", mwd.und_r14);
		fprintf(outputpath, "und_spsr = 0x%x\n", mwd.und_spsr);
		fprintf(outputpath, "fiq_r10 = 0x%x\n", mwd.fiq_r10);
		fprintf(outputpath, "fiq_r11 = 0x%x\n", mwd.fiq_r11);
		fprintf(outputpath, "fiq_r12 = 0x%x\n", mwd.fiq_r12);
		fprintf(outputpath, "fiq_r13 = 0x%x\n", mwd.fiq_r13);
		fprintf(outputpath, "fiq_r14 = 0x%x\n", mwd.fiq_r14);

		fprintf(outputpath, "\n");
		fprintf(outputpath, "Kernel stack at watchdog bark time: \n");
		arm_unwind_backtrace(mwd.svc_r13, 0, mwd.fiq_r14);
}

void show_pet_info()
{
	unsigned long long last_pet, last_ns = 0;
	unsigned int pet_delay_time;
	unsigned int dogstruct_addr, jiffies;

	last_ns = rev_lookup_prefix("last_ns", strlen("last_ns"));
	last_pet = rev_lookup("last_pet");
	pet_delay_time = rev_lookup("delay_time");
	dogstruct_addr = rev_lookup("dogwork_struct");
	unsigned long timer_offset = get_offset_struct("((struct delayed_work *)0x0)", "timer");
	unsigned long timer_expires, timer_expires_offset = get_offset_struct("((struct timer_list *)0x0)", "expires");
	jiffies = rev_lookup("jiffies");

	read_struct(&timer_expires, 4, open_ebi(PHY(dogstruct_addr)), PHY(dogstruct_addr) + timer_offset + timer_expires_offset);
	read_struct(&jiffies, 4, open_ebi(PHY(jiffies)), PHY(jiffies));

	if (timer_expires > jiffies)
		fprintf(outputpath, "Pet function to be scheduled in %g seconds.\n", (timer_expires - jiffies) * 0.01);
	else fprintf(outputpath, "Pet function may have been blocked, jiffies is \n"
				"%g seconds after when it was supposed to be scheduled\n"
				"on the work queue.\n", (jiffies - timer_expires ) * 0.01 );

	if(last_ns && last_pet && open_ebi(PHY(pet_delay_time))) {
		read_struct(&last_ns, 8, open_ebi(PHY(last_ns)), PHY(last_ns));
		read_struct(&last_pet, 8, open_ebi(PHY(last_pet)), PHY(last_pet));
		read_struct(&pet_delay_time, 4, open_ebi(PHY(pet_delay_time)), PHY(pet_delay_time));

		unsigned long long diff = last_ns - last_pet;
		fprintf(outputpath, "Most recent time that the watchdog was pet: %llu.%6llu\n", last_pet/1000000000,
			last_pet%1000000000);
		fprintf(outputpath, "Most recent timestamp read from the timer hardware: %llu.%6llu\n\n",
			last_ns/1000000000, last_ns%1000000000);
		if(last_ns > last_pet)
			fprintf(outputpath, "Pet delay time in this build is %u seconds.\n"
					"The watchdog was not pet for at least %llu.%6llu seconds\n\n", (pet_delay_time*10)/1000,
					diff/1000000000, diff%1000000000);

		fprintf(outputpath, "[W] The difference between the two timestamps above is NOT to be\n"
				"[W] used to determine whether a watchdog bite occured.\n\n");
	} else if(open_ebi(PHY(last_pet))) {
		read_struct(&last_pet, 8, open_ebi(PHY(last_pet)), PHY(last_pet));
		fprintf(outputpath, "Most recent time that the watchdog was pet: %llu.%6llu\n", last_pet/1000000000,
			last_pet%1000000000);
	}
}

void do_TZ_dump()
{
	unsigned int core0_sp;
	unsigned int core1_sp;
	unsigned int core0_irq_sp;
	unsigned int core0_stack[256];
	unsigned int core1_stack[256];
	unsigned int ebi_address;
	int offset;

	fstream *ebifile;
	fstream *imem_file = 0;
	int appsbark_fiq = 0;
	fprintf(outputpath, "Determining watchdog state now.\n");

	/* Check if the Linux kernel is handling (as an FIQ or IRQ) the watchdog bark interrupt */
	int appsbark_fiq_addr = rev_lookup("appsbark_fiq");

	if (open_ebi(PHY(appsbark_fiq_addr))) {

		fprintf(outputpath, "\n");

		read_struct(&appsbark_fiq, 4, open_ebi(PHY(appsbark_fiq_addr)), PHY(appsbark_fiq_addr));

		if(appsbark_fiq) {
			fprintf(outputpath, "[!] Kernel is handling the bark interrupt as an FIQ!\n");
			do_fiq_bark_dump();
			show_pet_info();
			return;
		}
	}

	if(!imem_offset)
		imem_file = open_ebi(hw_ids[chip].assumed_imem_debug_offset);
	else
		imem_file = open_ebi(imem_offset);

	if(!imem_file) {
		fprintf(outputpath, "No imem file found or invalid imem offset supplied.\n");
		return;
	}

	unsigned int imemloc = (imem_offset == 0) ? (hw_ids[chip].assumed_imem_debug_offset)  : imem_offset;

	read_struct(&ebi_address, 4, open_ebi(imemloc), imemloc);

	fprintf(outputpath, "\n");
	fprintf(outputpath, "[!] EBI Address found at offset %x: 0x%08X\n\n", imemloc, ebi_address);

	ebifile = open_ebi(ebi_address);

	if(!ebifile || !ebifile->is_open()) {
		fprintf(outputpath, "[!] Address of TZ-dumped scorpion context looks bogus. \n"
				"[!] This may have been an apps  watchdog bite but there was \n"
				"[!] no bark. Or it may have not been a watchdog reset at all.\n");
		return;
	} else wdog = 1;

	fprintf(outputpath, "[!] Address of TZ-dumped scorpion context looks valid.\n" );
	if (ebi_address & 0x00000FFF) fprintf(outputpath, "[!] EBI address not page aligned. Garbage may follow.\n");
	fprintf(outputpath, "[!] This looks like an apps watchdog bark.\n\n");
	if(in_panic)
		fprintf(outputpath, "[!] Careful, it looks like there was a panic as well.\n\n");

	read_struct(&reg_dump_v1, sizeof(reg_dump_v1), ebifile, ebi_address);
	read_struct(&reg_dump_v2_2core, sizeof(reg_dump_v2_2core), ebifile, ebi_address);
	read_struct(&reg_dump_v2_4core, sizeof(reg_dump_v2_2core), ebifile, ebi_address);

	if((reg_dump_v2_2core.magic == 0x44434151) || (!reg_dump_v2_2core.cpu_count && !reg_dump_v2_2core.magic && !reg_dump_v2_2core.version)) {
	
		if (!reg_dump_v2_2core.magic) {
			fprintf(outputpath, "[!] TZ magic number/version information may not have been flushed. Applying workaround..\n");
			if (hw_ids[chip].hw_id == 8064)
				reg_dump_v2_2core.cpu_count = 4;
			else reg_dump_v2_2core.cpu_count  = 2;
		} else {
			fprintf(outputpath, "[!] Detected TZ context magic 0x44434151. Switching to the new TZ dump context now!\n");
			fprintf(outputpath, "[!] TZ dump context version: %d\n", reg_dump_v2_2core.version);
		}

		if (reg_dump_v2_2core.cpu_count > 4 || reg_dump_v2_2core.cpu_count < 1) {
			fprintf(outputpath, "Invalid TZ dump. Not retrieving processor context.\n");
		}
		else if (reg_dump_v2_2core.cpu_count == 4) {
			dump_proc_flags(reg_dump_v2_4core.sc_status, 4);
			dump_wdt_status(reg_dump_v2_4core.wdt0_sts, 4);
			do_new_tz_dump(reg_dump_v2_4core.sc_ns, 4);
			do_new_tz_dump(&reg_dump_v2_4core.sec, 1, 1);
		}
		else {
			dump_proc_flags(reg_dump_v2_4core.sc_status, 2);
			dump_wdt_status(reg_dump_v2_4core.wdt0_sts, 2);
			do_new_tz_dump(reg_dump_v2_2core.sc_ns, 2);
			do_new_tz_dump(&reg_dump_v2_2core.sec, 1, 1);
		}

		show_pet_info();
		return;
	}

	if(reg_dump_v1.sc_status[0] & TZBSP_SC_STATUS_NS)
		fprintf(outputpath, "CORE 0 was in the non-secure world.\n");
	else fprintf(outputpath, "CORE 0 was in the secure world.\n");

	if(reg_dump_v1.sc_status[0] & TZBSP_SC_STATUS_WDT)
		fprintf(outputpath, "CORE 0 experienced a watchdog timeout.\n");

	if(reg_dump_v1.sc_status[0] & TZBSP_SC_STATUS_SGI)
		fprintf(outputpath, "CORE 0 did not experience a watchdog timeout but some other core did.\n");

	fprintf(outputpath, "\n");

	if(reg_dump_v1.sc_status[1] & TZBSP_SC_STATUS_NS)
		fprintf(outputpath, "CORE 1 was in the non-secure world.\n");
	else fprintf(outputpath, "CORE 1 was in the secure world.\n");

	if(reg_dump_v1.sc_status[1] & TZBSP_SC_STATUS_WDT)
		fprintf(outputpath, "CORE 1 experienced a watchdog timeout.\n");

	if(reg_dump_v1.sc_status[1] & TZBSP_SC_STATUS_SGI)
		fprintf(outputpath, "CORE 1 did not experience a watchdog timeout but some other core did.\n");

	char *core0_sym = lookup(reg_dump_v1.sc_ns[0].mon_lr, &offset);

	fprintf(outputpath, "\n");

	if(core0_sym)
		fprintf(outputpath, "CORE 0 PC: %s+0x%02x <0x%08x>\n", core0_sym, offset, reg_dump_v1.sc_ns[0].mon_lr);
	else fprintf(outputpath, "CORE 0 PC: %s <0x%08x>\n", core0_sym, reg_dump_v1.sc_ns[0].mon_lr);

	offset = 0;
	core0_sym = lookup(reg_dump_v1.sc_ns[0].svc_r14, &offset);
	if(core0_sym)
		fprintf(outputpath, "CORE 0 LR: %s+0x%02x <0x%08x>\n", core0_sym, offset, reg_dump_v1.sc_ns[0].svc_r14);
	else
		fprintf(outputpath, "CORE 0 LR: %s <0x%08x>\n", core0_sym, reg_dump_v1.sc_ns[0].svc_r14);

	fprintf(outputpath, "\n");
	offset = 0;
	char *core1_sym = lookup(reg_dump_v1.sc_ns[1].mon_lr, &offset);
	if(core1_sym)
		fprintf(outputpath, "CORE 1 PC: %s+0x%02x <0x%08x>\n", core1_sym, offset, reg_dump_v1.sc_ns[1].mon_lr);
	else
		fprintf(outputpath, "CORE 1 PC: %s <0x%08x>\n", core1_sym, reg_dump_v1.sc_ns[1].mon_lr);

	offset = 0;
	core1_sym = lookup(reg_dump_v1.sc_ns[1].svc_r14, &offset);
	if(core1_sym)
		fprintf(outputpath, "CORE 1 LR: %s+0x%02x <0x%08x>\n", core1_sym, offset, reg_dump_v1.sc_ns[1].svc_r14);
	else
		fprintf(outputpath, "CORE 1 LR: %s <0x%08x>\n", core1_sym, reg_dump_v1.sc_ns[1].svc_r14);

	core0_sp = PHY(reg_dump_v1.sc_ns[0].svc_r13);
	core1_sp = PHY(reg_dump_v1.sc_ns[1].svc_r13);
	core0_irq_sp = PHY(reg_dump_v1.sc_ns[1].irq_r13);

	current_c0 = PHY(get_current(reg_dump_v1.sc_ns[0].svc_r13));
	current_c1 = PHY(get_current(reg_dump_v1.sc_ns[1].svc_r13));

	fprintf(outputpath, "\n");

	fprintf(outputpath, "CORE 0 current task: %08x\n", VIRT(current_c0));
	fprintf(outputpath, "CORE 1 current task: %08x\n", VIRT(current_c1));

	get_current_info();

	fprintf(outputpath, "\n");
	fprintf(outputpath, "Core 0 ARM unwind stack:\n");
	arm_unwind_backtrace(reg_dump_v1.sc_ns[0].svc_r13, 0, reg_dump_v1.sc_ns[0].mon_lr);
	fprintf(outputpath, "CORE 0 raw stack dump (starting at %08X): \n", VIRT(core0_sp));
	dump_single_stack(core0_sp);

	fprintf(outputpath, "\n");
	fprintf(outputpath, "Core1 ARM unwind stack:\n");
	arm_unwind_backtrace(reg_dump_v1.sc_ns[1].svc_r13, 0, reg_dump_v1.sc_ns[1].svc_r14);
	fprintf(outputpath, "CORE 1 raw stack dump (starting at %08X): \n", VIRT(core1_sp));
	dump_single_stack(core1_sp);

	fprintf(outputpath, "\n");
	dump_bark_context_core_cmm("core0_regs.cmm", reg_dump_v1.sc_ns[0]);
	dump_bark_context_core_cmm("core1_regs.cmm", reg_dump_v1.sc_ns[1]);

	offset = 0;
	fprintf(outputpath, "======== CORE 0 ==========\n");
	core0_sym = lookup(reg_dump_v1.sc_ns[0].mon_lr, &offset);
	fprintf(outputpath, " sc_ns[0].mon_lr = 0x%08X [%s+0x%04x]\n", reg_dump_v1.sc_ns[0].mon_lr, core0_sym, core0_sym ? offset : 0);
	fprintf(outputpath, " sc_ns[0].mon_spsr = 0x%08X (%s)\n", reg_dump_v1.sc_ns[0].mon_spsr, print_mode(reg_dump_v1.sc_ns[0].mon_spsr));
	fprintf(outputpath, " sc_ns[0].usr_r0 = 0x%08X\n", reg_dump_v1.sc_ns[0].usr_r0);
	fprintf(outputpath, " sc_ns[0].usr_r1 = 0x%08X\n", reg_dump_v1.sc_ns[0].usr_r1);
	fprintf(outputpath, " sc_ns[0].usr_r2 = 0x%08X\n", reg_dump_v1.sc_ns[0].usr_r2);
	fprintf(outputpath, " sc_ns[0].usr_r3 = 0x%08X\n", reg_dump_v1.sc_ns[0].usr_r3);
	fprintf(outputpath, " sc_ns[0].usr_r4 = 0x%08X\n", reg_dump_v1.sc_ns[0].usr_r4);
	fprintf(outputpath, " sc_ns[0].usr_r5 = 0x%08X\n", reg_dump_v1.sc_ns[0].usr_r5);
	fprintf(outputpath, " sc_ns[0].usr_r6 = 0x%08X\n", reg_dump_v1.sc_ns[0].usr_r6);
	fprintf(outputpath, " sc_ns[0].usr_r7 = 0x%08X\n", reg_dump_v1.sc_ns[0].usr_r7);

	fprintf(outputpath, " sc_ns[0].usr_r8 = 0x%08X\n", reg_dump_v1.sc_ns[0].usr_r8);
	fprintf(outputpath, " sc_ns[0].usr_r9 = 0x%08X\n", reg_dump_v1.sc_ns[0].usr_r9);
	fprintf(outputpath, " sc_ns[0].usr_r10 = 0x%08X\n", reg_dump_v1.sc_ns[0].usr_r10);
	fprintf(outputpath, " sc_ns[0].usr_r11 = 0x%08X\n", reg_dump_v1.sc_ns[0].usr_r11);
	fprintf(outputpath, " sc_ns[0].usr_r12 = 0x%08X\n", reg_dump_v1.sc_ns[0].usr_r12);

	fprintf(outputpath, " sc_ns[0].usr_r13 = 0x%08X\n", reg_dump_v1.sc_ns[0].usr_r13);
	fprintf(outputpath, " sc_ns[0].usr_r14 = 0x%08X\n", reg_dump_v1.sc_ns[0].usr_r14);
	fprintf(outputpath, " sc_ns[0].irq_spsr = 0x%08X\n", reg_dump_v1.sc_ns[0].irq_spsr);
	fprintf(outputpath, " sc_ns[0].irq_r13 = 0x%08X\n", reg_dump_v1.sc_ns[0].irq_r13);

	offset = 0;
	core0_sym = lookup(reg_dump_v1.sc_ns[0].irq_r14, &offset);
	fprintf(outputpath, " sc_ns[0].irq_r14 = 0x%08X [%s+0x%04x]\n", reg_dump_v1.sc_ns[0].irq_r14, core0_sym, core0_sym ? offset : 0);

	fprintf(outputpath, " sc_ns[0].svc_spsr = 0x%08X\n", reg_dump_v1.sc_ns[0].svc_spsr);
	fprintf(outputpath, " sc_ns[0].svc_r13 = 0x%08X\n", reg_dump_v1.sc_ns[0].svc_r13);

	offset = 0;
	core0_sym = lookup(reg_dump_v1.sc_ns[0].svc_r14, &offset);
	fprintf(outputpath, " sc_ns[0].svc_r14 = 0x%08X [%s+0x%04x]\n", reg_dump_v1.sc_ns[0].svc_r14, core0_sym, core0_sym ? offset : 0);
	fprintf(outputpath, " sc_ns[0].abt_spsr = 0x%08X\n", reg_dump_v1.sc_ns[0].abt_spsr);
	fprintf(outputpath, " sc_ns[0].abt_r13 = 0x%08X\n", reg_dump_v1.sc_ns[0].abt_r13);

	offset = 0;
	core0_sym = lookup(reg_dump_v1.sc_ns[0].abt_r14, &offset);
	fprintf(outputpath, " sc_ns[0].abt_r14 = 0x%08X [%s+0x%04x]\n", reg_dump_v1.sc_ns[0].abt_r14, core0_sym, core0_sym ? offset : 0);
	fprintf(outputpath, " sc_ns[0].und_spsr = 0x%08X\n", reg_dump_v1.sc_ns[0].und_spsr);
	fprintf(outputpath, " sc_ns[0].und_r13 = 0x%08X\n", reg_dump_v1.sc_ns[0].und_r13);

	offset = 0;
	core0_sym = lookup(reg_dump_v1.sc_ns[0].und_r14, &offset);
	fprintf(outputpath, " sc_ns[0].und_r14 = 0x%08X [%s+0x%04x]\n", reg_dump_v1.sc_ns[0].und_r14, core0_sym, core0_sym ? offset : 0);
	fprintf(outputpath, " sc_ns[0].fiq_spsr = 0x%08X\n", reg_dump_v1.sc_ns[0].fiq_spsr);
	fprintf(outputpath, " sc_ns[0].fiq_r8 = 0x%08X\n", reg_dump_v1.sc_ns[0].fiq_r8);
	fprintf(outputpath, " sc_ns[0].fiq_r9 = 0x%08X\n", reg_dump_v1.sc_ns[0].fiq_r9);
	fprintf(outputpath, " sc_ns[0].fiq_r10 = 0x%08X\n", reg_dump_v1.sc_ns[0].fiq_r10);
	fprintf(outputpath, " sc_ns[0].fiq_r11 = 0x%08X\n", reg_dump_v1.sc_ns[0].fiq_r11);
	fprintf(outputpath, " sc_ns[0].fiq_r12 = 0x%08X\n", reg_dump_v1.sc_ns[0].fiq_r12);
	fprintf(outputpath, " sc_ns[0].fiq_r13 = 0x%08X\n", reg_dump_v1.sc_ns[0].fiq_r13);
	fprintf(outputpath, " sc_ns[0].fiq_r14 = 0x%08X\n", reg_dump_v1.sc_ns[0].fiq_r14);

	offset = 0;
	fprintf(outputpath, "\n");
	fprintf(outputpath, "======== CORE 1 ==========\n");
	core1_sym = lookup(reg_dump_v1.sc_ns[1].mon_lr, &offset);
	fprintf(outputpath, " sc_ns[1].mon_lr = 0x%08X [%s+0x%04x]\n", reg_dump_v1.sc_ns[1].mon_lr, core1_sym, core1_sym ? offset : 0);
	fprintf(outputpath, " sc_ns[1].mon_spsr = 0x%08X (%s)\n", reg_dump_v1.sc_ns[1].mon_spsr, print_mode(reg_dump_v1.sc_ns[1].mon_spsr));
	fprintf(outputpath, " sc_ns[1].usr_r0 = 0x%08X\n", reg_dump_v1.sc_ns[1].usr_r0);
	fprintf(outputpath, " sc_ns[1].usr_r1 = 0x%08X\n", reg_dump_v1.sc_ns[1].usr_r1);
	fprintf(outputpath, " sc_ns[1].usr_r2 = 0x%08X\n", reg_dump_v1.sc_ns[1].usr_r2);
	fprintf(outputpath, " sc_ns[1].usr_r3 = 0x%08X\n", reg_dump_v1.sc_ns[1].usr_r3);
	fprintf(outputpath, " sc_ns[1].usr_r4 = 0x%08X\n", reg_dump_v1.sc_ns[1].usr_r4);
	fprintf(outputpath, " sc_ns[1].usr_r5 = 0x%08X\n", reg_dump_v1.sc_ns[1].usr_r5);
	fprintf(outputpath, " sc_ns[1].usr_r6 = 0x%08X\n", reg_dump_v1.sc_ns[1].usr_r6);
	fprintf(outputpath, " sc_ns[1].usr_r7 = 0x%08X\n", reg_dump_v1.sc_ns[1].usr_r7);
	fprintf(outputpath, " sc_ns[1].usr_r8 = 0x%08X\n", reg_dump_v1.sc_ns[1].usr_r8);
	fprintf(outputpath, " sc_ns[1].usr_r9 = 0x%08X\n", reg_dump_v1.sc_ns[1].usr_r9);
	fprintf(outputpath, " sc_ns[1].usr_r10 = 0x%08X\n", reg_dump_v1.sc_ns[1].usr_r10);
	fprintf(outputpath, " sc_ns[1].usr_r11 = 0x%08X\n", reg_dump_v1.sc_ns[1].usr_r11);
	fprintf(outputpath, " sc_ns[1].usr_r12 = 0x%08X\n", reg_dump_v1.sc_ns[1].usr_r12);
	fprintf(outputpath, " sc_ns[1].usr_r13 = 0x%08X\n", reg_dump_v1.sc_ns[1].usr_r13);
	fprintf(outputpath, " sc_ns[1].usr_r14 = 0x%08X\n", reg_dump_v1.sc_ns[1].usr_r14);
	fprintf(outputpath, " sc_ns[1].irq_spsr = 0x%08X\n", reg_dump_v1.sc_ns[1].irq_spsr);
	fprintf(outputpath, " sc_ns[1].irq_r13 = 0x%08X\n", reg_dump_v1.sc_ns[1].irq_r13);

	offset = 0;
	core1_sym = lookup(reg_dump_v1.sc_ns[1].irq_r14, &offset);
	fprintf(outputpath, " sc_ns[0].irq_r14 = 0x%08X [%s+0x%04x]\n", reg_dump_v1.sc_ns[1].irq_r14, core1_sym, core1_sym ? offset : 0);
	fprintf(outputpath, " sc_ns[1].svc_spsr = 0x%08X\n", reg_dump_v1.sc_ns[1].svc_spsr);
	fprintf(outputpath, " sc_ns[1].svc_r13 = 0x%08X\n", reg_dump_v1.sc_ns[1].svc_r13);

	offset = 0;
	core1_sym = lookup(reg_dump_v1.sc_ns[1].svc_r14, &offset);
	fprintf(outputpath, " sc_ns[0].svc_r14 = 0x%08X [%s+0x%04x]\n", reg_dump_v1.sc_ns[1].svc_r14, core1_sym, core1_sym ? offset : 0);
	fprintf(outputpath, " sc_ns[1].abt_spsr = 0x%08X\n", reg_dump_v1.sc_ns[1].abt_spsr);
	fprintf(outputpath, " sc_ns[1].abt_r13 = 0x%08X\n", reg_dump_v1.sc_ns[1].abt_r13);

	offset = 0;
	core1_sym = lookup(reg_dump_v1.sc_ns[1].abt_r14, &offset);
	fprintf(outputpath, " sc_ns[0].abt_r14 = 0x%08X [%s+0x%04x]\n", reg_dump_v1.sc_ns[1].abt_r14, core1_sym, core1_sym ? offset : 0);
	fprintf(outputpath, " sc_ns[1].und_spsr = 0x%08X\n", reg_dump_v1.sc_ns[1].und_spsr);
	fprintf(outputpath, " sc_ns[1].und_r13 = 0x%08X\n", reg_dump_v1.sc_ns[1].und_r13);

	offset = 0;
	core1_sym = lookup(reg_dump_v1.sc_ns[1].und_r14, &offset);
	fprintf(outputpath, " sc_ns[0].und_r14 = 0x%08X [%s+0x%04x]\n", reg_dump_v1.sc_ns[1].und_r14, core1_sym, core1_sym ? offset : 0);
	fprintf(outputpath, " sc_ns[1].fiq_spsr = 0x%08X\n", reg_dump_v1.sc_ns[1].fiq_spsr);
	fprintf(outputpath, " sc_ns[1].fiq_r8 = 0x%08X\n", reg_dump_v1.sc_ns[1].fiq_r8);
	fprintf(outputpath, " sc_ns[1].fiq_r9 = 0x%08X\n", reg_dump_v1.sc_ns[1].fiq_r9);
	fprintf(outputpath, " sc_ns[1].fiq_r10 = 0x%08X\n", reg_dump_v1.sc_ns[1].fiq_r10);
	fprintf(outputpath, " sc_ns[1].fiq_r11 = 0x%08X\n", reg_dump_v1.sc_ns[1].fiq_r11);
	fprintf(outputpath, " sc_ns[1].fiq_r12 = 0x%08X\n", reg_dump_v1.sc_ns[1].fiq_r12);
	fprintf(outputpath, " sc_ns[1].fiq_r13 = 0x%08X\n", reg_dump_v1.sc_ns[1].fiq_r13);
	fprintf(outputpath, " sc_ns[1].fiq_r14 = 0x%08X\n", reg_dump_v1.sc_ns[1].fiq_r14);

	offset = 0;
	fprintf(outputpath, "\n");
	fprintf(outputpath, "======== Secure Context ==========\n");
	fprintf(outputpath, " sec.mon_lr = 0x%08X\n", reg_dump_v1.sec.mon_lr);
	fprintf(outputpath, " sec.mon_spsr = 0x%08X\n", reg_dump_v1.sec.mon_spsr);
	fprintf(outputpath, " sec.usr_r0 = 0x%08X\n", reg_dump_v1.sec.usr_r0);
	fprintf(outputpath, " sec.usr_r1 = 0x%08X\n", reg_dump_v1.sec.usr_r1);
	fprintf(outputpath, " sec.usr_r2 = 0x%08X\n", reg_dump_v1.sec.usr_r2);
	fprintf(outputpath, " sec.usr_r3 = 0x%08X\n", reg_dump_v1.sec.usr_r3);
	fprintf(outputpath, " sec.usr_r4 = 0x%08X\n", reg_dump_v1.sec.usr_r4);
	fprintf(outputpath, " sec.usr_r5 = 0x%08X\n", reg_dump_v1.sec.usr_r5);
	fprintf(outputpath, " sec.usr_r6 = 0x%08X\n", reg_dump_v1.sec.usr_r6);
	fprintf(outputpath, " sec.usr_r7 = 0x%08X\n", reg_dump_v1.sec.usr_r7);
	fprintf(outputpath, " sec.usr_r8 = 0x%08X\n", reg_dump_v1.sec.usr_r8);
	fprintf(outputpath, " sec.usr_r9 = 0x%08X\n", reg_dump_v1.sec.usr_r9);
	fprintf(outputpath, " sec.usr_r10 = 0x%08X\n", reg_dump_v1.sec.usr_r10);
	fprintf(outputpath, " sec.usr_r11 = 0x%08X\n", reg_dump_v1.sec.usr_r11);
	fprintf(outputpath, " sec.usr_r12 = 0x%08X\n", reg_dump_v1.sec.usr_r12);
	fprintf(outputpath, " sec.usr_r13 = 0x%08X\n", reg_dump_v1.sec.usr_r13);
	fprintf(outputpath, " sec.usr_r14 = 0x%08X\n", reg_dump_v1.sec.usr_r14);
	fprintf(outputpath, " sec.irq_spsr = 0x%08X\n", reg_dump_v1.sec.irq_spsr);
	fprintf(outputpath, " sec.irq_r13 = 0x%08X\n", reg_dump_v1.sec.irq_r13);
	fprintf(outputpath, " sec.irq_r14 = 0x%08X\n", reg_dump_v1.sec.irq_r14);
	fprintf(outputpath, " sec.svc_spsr = 0x%08X\n", reg_dump_v1.sec.svc_spsr);
	fprintf(outputpath, " sec.svc_r13 = 0x%08X\n", reg_dump_v1.sec.svc_r13);
	fprintf(outputpath, " sec.svc_r14 = 0x%08X\n", reg_dump_v1.sec.svc_r14);
	fprintf(outputpath, " sec.fiq_spsr = 0x%08X\n", reg_dump_v1.sec.fiq_spsr);
	fprintf(outputpath, " sec.fiq_r8 = 0x%08X\n", reg_dump_v1.sec.fiq_r8);
	fprintf(outputpath, " sec.fiq_r9 = 0x%08X\n", reg_dump_v1.sec.fiq_r9);
	fprintf(outputpath, " sec.fiq_r10 = 0x%08X\n", reg_dump_v1.sec.fiq_r10);
	fprintf(outputpath, " sec.fiq_r11 = 0x%08X\n", reg_dump_v1.sec.fiq_r11);
	fprintf(outputpath, " sec.fiq_r12 = 0x%08X\n", reg_dump_v1.sec.fiq_r12);
	fprintf(outputpath, " sec.fiq_r13 = 0x%08X\n", reg_dump_v1.sec.fiq_r13);
	fprintf(outputpath, " sec.fiq_r14 = 0x%08X\n", reg_dump_v1.sec.fiq_r14);

	fprintf(outputpath, "\n");

	if(!nosymbols) show_pet_info();
}

void load_symbols()
{
	int ret = system(vmlinux_cmd);
	char sysmapline[256];

	if(ret) {
		fprintf(outputpath, "**** UNABLE TO CONSTRUCT SYMBOL TABLE. NO SYMBOLS FOR YOU.\n\n");
		return;
	}

	fstream sysmap;
	fstream sysout;
	sysmap.open((outputdir+SYSMAPFILE).c_str(), ios::in);
	sysout.open((outputdir+SYSMAPOUT).c_str(), ios::out);

	int flag = 0;

	while(!sysmap.eof() && !sysmap.bad() && !sysmap.fail()) {

		sysmap.getline(sysmapline, 256);
		if(sysmapline[0] == ' ') continue;

		char *address = strtok(sysmapline, " ");
		if(address == NULL) break;
		sysmap_entry *entry = new sysmap_entry;
		entry->addr = strtoul(address, NULL, 16);
		strcpy(entry->type, strtok(NULL, " "));
		strcpy(entry->symbol, strtok(NULL, " "));
		symbol_table.push_back(*entry);
		string symstr = entry->symbol;

		if(!strcmp("init_task", entry->symbol)) {
			dfprintf(outputpath, "INIT_TASK ADDRRESS: %x\n", entry->addr);
		}

		if(!strcmp("__init_begin", entry->symbol))
			flag = 1;

		if(flag && (!strcmp(entry->type, "d")
					 || !strcmp(entry->type, "D")
					 || !strcmp(entry->type, "w")
					 || !strcmp(entry->type, "W")))
		if((symstr.length() > 0) && (symstr.find(".")==string::npos))
			sysout << "whatis " << entry->symbol << endl;
	}
	sysmap.close();
	sysout.close();

	if(symbol_table.empty())
		fprintf(outputpath, "**** UNABLE TO CONSTRUCT SYMBOL TABLE. NO SYMBOLS FOR YOU.\n\n");
	else {
		char vmlinux_cmd2[1024];
		sprintf_s(vmlinux_cmd2, 1024, "%s --batch --command=%s %s > types.txt",
							gdbpath, (outputdir+SYSMAPOUT).c_str(), vmlinuxpath);
		dfprintf(outputpath, "Executing this: %s\n", vmlinux_cmd2);
	}

	unlink((outputdir+SYSMAPFILE).c_str());
}

void load_main_unwind_table()
{
	unsigned int start = rev_lookup("__start_unwind_idx");
	unsigned int end = rev_lookup("__stop_unwind_idx");
	unsigned int i;

	fprintf(outputpath, "Init'ing unwind table. Start = [0x%X], End = [0x%X].\n", start, end);

	unwind_table = new unwind_idx[(end-start)/sizeof(unwind_table)];
	end_unwind_table = &unwind_table[(end-start)/sizeof(unwind_table)-1];

	dfprintf(outputpath, "PHY Start = %x\n", PHY(start));

	if(!start)
		fprintf(outputpath, "[W] Unwind table not found.\n");

	fstream *ebifile = open_ebi(PHY(start));

	if (!ebifile) {
		fprintf(outputpath, "Unable to load unwind table. Fopen failed (phy addr of the unwind table = %x).\n", PHY(start));
		return;
	}

	for(i = 0; i <= (((end-start))/(sizeof(struct unwind_idx)-4)); i++) {
		read_struct(&unwind_table[i], sizeof(struct unwind_idx)-4, ebifile, PHY((start + i*(sizeof(struct unwind_idx)-4))));
		dfprintf(outputpath, "uw: %x\n", (start + i*sizeof(struct unwind_idx)));
		unwind_table[i].addr_idx = start + i*(sizeof(struct unwind_idx)-4);
		if((unwind_table[i].addr & page_offset) != page_offset) {i--; break;}
	}

	end_unwind_table = unwind_table+i;
}

void print_clocks_35()
{
	unsigned int clocks_ptr = rev_lookup("soc_clk_local_tb");
}

void print_workqueue_state_38()
{
	unsigned int per_cpu_offset_addr = rev_lookup("__per_cpu_offset");
	unsigned int global_cwq_sym_addr = rev_lookup("global_cwq");
	unsigned int system_wq_addr = rev_lookup("system_long_wq");
	unsigned int idle_list_offset = get_offset_struct("((struct global_cwq *)0x0)", "idle_list");
	unsigned int worklist_offset = get_offset_struct("((struct global_cwq *)0x0)", "worklist");
	unsigned int busy_hash_offset = get_offset_struct("((struct global_cwq *)0x0)", "busy_hash");
	unsigned int scheduled_offset = get_offset_struct("((struct worker *)0x0)", "scheduled");
	unsigned int worker_task_offset = get_offset_struct("((struct worker *)0x0)", "task");
	unsigned int worker_entry_offset = get_offset_struct("((struct worker *)0x0)", "entry");
	unsigned int per_cpu_offset0, per_cpu_offset1, global_cwq_cpu0_addr, idle_list_addr[2], worklist_addr[2], next_entry;
	unsigned int worker_task_addr, scheduled_addr, work_func_addr, work_function;
	unsigned int offset_comm = get_offset_struct("((struct task_struct *)0x0)", "comm");
	unsigned int work_entry_offset = get_offset_struct("((struct work_struct *)0x0)", "entry");
	unsigned int work_hentry_offset = get_offset_struct("((struct worker *)0x0)", "hentry");
	unsigned int work_func_offset = get_offset_struct("((struct work_struct *)0x0)", "func");
	unsigned int current_work_offset = get_offset_struct("((struct worker *)0x0)", "current_work");

	unsigned int cpu_wq_offset = get_offset_struct("((struct workqueue_struct *)0x0)", "cpu_wq");
	unsigned int unbound_gcwq_addr = rev_lookup("unbound_global_cwq");
	char taskname[16];
	unsigned int busy_hash[128], worker_addr, current_work_addr, current_work_func, next_busy_worker;
	unsigned int next_work_entry;

	if (per_cpu_offset_addr == 0) {
		per_cpu_offset0 = 0;
		per_cpu_offset1 = 0;
	} else {
	read_struct(&per_cpu_offset0, 4, open_ebi(PHY(per_cpu_offset_addr)), PHY(per_cpu_offset_addr));
	read_struct(&per_cpu_offset1, 4, open_ebi(PHY(per_cpu_offset_addr)), PHY(per_cpu_offset_addr + 4));
	}
	global_cwq_cpu0_addr = global_cwq_sym_addr + per_cpu_offset0;

	read_struct(&idle_list_addr[0], 4, open_ebi(PHY(global_cwq_cpu0_addr)), PHY(global_cwq_cpu0_addr + idle_list_offset));
	read_struct(&idle_list_addr[1], 4, open_ebi(PHY(unbound_gcwq_addr)), PHY(unbound_gcwq_addr + idle_list_offset));

	read_struct(&worklist_addr[0], 4, open_ebi(PHY(global_cwq_cpu0_addr)), PHY(global_cwq_cpu0_addr + worklist_offset));
	read_struct(&worklist_addr[1], 4, open_ebi(PHY(unbound_gcwq_addr)), PHY(unbound_gcwq_addr + worklist_offset));

	read_struct(busy_hash, 64*4, open_ebi(PHY(global_cwq_cpu0_addr)), PHY(global_cwq_cpu0_addr + busy_hash_offset));
	read_struct(busy_hash + 64, 64*4, open_ebi(PHY(unbound_gcwq_addr)), PHY(unbound_gcwq_addr + busy_hash_offset));

	for(int k=0; k<128; k++) {
		next_busy_worker = busy_hash[k];
		if(busy_hash[k] != 0) {
			int cnt = 0;
			do {
				worker_addr = next_busy_worker - work_hentry_offset;
				read_struct(&worker_task_addr, 4, open_ebi(PHY(worker_addr)), PHY(worker_addr + worker_task_offset));

				if(!worker_task_addr) break;
				read_struct(&taskname, 16, open_ebi(PHY(worker_task_addr + offset_comm)), PHY(worker_task_addr + offset_comm));
				read_struct(&scheduled_addr, 4, open_ebi(PHY(worker_addr)), PHY(worker_addr + scheduled_offset));
				read_struct(&current_work_addr, 4, open_ebi(PHY(worker_addr)), PHY(worker_addr + current_work_offset));
				read_struct(&current_work_func, 4, open_ebi(PHY(current_work_addr)), PHY(current_work_addr + work_func_offset));

				fprintf(outputpath, "BUSY Workqueue worker: %s, current_work: %s\n", taskname, lookup(current_work_func));

				if(scheduled_addr == (worker_addr + scheduled_offset)) goto skip;

				next_work_entry = scheduled_addr;
				do {
					read_struct(&work_func_addr, 4, open_ebi(PHY(next_work_entry)), PHY(next_work_entry - work_hentry_offset + work_func_offset));
					read_struct(&next_work_entry, 4, open_ebi(PHY(next_work_entry)), PHY(next_work_entry));

					fprintf(outputpath, "entry: %x, workfuncaddr: %x, %s\n", next_work_entry, PHY(work_func_addr), lookup(work_func_addr));

				}while(next_work_entry != scheduled_addr);
				if(cnt++>200) break;
skip:
				read_struct(&next_busy_worker, 4, open_ebi(PHY(worker_addr)), PHY(worker_addr + work_hentry_offset));

			}while(next_busy_worker != 0);
		}
	}

	for(int i=0; i<2; i++) {
		next_entry = idle_list_addr[i];
		int cnt = 0;
		do {
			worker_addr = next_entry - worker_entry_offset;
			read_struct(&worker_task_addr, 4, open_ebi(PHY(next_entry)), PHY(next_entry - worker_entry_offset + worker_task_offset));
			if(!worker_task_addr) break;
			read_struct(&taskname, 16, open_ebi(PHY(worker_task_addr + offset_comm)), PHY(worker_task_addr + offset_comm));
			read_struct(&scheduled_addr, 4, open_ebi(PHY(worker_addr)), PHY(next_entry - worker_entry_offset + scheduled_offset));
			read_struct(&next_entry, 4, open_ebi(PHY(next_entry)), PHY(next_entry));
			read_struct(&current_work_addr, 4, open_ebi(PHY(worker_addr)), PHY(worker_addr + current_work_offset));
			if(current_work_addr)
				read_struct(&current_work_func, 4, open_ebi(PHY(current_work_addr)), PHY(current_work_addr + work_func_offset));
			else current_work_func = 0;
			if(next_entry == idle_list_addr[i]) break;

			fprintf(outputpath, "IDLE Workqueue worker: %s, current_work: %s\n", taskname, lookup(current_work_func));

			if(scheduled_addr == (worker_addr + scheduled_offset)) continue;
			if(cnt++>200) break;
			unsigned int next_work_entry = scheduled_addr;
			int cnt2 = 0;
			do {
				read_struct(&work_func_addr, 4, open_ebi(PHY(next_work_entry)), PHY(next_work_entry - work_entry_offset + work_func_offset));
				read_struct(&next_work_entry, 4, open_ebi(PHY(next_work_entry)), PHY(next_work_entry));

				fprintf(outputpath, "entry: %x, workfuncaddr: %x, %s\n", next_work_entry, PHY(work_func_addr), lookup(work_func_addr));
				if(next_work_entry == scheduled_addr) break;
				if(cnt2++>200) break;
			}while(next_work_entry != scheduled_addr);

		}while(next_entry != idle_list_addr[i]);
	}

	fprintf(outputpath, "Pending workqueue info: \n");

	for(int i=0; i<2; i++) {
		next_work_entry = worklist_addr[i];
		int cnt = 0;
		do {
				read_struct(&work_func_addr, 4, open_ebi(PHY(next_work_entry)), PHY(next_work_entry - work_entry_offset + work_func_offset));
				read_struct(&next_work_entry, 4, open_ebi(PHY(next_work_entry)), PHY(next_work_entry));

				if (PHY(work_func_addr))
					if(i==0) fprintf(outputpath, "Pending unbound entry: %s\n", lookup(work_func_addr));
					else fprintf(outputpath, "Pending bound entry: %s\n", lookup(work_func_addr));
				if(next_work_entry == worklist_addr[i]) break;
				if(cnt++>200) break;
			}while(next_work_entry != worklist_addr[i]);
	}
}

void print_workqueue_state()
{
	unsigned int keventd_wq_addr = rev_lookup("keventd_wq");
	unsigned int keventd_wq;
	unsigned int cpu_wq_offset = get_offset_struct("((struct workqueue_struct *)0x0)", "cpu_wq");
	unsigned int wq_name_offset = get_offset_struct("((struct workqueue_struct *)0x0)", "name");
	unsigned int worklist_offset = get_offset_struct("((struct cpu_workqueue_struct *)0x0)", "worklist");
	unsigned int work_func_offset = get_offset_struct("((struct work_struct *)0x0)", "func");
	unsigned int work_entry_offset = get_offset_struct("((struct work_struct *)0x0)", "entry");
	unsigned int thread_offset = get_offset_struct("((struct cpu_workqueue_struct *)0x0)", "thread");
	unsigned int cur_work_offset = get_offset_struct("((struct cpu_workqueue_struct *)0x0)", "current_work");
	unsigned int cpuwqaddr, worklistaddr, workfuncaddr, threadaddr, wq_name_addr, current_work_addr;
	char wq_name[16];
	unsigned int cpuwqsize = 64, current_work;
	unsigned int pcpu_base_addr = rev_lookup("pcpu_base_addr");
	unsigned int per_cpu_start_addr = rev_lookup("__per_cpu_start");
	unsigned int per_cpu_offset_addr = rev_lookup("__per_cpu_offset");
	unsigned int pcpu_base, per_cpu_start, per_cpu_offset[2];
	unsigned int next_entry, c=0;

	fstream *f1 = open_ebi(PHY(keventd_wq_addr));

	if(!f1) {
		fprintf(outputpath, "Sorry, keventd_wq's invalid. Workqueue state cannot be retrieved!\n");
		return;
	}

	read_struct(&keventd_wq, 4, f1, PHY(keventd_wq_addr));
	fprintf(outputpath, "keventd_wq: %x\n", keventd_wq);

	f1 = open_ebi(PHY(keventd_wq));

	if(!f1) {
		return;
	}

	read_struct(&cpuwqaddr, 4, f1, PHY(keventd_wq + cpu_wq_offset));
	read_struct(&wq_name_addr, 4, f1, PHY(keventd_wq + wq_name_offset));

	if(!open_ebi(PHY(wq_name_addr))) {
		return;
	}

	read_struct(wq_name, 16, open_ebi(PHY(wq_name_addr)), PHY(wq_name_addr));

	f1 = open_ebi(PHY(cpuwqaddr));

	if(!f1) {
		return;
	}

	read_struct(&current_work_addr, 4, f1, PHY(cpuwqaddr + cur_work_offset));

	if(current_work_addr > 0) {
		if(!open_ebi(current_work_addr)) return;
		read_struct(&current_work, 4, open_ebi(current_work_addr), PHY(current_work_addr + work_func_offset));
		fprintf(outputpath, "Current work(if any): %s\n", lookup(current_work));
	}

	read_struct(&per_cpu_offset, 8, open_ebi(PHY(per_cpu_offset_addr)), PHY(per_cpu_offset_addr));
	cpuwqaddr = cpuwqaddr + per_cpu_offset[0];

	read_struct(&worklistaddr, 4, open_ebi(PHY(cpuwqaddr + worklist_offset)), PHY(cpuwqaddr + worklist_offset));

	f1 = open_ebi(PHY(worklistaddr));
	next_entry = worklistaddr;
	do {
		read_struct(&workfuncaddr, 4, open_ebi(PHY(next_entry)), PHY(next_entry - work_entry_offset + work_func_offset));
		fprintf(outputpath, "%d. %s (at 0x%X)\n", ++c, lookup(workfuncaddr), workfuncaddr);
		if(c++ > 100) {
			fprintf(outputpath, "Too many entries!\n");
			break;
		}
		read_struct(&next_entry, 4, open_ebi(PHY(next_entry)), PHY(next_entry));
	}while(next_entry != worklistaddr);
}

void print_irq_state()
{
	unsigned int desc_size = 128, irqnum, irq_desc_size = 0, irq_count, irq_count_offset, chip, action=0, kstat_irqs_addr=0;
	unsigned int irq_desc = rev_lookup("irq_desc", &irq_desc_size);
	unsigned int h_irq_offset = get_offset_struct("irq_desc", "handle_irq");
	unsigned int irq_num_offset = get_offset_struct("irq_desc", "irq");
	irq_count_offset = get_offset_struct("irq_desc", "irq_count");
	unsigned int irq_chip_offset = get_offset_struct("irq_desc", "chip");
	unsigned int irq_action_offset = get_offset_struct("irq_desc", "action");
	unsigned int action_name_offset = get_offset_struct("((struct irqaction *)0x0)", "name");
	unsigned int kstat_irqs_offset = get_offset_struct("irq_desc", "kstat_irqs");
	unsigned int chip_name_offset = get_offset_struct("((struct irq_chip *)0x0)", "name");
	unsigned int irq_desc_entry_size = get_offset_struct("sizeof(irq_desc[0])", "", 1);
	unsigned int name_addr, chip_name_addr;
	unsigned int irq_stats[2];
	char name[48], chip_name[48];

	fstream *f1 = open_ebi(PHY(irq_desc));

	if(!f1) return;

	fprintf(outputpath, "%4s %10s %10s %30s %10s", "IRQ", "CPU0", "CPU1", "Name", "Chip\n");
	fprintf(outputpath, "=====================================================================\n");
	for(int i=16*128; i< irq_desc_size; i+=irq_desc_entry_size) {

		read_struct(&irqnum, 4, f1, PHY(irq_desc)+i+irq_num_offset);
		read_struct(&irq_count, 4, f1, PHY(irq_desc)+i+irq_count_offset);
		read_struct(&action, 4, f1, PHY(irq_desc)+i+irq_action_offset);
		read_struct(&kstat_irqs_addr, 4, f1, PHY(irq_desc)+i+kstat_irqs_offset);
		read_struct(&irq_stats, 8, f1, PHY(kstat_irqs_addr));
		read_struct(&chip, 4, f1, PHY(irq_desc)+i+irq_chip_offset);

		if(!open_ebi(PHY(chip)))
			return;

		read_struct(&chip_name_addr, 4, open_ebi(PHY(chip)), PHY(chip)+chip_name_offset);

		if(!open_ebi(PHY(chip_name_addr)))
			return;

		read_struct(&chip_name, 48, open_ebi(PHY(chip_name_addr)), PHY(chip_name_addr));

		if(action != 0) {
			read_struct(&name_addr, 4, open_ebi(PHY(action)), PHY(action)+action_name_offset);

			if (!open_ebi(PHY(name_addr)))
				return;
			read_struct(&name, 48, open_ebi(PHY(name_addr)), PHY(name_addr));
			fprintf(outputpath, "%4d %10d %10d %30s %10s\n", irqnum, irq_stats[0], irq_stats[1], name, chip_name);
		}
	}
}

void print_irq_state_38()
{
	unsigned int per_cpu_offset_addr = rev_lookup("__per_cpu_offset");
	unsigned int desc_size = 128, irqnum, irq_desc_size = 0, irq_count, irq_count_offset, chip, action=0, kstat_irqs_addr=0;
	unsigned int irq_desc = rev_lookup("irq_desc", &irq_desc_size);
	unsigned int h_irq_offset = get_offset_struct("irq_desc", "handle_irq");
	unsigned int irq_num_offset = get_offset_struct("irq_desc", "irq");
	irq_count_offset = get_offset_struct("irq_desc", "irq_count");
	unsigned int irq_chip_offset = get_offset_struct("irq_desc", "chip");
	unsigned int irq_action_offset = get_offset_struct("irq_desc", "action");
	unsigned int action_name_offset = get_offset_struct("((struct irqaction *)0x0)", "name");
	unsigned int kstat_irqs_offset = get_offset_struct("irq_desc", "kstat_irqs");
	unsigned int chip_name_offset = get_offset_struct("((struct irq_chip *)0x0)", "name");
	unsigned int irq_desc_entry_size = get_offset_struct("sizeof(irq_desc[0])", "", 1);
	unsigned int name_addr, chip_name_addr;
	unsigned int irq_stats[2];
	char name[48], chip_name[48];
	unsigned int per_cpu_offset1, per_cpu_offset0;

	read_struct(&per_cpu_offset0, 4, open_ebi(PHY(per_cpu_offset_addr)), PHY(per_cpu_offset_addr));
	read_struct(&per_cpu_offset1, 4, open_ebi(PHY(per_cpu_offset_addr)), PHY(per_cpu_offset_addr + 4));
	fstream *f1 = open_ebi(PHY(irq_desc));

	if(!f1) return;

	fprintf(outputpath, "%4s %10s %10s %30s %10s", "IRQ", "CPU0", "CPU1", "Name", "Chip\n");
	fprintf(outputpath, "=====================================================================\n");
	for(int i=16*128; i< irq_desc_size; i+=irq_desc_entry_size) {
		read_struct(&irqnum, 4, f1, PHY(irq_desc)+i+irq_num_offset);
		read_struct(&irq_count, 4, f1, PHY(irq_desc)+i+irq_count_offset);
		read_struct(&action, 4, f1, PHY(irq_desc)+i+irq_action_offset);
		read_struct(&kstat_irqs_addr, 4, f1, PHY(irq_desc)+i+kstat_irqs_offset);
		read_struct(&irq_stats, 4, f1, PHY(kstat_irqs_addr + per_cpu_offset0));
		read_struct(&irq_stats[1], 4, f1, PHY(kstat_irqs_addr + per_cpu_offset1));
		read_struct(&chip, 4, f1, PHY(irq_desc)+i+irq_chip_offset);

		if(!open_ebi(PHY(chip)))
			return;
		dfprintf(outputpath, "1\n");
		read_struct(&chip_name_addr, 4, open_ebi(PHY(chip)), PHY(chip)+chip_name_offset);

		if(!open_ebi(PHY(chip_name_addr)))
			return;

		read_struct(&chip_name, 48, open_ebi(PHY(chip_name_addr)), PHY(chip_name_addr));
		dfprintf(outputpath, "2 action=%x\n", action);

		if(action != 0) {
			read_struct(&name_addr, 4, open_ebi(PHY(action)), PHY(action)+action_name_offset);
			dfprintf(outputpath, "4, %x, %x\n", PHY(action), PHY(name_addr));
			if(!open_ebi(PHY(name_addr)))
				return;
			dfprintf(outputpath, "5\n");
			read_struct(&name, 48, open_ebi(PHY(name_addr)), PHY(name_addr));
			fprintf(outputpath, "%4d %10d %10d %30s %10s\n", irqnum, irq_stats[0], irq_stats[1], name, chip_name);
		}
	}
}

void print_irq_state_3_0()
{
	unsigned int per_cpu_offset_addr = rev_lookup("__per_cpu_offset");
        unsigned int desc_size = 160, irqnum, irq_desc_size = 0, irq_count, irq_count_offset, chip, action=0, kstat_irqs_addr=0;
        unsigned int irq_desc = rev_lookup("irq_desc", &irq_desc_size);
        unsigned int h_irq_offset = get_offset_struct("irq_desc", "handle_irq");
        unsigned int irq_num_offset = get_offset_struct("((struct irq_data *)0x0)", "irq");
        unsigned int irq_data_offset = get_offset_struct("irq_desc", "irq_data");
        irq_count_offset = get_offset_struct("irq_desc", "irq_count");
        unsigned int irq_chip_offset = get_offset_struct("((struct irq_data *)0x0)", "chip");
        unsigned int irq_action_offset = get_offset_struct("irq_desc", "action");
        unsigned int action_name_offset = get_offset_struct("((struct irqaction *)0x0)", "name");
	unsigned int kstat_irqs_offset = get_offset_struct("irq_desc", "kstat_irqs");
        unsigned int chip_name_offset = get_offset_struct("((struct irq_chip *)0x0)", "name");
	unsigned int irq_desc_entry_size = get_offset_struct("sizeof(irq_desc[0])", "", 1);
        unsigned int name_addr, chip_name_addr;
        unsigned int irq_stats[2];
        char name[48], chip_name[48];
        unsigned int per_cpu_offset1, per_cpu_offset0;

		if (per_cpu_offset_addr==0) {
			per_cpu_offset0 = 0;
			per_cpu_offset1 = 0;
		}
		else {
			read_struct(&per_cpu_offset0, 4, open_ebi(PHY(per_cpu_offset_addr)), PHY(per_cpu_offset_addr));
			read_struct(&per_cpu_offset1, 4, open_ebi(PHY(per_cpu_offset_addr)), PHY(per_cpu_offset_addr + 4));
		}

        fstream *f1 = open_ebi(PHY(irq_desc));

        if(!f1) return;

        fprintf(outputpath, "%4s %10s %10s %30s %10s", "IRQ", "CPU0", "CPU1", "Name", "Chip\n");
        fprintf(outputpath, "=====================================================================\n");
        for(int i=0; i< irq_desc_size; i+=irq_desc_entry_size) {

                read_struct(&irqnum, 4, f1, PHY(irq_desc)+ i + irq_data_offset + irq_num_offset);
				dfprintf(outputpath, "irqnum = %x\n", irqnum);
                read_struct(&irq_count, 4, f1, PHY(irq_desc)+i+irq_count_offset);
                read_struct(&action, 4, f1, PHY(irq_desc)+i+irq_action_offset);
                read_struct(&kstat_irqs_addr, 4, f1, PHY(irq_desc)+i+kstat_irqs_offset);
                read_struct(&irq_stats, 4, f1, PHY(kstat_irqs_addr + per_cpu_offset0));
                read_struct(&irq_stats[1], 4, f1, PHY(kstat_irqs_addr + per_cpu_offset1));
                read_struct(&chip, 4, f1, PHY(irq_desc)+i+irq_data_offset+irq_chip_offset);

		dfprintf(outputpath, "0, irq_desc + i + irq_chip_offset = %x, chip=%x\n", PHY(irq_desc + i + irq_data_offset + irq_chip_offset),  chip);
                if(!open_ebi(PHY(chip))) {
						fprintf(outputpath, "Aborting IRQ dump due to bad chip address %x.\n", chip);
                        return;
				}
                dfprintf(outputpath, "1\n");
                read_struct(&chip_name_addr, 4, open_ebi(PHY(chip)), PHY(chip)+chip_name_offset);

                if(!open_ebi(PHY(chip_name_addr))) {
						fprintf(outputpath, "Aborting IRQ dump due to bad chip_name_addr address %x (chip=%x, i =%d).\n", chip_name_addr, chip, i/irq_desc_entry_size);
                        continue;
				}

                read_struct(&chip_name, 48, open_ebi(PHY(chip_name_addr)), PHY(chip_name_addr));
				dfprintf(outputpath, "2 action=%x\n", action);

                if(action != 0) {
                        read_struct(&name_addr, 4, open_ebi(PHY(action)), PHY(action)+action_name_offset);
						dfprintf(outputpath, "4, %x, %x\n", PHY(action), PHY(name_addr));
                        if(!open_ebi(PHY(name_addr))) {
								fprintf(outputpath, "Aborting IRQ dump due to bad name_addr address %x.\n", name_addr);
                                return;
						}
						dfprintf(outputpath, "5\n");
                        read_struct(&name, 48, open_ebi(PHY(name_addr)), PHY(name_addr));
						fprintf(outputpath, "%4d %10d %10d %30s %10s\n", irqnum, irq_stats[0], irq_stats[1], name, chip_name);
                }
        }
}

int determine_version()
{
	unsigned int linuxbansym_addr = rev_lookup("linux_banner");
	unsigned int linux_cmdline = rev_lookup("saved_command_line");
	unsigned int linuxban_addr;
	char linuxban[256];
	char cmdline[2048];

	fstream *f1 = open_ebi(PHY(linuxbansym_addr));

	if(f1) {
		read_struct(linuxban, 256, f1, PHY(linuxbansym_addr));

		if(open_ebi(PHY(linux_cmdline))) {
			read_struct(&linux_cmdline, 4, f1, PHY(linux_cmdline));
			read_struct(cmdline, 2048, f1, PHY(linux_cmdline));
		}
		else sprintf(cmdline, "(not found)");

		if(linuxban[0] == 'L' && linuxban[1] == 'i') {
			fprintf(outputpath, "Linux banner from the ramdump:\n%s", linuxban);
			fprintf(outputpath, "Kernel commandline: %s\n", cmdline);
		} else {
			fprintf(outputpath, "[F] Error reading linux version. Are you using the right vmlinux? \n");
			fprintf(outputpath, "[F] You've got the wrong vmlinux. I may not be able to do anything that requires symbols.\n");

			return -1;
		}
	} else {
		fprintf(outputpath, "Couldn't locate the linux banner.\n");
		return -1;
	}

	if(linuxban[14] == '3') {
		fprintf(outputpath, "LINUX VERSION 3.[something]\n");
                linuxversion = 30;
                offsets_required = offsets_required_30;
		offsets_required_size = sizeof(offsets_required_30)/sizeof(offset_rec);
    } else if(linuxban[19] == '8') {
		fprintf(outputpath, "LINUX VERSION 2.6.38.[something]\n");
		linuxversion = 38;
		offsets_required = offsets_required_2_6_38;
		offsets_required_size = sizeof(offsets_required_2_6_38)/sizeof(offset_rec);
	} else {
		fprintf(outputpath, "LINUX VERSION 2.6.35.[something]\n");
		linuxversion = 35;
		offsets_required = offsets_required_2_6_35;
		offsets_required_size = sizeof(offsets_required_2_6_35)/sizeof(offset_rec);
	}

	return 0;
}

fstream fout;

void create_t32sim_launcher()
{
	char physoff[10];

	sprintf(physoff, "%x", phys_offset+0x4000);

	if (chip == -1)
		return;

	string launch_config =
		"OS=\nID=T32_1000002\nTMP=C:\\TEMP\nSYS=C:\\T32\nHELP=C:\\T32\\pdf\n\nPBI=SIM\nSCREEN=\nFONT=SMALL\nHEADER=Trace32-ScorpionSimulator\nPRINTER=WINDOWS";

	string startup_script;

	if (hw_ids[chip].hw_id!=9615)
		startup_script = ("sys.cpu SCORPION\n");
	else startup_script = ("sys.cpu CORTEXA5\n");

	startup_script += ("sys.u\n");

	for(int i=0; i < ramfiles.size(); i++) {
		size_t szconv;
		char fname[1024];
		char fsize[10];
		char wname[PATH_MAX];

		realpath(ramfiles[i].ramfile_name, wname);
		startup_script += "d.load.binary ";

		char temp[20];
		sprintf(temp, "%x", ramfiles[i].range.begin);

		startup_script += wname;
		startup_script += " 0x";
		startup_script += temp;
		startup_script += "\n";
	}

	startup_script += string("PER.S.F C15:0x2 %L 0xFFFFC000 0x4000 0x");
	startup_script += string(physoff);
	startup_script += string("\n");
	startup_script += string("mmu.on\n");
	startup_script += string("mmu.scan\n");
	startup_script += string("d.load.elf ");

	char vmlinuxpathfull[PATH_MAX];

	realpath(vmlinuxpath, vmlinuxpathfull);

	startup_script += string(vmlinuxpathfull);

	startup_script += string(" /nocode\n");
	startup_script += string("task.config c:\\t32\\demo\\arm\\kernel\\linux\\linux.t32\n");
	startup_script += string("menu.reprogram c:\\t32\\demo\\arm\\kernel\\linux\\linux.men\n");
	startup_script += string("task.dtask\n");
	startup_script += string("v.v  %ASCII %STRING linux_banner\n");
	if(in_panic) {
		startup_script += "do ";
		startup_script += outputdir.c_str();
		startup_script += "regs_panic.cmm\n";
		startup_script += "v.f\n";
	} else if(wdog) {
		startup_script += "do ";
		startup_script += outputdir.c_str();
		startup_script += "core0_regs.cmm\n";
		startup_script += "v.f\n";
	}

	string batch_file = "start c:\\t32\\t32MARM.exe -c ";
	batch_file += outputdir.c_str();
	batch_file += "t32_config.t32, ";
	batch_file += outputdir.c_str();
	batch_file += "t32_startup_script.cmm";

	fout.open((outputdir+"t32_startup_script.cmm").c_str(), ios::out);
	fout << startup_script;
	fout.close();

	fout.open((outputdir+"t32_config.t32").c_str(), ios::out);
	fout << launch_config;
	fout.close();

	fout.open((outputdir+"launch_t32.bat").c_str(), ios::out);
	fout << batch_file;
	fout.close();
	fprintf(outputpath, "-- Created a T32 Simulator launcher (run %s\\launch_t32.bat). --\n\n", outputdir.c_str());
}

void determine_hw_version(int ebi_start)
{
	unsigned int hw_bytes = 0;
	unsigned int counter = 0;
	socinfo_v1 socinfo;

	do {
		read_struct(&socinfo, sizeof(socinfo), open_ebi(ebi_start + counter), ebi_start + counter);

		if(counter == 0x4478) dfprintf(outputpath, "ok should work now (%x, ebi = %p)?\n", socinfo.format);

		if(socinfo.format > 0 && socinfo.format < 7) {

			for(int i=0; i < (sizeof(cpu_of_id)/sizeof(cpu_of_id[0])); i++)
			{
				if (socinfo.id == cpu_of_id[i].id) {
					for(int j=0; j < (sizeof(hw_ids)/sizeof(hw_ids[0])); j++)
					{
						if(cpu_of_id[i].cpu == hw_ids[j].hw_id)
						{
							chip = j;
							fprintf(outputpath, "Hardware match: %d\n", hw_ids[chip].hw_id);
							fprintf(outputpath, "Socinfo id = %d, version: %x.%x\n", hw_ids[chip].hw_id, socinfo.version >> 16, socinfo.version & 0xFFFF);
							fprintf(outputpath, "Socinfo build = %s\n", socinfo.build_id);
							if (!custom_phys_offset)
								phys_offset = hw_ids[chip].assumed_phys_offset;
							fprintf(outputpath, "Now setting phys_offset to %x\n", phys_offset);
							return;
						}
					}
					break;
				}
			}
		}

		counter+=4;
	} while (counter <= 0x20000);

	fprintf(outputpath, "Couldn't figure out what chip this is.\n");
}

void add_ram_file(string &ebifile, int begin, int print = 1)
{

	struct stat *stFileInfo = new struct stat;

	stFileInfo = new struct stat;

	int statRet = stat(ebifile.c_str(), stFileInfo);
	ramfile_s *rf = new ramfile_s();
	rf->f = new fstream(ebifile.c_str(), ios::in|ios::binary);

	if(!rf->f->is_open())
		return;

	rf->range.begin = begin;

	rf->range.end = begin + stFileInfo->st_size - 1;
	rf->stFileInfo = stFileInfo;
	strcpy(rf->ramfile_name, ebifile.c_str());

	ramfiles.push_back(*rf);

	char fpath[PATH_MAX];

	realpath(rf->ramfile_name, fpath);

	if(print) fprintf(outputpath, "RAM file %s representing memory at %x--%x processed.\n", fpath, rf->range.begin, rf->range.end);
}

int parse_arguments(int argc, char* argv[])
{
	int done = 0, i=1;

	if(argc < 5) {
		fprintf(outputpath, "Need at least one dump file and a vmlinux to proceed.\nPlease check your arguments.\n");
		do_exit(-1);
	}

	do {
			int start = i;

			if(!strcmp(argv[i], "-e") || !strcmp(argv[i], "-es")) {
			struct stat *stFileInfo = new struct stat;
			if ((i+2) >= argc) {
				fprintf(outputpath, "Expected ram file and start address after -e.\nPlease check your arguments.\n");
				do_exit(-1);
			}

			fstream *f1 = new fstream(argv[i+1], ios::in|ios::binary);
			if(!f1->is_open()) {
				fprintf(outputpath, "Unable to open dump file %s.\nPlease check your arguments.\n", argv[i+1]);
				do_exit(-1);
			}

			unsigned int begin = strtoul(argv[i+2], 0, 16);

			if(!begin || begin==-1) {
				fprintf(outputpath, "%s is an invalid range.\nPlease check your arguments.\n", argv[i+2]);
				do_exit(-1);
			}

			int statRet = stat(argv[i+1], stFileInfo);
			ramfile_s *rf = new ramfile_s();
			rf->f = f1;
			rf->range.begin = begin;

			rf->range.end = begin + stFileInfo->st_size - 1;
			rf->stFileInfo = stFileInfo;
			strcpy(rf->ramfile_name, argv[i+1]);

			ramfiles.push_back(*rf);
			fprintf(outputpath, "RAM file %s representing memory at %x--%x processed.\n", argv[i+1], rf->range.begin, rf->range.end);

			if(!strcmp(argv[i], "-es")) {
				ebi_start = begin;
				done |=4;
			}

			i+=3;
			done |= 1;
			continue;
		}

		if(!strcmp(argv[i], "-v")) {

			char vmlpath[PATH_MAX];

		realpath(argv[i+1], vmlpath);

			if ((i+1) >= argc) {
				fprintf(outputpath, "Expected vmlinux file after -v.\nPlease check your arguments.\n");
				do_exit(-1);
			}

			fstream *f1 = new fstream(argv[i+1], ios::in|ios::binary);
			if(!f1->is_open()) {
				fprintf(outputpath, "Unable to open  vmlinux at %s.\nPlease check your arguments.\n", argv[i+1]);
				do_exit(-1);
			}

			fprintf(outputpath, "vmlinux located at %s.\n", vmlpath);

			size_t szconv;

			strcpy(vmlinuxpath, argv[i+1]);

			sprintf_s(vmlinux_cmd, 512,
							"%s --numeric-sort %s > %s",
							nmpath, vmlinuxpath, (outputdir+SYSMAPFILE).c_str());

			i+=2;
			done |= 2;
			continue;
		}

		if(!strcmp(argv[i], "-phy")) {

			if ((i+1) >= argc) {
				fprintf(outputpath, "Expected physical offset after -phy.\nPlease check your arguments.\n");
				do_exit(-1);
			}

			phys_offset = strtoul(argv[i+1], 0, 16);
			custom_phys_offset = 1;

			if(phys_offset == 0 || phys_offset == -1) {
				fprintf(outputpath, "Unable to parse physical offset %s.\nPlease check your arguments.\n", argv[i+1]);
				do_exit(-1);
			}

			printf("Custom physical offset: %x\n", phys_offset);

			i+=2;
			continue;
		}

		if(!strcmp(argv[i], "-offbark")) {

			if ((i+1) >= argc) {
				fprintf(outputpath, "Expected IMEM offset after -offbark.\nPlease check your arguments.\n");
				do_exit(-1);
			}

			imem_offset = strtoul(argv[i+1], 0, 16);

			if(imem_offset == 0 || imem_offset == -1) {
				fprintf(outputpath, "Unable to parse physical offset %s.\nPlease check your arguments.\n", argv[i+1]);
				do_exit(-1);
			}

			i+=2;
			continue;
		}

		if(!strcmp(argv[i], "-page")) {

			if ((i+1) >= argc) {
				fprintf(outputpath, "Expected page offset after -page.\nPlease check your arguments.\n");
				do_exit(-1);
			}

			unsigned int page_offset = strtoul(argv[i+1], 0, 16);

			if(page_offset == 0 || page_offset == -1) {
				fprintf(outputpath, "Unable to parse page offset %s.\nPlease check your arguments.\n", argv[i+1]);
				do_exit(-1);
			}

			fprintf(outputpath, "Custom page offset: %x.\n", page_offset);

			i+=2;
			continue;
		}

		if(!strcmp(argv[i], "-outdir")) {
			i += 2;
			continue;
		}

		if(!strcmp(argv[i], "-qcdump")) {

			fprintf(outputpath, "\n** [W] You have selected an experimental feature - QC dump identification.\n");
			fprintf(outputpath, "** [W] This may not work.\n\n");

			if(argc <= i+1) {
				fprintf(outputpath, "Please specify a path to the QC ramdump.\n");
				do_exit(-1);
			}

			string firstebifile = argv[i+1];
			if(firstebifile[firstebifile.size()-1] != PATHDELIMCHAR)
				firstebifile += PATHDELIM;
			firstebifile += "EBICS0.BIN";

			fstream f_low_ebi(firstebifile.c_str(), ios::binary|ios::in);

			if(!f_low_ebi.is_open()) {
				firstebifile = argv[i+1];
				if(firstebifile[firstebifile.size()-1] != PATHDELIMCHAR)
					firstebifile += PATHDELIM;
				firstebifile += "EBI1.BIN";

				fstream f_low_ebi2(firstebifile.c_str(), ios::binary|ios::in);

				if (!f_low_ebi2.is_open()) {
					fprintf(outputpath, "Couldn't locate EBI1.bin or EBICS0.bin (tried %s). Exiting...\n", firstebifile.c_str());
					do_exit(-1);
				}
			}

			add_ram_file(firstebifile, 0x0, 0);
			determine_hw_version(0x0);

			if(chip == -1) {
				fprintf(outputpath, "Couldn't identify the chip. Please re-run this tool without the -qcdump argument.\n");
				do_exit(-1);
			}

			ramfiles.clear();

			add_ram_file(firstebifile, hw_ids[chip].assumed_phys_offset & 0xF0000000);
			ebi_start = hw_ids[chip].assumed_phys_offset & 0xF0000000;

			firstebifile = argv[i+1];
			if(firstebifile[firstebifile.size()-1] != PATHDELIMCHAR)
				firstebifile += PATHDELIM;
			firstebifile += "EBI1CS1.BIN";
			add_ram_file(firstebifile, ramfiles[0].range.end + 1);

			firstebifile = argv[i+1];
			if(firstebifile[firstebifile.size()-1] != PATHDELIMCHAR)
				firstebifile += PATHDELIM;
			firstebifile += "IMEM_C.BIN";
			add_ram_file(firstebifile, hw_ids[chip].imemc_begin);

			done |= 1;
			done |= 4;
			i+=2;
			continue;
		}

		if (i==start) {
			fprintf(outputpath, "Unrecognized argument %s.\nPlease check your arguments.\n", argv[i]);
			do_exit(-1);
		}

	} while(i!=argc);

	if(done!=7) {
			fprintf(outputpath, "Need atleast a dump file and a vmlinux and an ebi_start (-es) argument.\nPlease check your arguments.\n");
			do_exit(-1);
	}

	int error=0;
	for(unsigned int i=0; i<ramfiles.size(); i++) {
		for(unsigned int j=0; j<ramfiles.size(); j++) {
			if(i==j)
				continue;

			if (ramfiles[i].range.begin == ramfiles[j].range.begin) {
				error=1;
				break;
			}

			if (ramfiles[i].range.begin == ramfiles[j].range.begin) {
				error = 1;
				break;
			}

			if (ramfiles[i].range.begin == ramfiles[j].range.end) {
				error = 1;
				break;
			}

			if (ramfiles[i].range.end == ramfiles[j].range.begin) {
				error = 1;
				break;
			}

			if (ramfiles[i].range.begin < ramfiles[j].range.begin) {
				if (!(ramfiles[i].range.end < ramfiles[j].range.begin)) {
					error = 1;
					break;
				}
			}

			if (ramfiles[j].range.begin < ramfiles[i].range.begin) {
				if (!(ramfiles[j].range.end < ramfiles[i].range.begin)) {
					error = 1;
					break;
				}
			}
		}
	}

	if (error) {
		fprintf(outputpath, "Overlapping or invalid memory ranges specified for ram files.\nPlease check your arguments.\n");
		do_exit(-1);
	}

	return 0;
}

fstream *open_ebi(unsigned int offset) {

	for(unsigned int i=0; i<ramfiles.size(); i++)
		if(offset >= ramfiles[i].range.begin &&  offset <= ramfiles[i].range.end) {
			dfprintf(outputpath, "Returning %s\n", ramfiles[i].ramfile_name);
			return ramfiles[i].f;
		}
	return NULL;
}

unsigned int get_real_offset(unsigned int offset)
{
	for(unsigned int i=0; i<ramfiles.size(); i++)
		if(offset >= ramfiles[i].range.begin &&  offset <= ramfiles[i].range.end)
			return offset - ramfiles[i].range.begin;

	return 0;
}

int main(int argc, char* argv[])
{
	unsigned int ebi_address = 0;
	unsigned int pc_value = 0;
	size_t szconv;
	char gdb_cmd[1024];
	fstream cf;
	int count = 0, no_tz = 0;
	char outputpathfull[PATH_MAX];

	outputdir = ".";
	outputdir += PATHDELIM;
	outputpath = stdout;

	for(int i=0; i < argc; i++) {
		if(!strcmp(argv[i], "-outdir")) {
			if(argc <= i+1) {
				printf("Please specify a path to store the output in.\n");
				do_exit(-1);
			}

			outputdir  = argv[i+1];
			if(outputdir[outputdir.size()-1] != PATHDELIMCHAR)
				outputdir  += PATHDELIM;
			outputpath = fopen((outputdir+"linuxparser_output.txt").c_str(), "w+");

			if(!outputpath) {
				printf("Could not open %s.\n", outputdir.c_str());
				do_exit(-1);
			}
		}
	}

		realpath(outputdir.c_str(), outputpathfull);

	outputdir = outputpathfull;
	if(outputdir[outputdir.size()-1] != PATHDELIMCHAR)
		outputdir += PATHDELIM;

	fprintf(outputpath, "Output path: %s\n", outputpathfull);

	FILE *f = fopen((outputdir+"raw_stack_dumps.txt").c_str(), "w");

	if(!f){
		printf("Couldn't create a file in this folder: %s.\nPlease run this tool from a place where it can create files or specify a writeable folder with -outdir.\n", outputdir.c_str());
		do_exit(-1);
	}

	fclose(f);

	fprintf(outputpath, "Linux Ramdump Parser booting up. How are you today?\n");

	fprintf(outputpath, "Invocation:");
	for(int k=0 ; k < argc; k++) {
		fprintf(outputpath, " %s", argv[k]);
	}

	fprintf(outputpath, "\n");

	fprintf(outputpath, "\n");
	fprintf(outputpath, "Parsing arguments:\n");
	parse_arguments(argc, argv);

	fprintf(outputpath, "\n");
	fprintf(outputpath, "------------------------- Begin sanity information -------------------------\n");

	if(chip == -1)
		determine_hw_version(ebi_start);

	store_page_tables();

	fprintf(outputpath, "Page tables retrieved.\n");

	load_symbols();

	fprintf(outputpath, "Symbols retrieved.\n");

	load_main_unwind_table();

	fprintf(outputpath, "Unwind table retrieved.\n");

	if(determine_version() < 0){
		symbol_table.clear();
		nosymbols = 1;
		fprintf(outputpath, "[!] Couldn't use vmlinux and symbols. Will now create a T32 launcher, try to parse wdog context, and exit.\n\n");
		create_t32sim_launcher();

		fprintf(outputpath, "------------------------- Processor context information --------------------\n");
		do_TZ_dump();
		fprintf(outputpath, "------------------------- End Processor context information ----------------\n\n");
		exit(0);
	}

	fprintf(outputpath, "Filling offset map now.\n");
	fill_offset_map();
	fprintf(outputpath, "Structure offsets retrieved.\n");

	fprintf(outputpath, "Done with sanity checks.\n");

	fprintf(outputpath, "-------------------------- End sanity information --------------------------\n\n");

	check_for_panic();

	fprintf(outputpath, "------------------------- Processor context information --------------------\n");
	do_TZ_dump();
	fprintf(outputpath, "------------------------- End Processor context information ----------------\n\n");

	create_t32sim_launcher();

	fprintf(outputpath, "------------------------- Process/Thread stacks ----------------------------\n");
	do_dump_stacks(1);
	fprintf(outputpath, "------------------------- End Process/Thread stacks ------------------------\n\n");

	fprintf(outputpath, "------------------------- Kernel Log Buffer --------------------------------\n");
	dump_logbuf();
	fprintf(outputpath, "\n------------------------- End Kernel Log Buffer ----------------------------\n\n");

	fprintf(outputpath, "\n\n");
	fprintf(outputpath, "=========================== IRQ STATE ===============================\n");

	if(linuxversion == 35)
		print_irq_state();
	else if (linuxversion == 38)
		print_irq_state_38();
	else if (linuxversion == 30)
		print_irq_state_3_0();

	fprintf(outputpath, "\n");
	fprintf(outputpath, "======================= WORKQUEUE STATE ============================\n");

	if(linuxversion == 35)
		print_workqueue_state();
	else if (linuxversion == 38)
		print_workqueue_state_38();
	else if (linuxversion == 30)
		print_workqueue_state_38();

	do_exit(0);
	return 0;
}
