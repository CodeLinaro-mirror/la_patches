
7x30 FC release eMMC boot support requires the following two patches:


1) emmc_boot_bootloader_lk_17472.diff

Remove build ID check for eMMC
eMMC is based on compile time flag and runtime checking
of eMMC boot based on build ID can cause failure.



2) emmc_boot_vendor_qcom_msm7630_surf_17484.diff

Reverting perf-defconfig as it is causing eMMC bootup issue
(unable to mount system and userdata partitions).


