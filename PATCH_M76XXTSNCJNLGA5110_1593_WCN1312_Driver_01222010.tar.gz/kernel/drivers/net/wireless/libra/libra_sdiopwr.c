/* Copyright (c) 2009, Code Aurora Forum. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of Code Aurora Forum nor
 *       the names of its contributors may be used to endorse or promote
 *       products derived from this software without specific prior written
 *       permission.
 *
 * Alternatively, provided that this notice is retained in full, this software
 * may be relicensed by the recipient under the terms of the GNU General Public
 * License version 2 ("GPL") and only version 2, in which case the provisions of
 * the GPL apply INSTEAD OF those given above.  If the recipient relicenses the
 * software under the GPL, then the identification text in the MODULE_LICENSE
 * macro must be changed to reflect "GPLv2" instead of "Dual BSD/GPL".  Once a
 * recipient changes the license terms to the GPL, subsequent recipients shall
 * not relicense under alternate licensing terms, including the BSD or dual
 * BSD/GPL terms.  In addition, the following license statement immediately
 * below and between the words START and END shall also then apply when this
 * software is relicensed under the GPL:
 *
 * START
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 2 and only version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
 * END
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 */

/*===========================================================================

                           INCLUDE FILES

===========================================================================*/
#include <mach/mpp.h>
#include <linux/device.h>
#include <mach/vreg.h>
#include <linux/err.h>
#include <linux/delay.h>
#include <libra_sdiopwr.h>

#ifdef MSM_PLATFORM_7x30
#include <linux/mfd/pmic8058.h>
#endif

/*===========================================================================

                        DEFINITIONS AND TYPES

===========================================================================*/

#ifdef MSM_PLATFORM_7x30
#define PMIC_VREG_WLAN2_LEVEL   2500
#define PMIC_VREG_S2_LEVEL      1300
#define PMIC_VREG_S4_LEVEL      2200
#define PMIC_VREG_WLAN_LEVEL    2900

struct wlan_pm8058_gpio {
   int gpio_num;
   struct pm8058_gpio gpio_cfg;
};

//PMIC8058 GPIO COnfiguration for QRF8600 bringup on 7x30 FFA/SURF
static struct wlan_pm8058_gpio wlan_gpios_power_on[] = {
   {20,{PM_GPIO_DIR_IN,  PM_GPIO_OUT_BUF_CMOS, 0, PM_GPIO_PULL_DN,
         2, PM_GPIO_STRENGTH_NO,   PM_GPIO_FUNC_NORMAL, 0}},
   {21,{PM_GPIO_DIR_OUT, PM_GPIO_OUT_BUF_CMOS, 0, PM_GPIO_PULL_NO,
         0, PM_GPIO_STRENGTH_HIGH, PM_GPIO_FUNC_PAIRED, 0}},
   {22,{PM_GPIO_DIR_OUT, PM_GPIO_OUT_BUF_CMOS, 1, PM_GPIO_PULL_NO,
         2, PM_GPIO_STRENGTH_HIGH, PM_GPIO_FUNC_NORMAL, 0}},
   {30,{PM_GPIO_DIR_IN,  PM_GPIO_OUT_BUF_CMOS, 0, PM_GPIO_PULL_DN,
         2, PM_GPIO_STRENGTH_NO,   PM_GPIO_FUNC_NORMAL, 0}},
   {31,{PM_GPIO_DIR_OUT, PM_GPIO_OUT_BUF_CMOS, 1, PM_GPIO_PULL_NO,
         0, PM_GPIO_STRENGTH_HIGH, PM_GPIO_FUNC_PAIRED, 0}},
   {26,{PM_GPIO_DIR_IN,  PM_GPIO_OUT_BUF_CMOS, 1, PM_GPIO_PULL_UP_30,
         2, PM_GPIO_STRENGTH_NO,   PM_GPIO_FUNC_NORMAL, 0}},
};

//PMIC8058 GPIO COnfiguration for QRF8600 shutdown on 7x30 FFA/SURF
static struct wlan_pm8058_gpio wlan_gpios_power_off[] = {
   {22,{PM_GPIO_DIR_OUT, PM_GPIO_OUT_BUF_CMOS, 0, PM_GPIO_PULL_NO,
         2, PM_GPIO_STRENGTH_LOW, PM_GPIO_FUNC_NORMAL, 0}},
};

/* Helper routine to power up QRF8600 on 7x30 FFA/SURF */
static int libra_power_qrf8600(int on)
{
   int rc;
   struct vreg *vreg_wlan2 = NULL;
   struct vreg *vreg_s2 = NULL;
   struct vreg *vreg_s4 = NULL;
   struct vreg *vreg_wlan = NULL;

   //2.5v Analog from LDO19
   vreg_wlan2 = vreg_get(NULL, "wlan2");
   if (IS_ERR(vreg_wlan2)) {
      printk(KERN_ERR "%s: wlan2 vreg get failed (%ld)\n",
         __func__, PTR_ERR(vreg_wlan2));
      return PTR_ERR(vreg_wlan2);
   }

   //1.3v RF; gated by externel FET (GPIO 21 & GPIO 22)
   vreg_s2 = vreg_get(NULL, "s2");
   if (IS_ERR(vreg_s2)) {
      printk(KERN_ERR "%s: s2 vreg get failed (%ld)\n",
         __func__, PTR_ERR(vreg_wlan));
      return PTR_ERR(vreg_s2);
   }

   //2.2v RF - Gated by externel FET (GPIO 31 & GPIO 32)
   vreg_s4 = vreg_get(NULL, "s4");
   if (IS_ERR(vreg_s4)) {
      printk(KERN_ERR "%s: s4 vreg get failed (%ld)\n",
         __func__, PTR_ERR(vreg_s4));
      return PTR_ERR(vreg_s4);
   }

   //2.9v PA from LDO13
   vreg_wlan = vreg_get(NULL, "wlan");
   if (IS_ERR(vreg_wlan)) {
      printk(KERN_ERR "%s: wlan vreg get failed (%ld)\n",
         __func__, PTR_ERR(vreg_wlan));
      return PTR_ERR(vreg_wlan);
   }

   if (on) {
      // Configure GPIO 21 & GPIO 22
      rc = pm8058_gpio_config(wlan_gpios_power_on[0].gpio_num, 
         &wlan_gpios_power_on[0].gpio_cfg);
      if (rc) {
         printk(KERN_ERR "%s: pmic GPIO %d config failed (%d)\n",
            __func__, wlan_gpios_power_on[0].gpio_num, rc);
         return -EIO;
      }

      rc = pm8058_gpio_config(wlan_gpios_power_on[1].gpio_num, 
         &wlan_gpios_power_on[1].gpio_cfg);
      if (rc) {
         printk(KERN_ERR "%s: pmic GPIO %d config failed (%d)\n",
         __func__, wlan_gpios_power_on[1].gpio_num, rc);
         return -EIO;
      }

      // Cofigure GPIO 27 to be high. Without this GPIO 31, 32 are disabled.
      rc = pm8058_gpio_config(wlan_gpios_power_on[5].gpio_num, 
         &wlan_gpios_power_on[5].gpio_cfg);
      if (rc) {
         printk(KERN_ERR "%s: pmic GPIO %d config failed (%d)\n",
            __func__, wlan_gpios_power_on[5].gpio_num, rc);
         return -EIO;
      }

      // Configure GPIO 31 & GPIO 32
      rc = pm8058_gpio_config(wlan_gpios_power_on[3].gpio_num, 
         &wlan_gpios_power_on[3].gpio_cfg);
      if (rc) {
         printk(KERN_ERR "%s: pmic GPIO %d config failed (%d)\n",
            __func__, wlan_gpios_power_on[3].gpio_num, rc);
         return -EIO;
      }

      rc = pm8058_gpio_config(wlan_gpios_power_on[4].gpio_num, 
         &wlan_gpios_power_on[4].gpio_cfg);
      if (rc) {
         printk(KERN_ERR "%s: pmic GPIO %d config failed (%d)\n",
            __func__, wlan_gpios_power_on[4].gpio_num, rc);
         return -EIO;
      }

      // Configure GPIO 23 for Deep Sleep
      rc = pm8058_gpio_config(wlan_gpios_power_on[2].gpio_num, 
         &wlan_gpios_power_on[2].gpio_cfg);
      if (rc) {
         printk(KERN_ERR "%s: pmic GPIO %d config failed (%d)\n",
            __func__, wlan_gpios_power_on[2].gpio_num, rc);
         return -EIO;
      }

      // Power up 2.5v Analog
      rc = vreg_set_level(vreg_wlan2, PMIC_VREG_WLAN2_LEVEL);
      if (rc) {
         printk(KERN_ERR "%s: wlan2 vreg set level failed (%d)\n",
            __func__, rc);
         return -EIO;
      }

      rc = vreg_enable(vreg_wlan2);
      if (rc) {
         printk(KERN_ERR "%s: wlan2 vreg enable failed (%d)\n",__func__, rc);
         return -EIO;
      }

      printk(KERN_INFO "%s: Wait for 2.5v supply to settle\n",__func__);
      msleep(500);

      // Power up 1.3v RF
      rc = vreg_set_level(vreg_s2, PMIC_VREG_S2_LEVEL);
      if (rc) {
         printk(KERN_ERR "%s: s2 vreg set level failed (%d)\n",__func__, rc);
         return -EIO;
      }

      rc = vreg_enable(vreg_s2);
      if (rc) {
         printk(KERN_ERR "%s: s2 vreg enable failed (%d)\n",__func__, rc);
         return -EIO;
      }

      // Power up 2.2v RF
      rc = vreg_set_level(vreg_s4, PMIC_VREG_S4_LEVEL);
      if (rc) {
         printk(KERN_ERR "%s: s4 vreg set level failed (%d)\n", __func__, rc);
         return -EIO;
      }

      rc = vreg_enable(vreg_s4);
      if (rc) {
         printk(KERN_ERR "%s: s4 vreg enable failed (%d)\n",__func__, rc);
         return -EIO;
      }

      // Power up 2.9v PA
      rc = vreg_set_level(vreg_wlan, PMIC_VREG_WLAN_LEVEL);
      if (rc) {
         printk(KERN_ERR "%s: wlan vreg set level failed (%d)\n",__func__, rc);
         return -EIO;
      }

      rc = vreg_enable(vreg_wlan);
      if (rc) {
         printk(KERN_ERR "%s: wlan vreg enable failed (%d)\n",__func__, rc);
         return -EIO;
      }

      msleep(500);

      printk(KERN_INFO "%s: Enabled power supply for WLAN\n", __func__);
   }
   else {
      rc = vreg_disable(vreg_wlan);
      if (rc) {
         printk(KERN_ERR "%s: wlan vreg disable failed (%d)\n", __func__, rc);
         return -EIO;
      }

      rc = vreg_disable(vreg_s4); 
      if (rc) {
         printk(KERN_ERR "%s: s4 vreg disable failed (%d)\n",__func__, rc);
         return -EIO;
      }

      rc = vreg_disable(vreg_s2);
      if (rc) {
         printk(KERN_ERR "%s: s2 vreg disable failed (%d)\n",__func__, rc);
         return -EIO;
      }

      rc = vreg_disable(vreg_wlan2);
      if (rc) {
         printk(KERN_ERR "%s: wlan2 vreg disable failed (%d)\n",__func__, rc);
         return -EIO;
      }
      printk(KERN_INFO "%s: Disabled power supply for WLAN\n", __func__);
   }
   return 0;
}
#endif

#ifdef MSM_PLATFORM_7x27_FFA

#define MPP_4_CHIP_PWD_L 3 //MPP4 is hooked to Deep Sleep Signal 

/* Helper routine to power up Libra keypad on the 7x27 FFA */
static int libra_power_7x27_keypad( int on )
{
   struct vreg *vreg_wlan, *vreg_bt = NULL;
   int rc = 0;

   vreg_wlan = vreg_get(NULL, "wlan");
   if (IS_ERR(vreg_wlan)) {
      printk(KERN_ERR "%s: wlan vreg get failed (%ld)\n",
         __func__, PTR_ERR(vreg_wlan));
      return PTR_ERR(vreg_wlan);
   }

   vreg_bt = vreg_get(NULL, "gp6");
   if (IS_ERR(vreg_bt)) {
      printk(KERN_ERR "%s: gp6 vreg get failed (%ld)\n",
         __func__, PTR_ERR(vreg_bt));
      return PTR_ERR(vreg_bt);
   }

   if(on) {
      //Pull deep sleep signal low first to ensure a clean power on
      //sequence. Ideally this should already be pulled low.
      mpp_config_digital_out(MPP_4_CHIP_PWD_L, 
         MPP_CFG(MPP_DLOGIC_LVL_MSMP, MPP_DLOGIC_OUT_CTRL_LOW));

      //Disable VDD_WLAN in case this is turned on already. Ideally
      //this should already be turned off.
      rc = vreg_disable(vreg_wlan);
      if (rc) {
         printk(KERN_ERR "%s: vreg disable failed (%d)\n",__func__, rc);
         return -EIO;
      }      

      /* units of mV, steps of 50 mV */
      rc = vreg_set_level(vreg_bt, 2600);
      if (rc) {
         printk(KERN_ERR "%s: vreg set level failed (%d)\n",__func__, rc);
         return -EIO;
      }
      rc = vreg_enable(vreg_bt);
      if (rc) {
         printk(KERN_ERR "%s: vreg enable failed (%d)\n",__func__, rc);
         return -EIO;
      }

      //Pull deep sleep signal high to begin with.
      mpp_config_digital_out(MPP_4_CHIP_PWD_L, 
         MPP_CFG(MPP_DLOGIC_LVL_MSMP, MPP_DLOGIC_OUT_CTRL_HIGH));

      //Set VDD_WLAN_2V6 to 1.8v first.
      rc = vreg_set_level(vreg_wlan, 1800);
      if (rc) {
         printk(KERN_ERR "%s: vreg set level failed (%d)\n", __func__, rc);
         return -EIO;
      }

      rc = vreg_enable(vreg_wlan);
      if (rc) {
         printk(KERN_ERR "%s: wlan vreg enable failed (%d)\n",__func__, rc);
         return -EIO;
      }

      //Wait for voltage to settle
      msleep(500);

      //Set VDD_WLAN_2V6 to 2.6v
      rc = vreg_set_level(vreg_wlan, 2600);
      if (rc) {
         printk(KERN_ERR "%s: vreg set level failed (%d)\n", __func__, rc);
         return -EIO;
      }

      printk(KERN_INFO "%s: Enabled power supply for WLAN\n", __func__);

      //Wait for for voltages to settle and WLAN card to be detected. This
      //wait time can be optimized. On rare instances, I have seen significant
      //delay in card detection. That could be because of latency in polling
      //frequency.
      msleep(500);
   }
   else {
      rc = vreg_disable(vreg_wlan);
      if (rc) {
         printk(KERN_ERR "%s: vreg disable failed (%d)\n",__func__, rc);
         return -EIO;
      }

      rc = vreg_disable(vreg_bt);
      if (rc) {
         printk(KERN_ERR "%s: vreg disable failed (%d)\n",__func__, rc);
         return -EIO;
      }
      printk(KERN_INFO "%s: Disabled power supply for WLAN\n", __func__);
   }
   return 0;
}
#endif

/* API to turn on/off voltage supplies to Libra WLAN */
int libra_sdiopwr(int on)
{
#ifdef MSM_PLATFORM_7x30
   if(libra_power_qrf8600(on))
      return -1;
#endif   

#ifdef MSM_PLATFORM_7x27_FFA
   if(libra_power_7x27_keypad(on))
      return -1;
#endif
   return 0;
}
