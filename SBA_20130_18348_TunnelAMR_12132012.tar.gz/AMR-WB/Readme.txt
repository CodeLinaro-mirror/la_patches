1. Apply 177302.patch, 177304.patch, 178079.path, Kernel_patch.patch  in order.
2. Copy audio_amrwbplus.c file into kernel/arch/arm/mach-msm/qdsp6v2/ folder
3. Copy msm_audio_amrwbplus.h file into include/linux/ folder.