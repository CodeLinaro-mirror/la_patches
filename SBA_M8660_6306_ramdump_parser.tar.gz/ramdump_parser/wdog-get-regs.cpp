/* Copyright (c) 2011, Code Aurora Forum. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 and
 * only version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

// wdog-get-regs.cpp : Defines the entry point for the console application.
//

#include <iostream>
#include <fstream>
#include <vector>

#define lw_strtoul strtoul
#include <cstring>
#include <cstdlib>
#include <sys/stat.h>
#include "unwind.h"

#include "linuxstructs.h"
#include "unwind.h"

using namespace std;
#define MAX_STACK_WALKBACK 128
#define MAX_PROCESSES 400

#define IMEM_DEBUG_LOC 0x05f658
void (*arm_unwind_backtrace)(unsigned int, unsigned int, unsigned int)
	= unwind_backtrace_generic;
typedef unsigned int uint32;

char nmpath[] = "nm";
char gdbpath[] = "gdb";
char gdbcmds[] = "./cmds.txt";

uint32 current_c0;
uint32 current_c1;

char *ebi1cs1 = NULL, *ebics0 = NULL;
char *imem_c = NULL;

fstream imem_file, ebics0_file, ebics1_file;
static int offset_tasks, offset_comm, offset_stack,
	offset_thread_group, offset_pid, offset_state, offset_exit_state;;
char vmlinux_cmd[1024];
char vmlinuxpath[1024];

unsigned int page_offset = PAGE_OFFSET;
unsigned int phys_offset = PHYS_OFFSET;

int more_than_512mb_ram = 0;
struct unwind_idx *unwind_table;
struct unwind_idx *end_unwind_table;

struct sysmap_entry {
	unsigned int addr;
	char type[2];
	char symbol[256];
};

typedef struct tzbsp_dump_cpu_ctx_s
{
	uint32 mon_lr;
	uint32 mon_spsr;
	uint32 usr_r0;
	uint32 usr_r1;
	uint32 usr_r2;
	uint32 usr_r3;
	uint32 usr_r4;
	uint32 usr_r5;
	uint32 usr_r6;
	uint32 usr_r7;
	uint32 usr_r8;
	uint32 usr_r9;
	uint32 usr_r10;
	uint32 usr_r11;
	uint32 usr_r12;
	uint32 usr_r13;
	uint32 usr_r14;
	uint32 irq_spsr;
	uint32 irq_r13;
	uint32 irq_r14;
	uint32 svc_spsr;
	uint32 svc_r13;
	uint32 svc_r14;
	uint32 abt_spsr;
	uint32 abt_r13;
	uint32 abt_r14;
	uint32 und_spsr;
	uint32 und_r13;
	uint32 und_r14;
	uint32 fiq_spsr;
	uint32 fiq_r8;
	uint32 fiq_r9;
	uint32 fiq_r10;
	uint32 fiq_r11;
	uint32 fiq_r12;
	uint32 fiq_r13;
	uint32 fiq_r14;
} tzbsp_dump_cpu_ctx_t;

typedef struct tzbsp_dump_buf_s
{
	uint32 sc_status[2];
	tzbsp_dump_cpu_ctx_t sc_ns[2];
	tzbsp_dump_cpu_ctx_t sec;
} tzbsp_dump_buf_t;

tzbsp_dump_buf_t reg_dump;

unsigned int get_current(unsigned int sp)
{
	return (sp & ~(THREAD_SIZE - 1));
}

unsigned int get_real_offset(unsigned int offset)
{

	if(more_than_512mb_ram) {
		if(offset >> 28 == 5)
			return 0x1FFFFFFF & offset;
	}

	offset = 0x0FFFFFFF & offset;

	return offset;
}

void *read_struct(void *buf, int size, fstream *file, int offset)
{

	offset = get_real_offset(offset);

	file->seekg(offset, ios::beg);

	if(file->eof() || file->fail() || file->bad())
		return NULL;

	file->read((char *)buf, size);

	if(file->fail() || file->bad())
		return NULL;

	return buf;
}

fstream *open_ebi(unsigned int address)
{
	switch(address >> 28) {

		case 4:
			return &ebics0_file;

		break;

		case 5:
			if(more_than_512mb_ram)
				return &ebics0_file;

			else return &ebics1_file;

		case 6:
			return &ebics1_file;
			break;

		default:
			printf("Couldn't match address %x to EBI.\n", address);
			return NULL;
			break;
	}

	return NULL;
}

vector<sysmap_entry> symbol_table;

char * lookup(unsigned int addr, int *offset = NULL)
{
	if(symbol_table.empty())
		return NULL;

	if(addr == 0) return NULL;

	if(addr > symbol_table[symbol_table.size()-1].addr) return NULL;
	if(addr < symbol_table[0].addr) return NULL;

	int low = 0;
	int high = symbol_table.size()-1;

	int mid = (low+high)/2;
	int premid = 0;

	while(!(addr >= symbol_table[mid].addr
		&& addr < symbol_table[mid+1].addr)) {

		if(addr < symbol_table[mid].addr)
			high = mid - 1;

		if(addr > symbol_table[mid].addr)
			low = mid + 1;

		mid = (high+low)/2;

		if(mid==premid)
			return NULL;
		premid = mid;
	}

	if(offset) *offset = addr - symbol_table[mid].addr;

	if(symbol_table[mid].type[0] == 'T' || symbol_table[mid].type[0] == 't')
		return symbol_table[mid].symbol;
	else
		return NULL;
}

char * linlookup(unsigned int addr, int *offset = NULL)
{
	if(symbol_table.empty())
		return NULL;

	if(addr == 0)
		return NULL;

	if(addr > symbol_table[symbol_table.size()-1].addr)
		return NULL;
	if(addr < symbol_table[0].addr)
		return NULL;

	for(unsigned int k = 0; k < symbol_table.size()-1; k++) {
		if(addr >= symbol_table[k].addr
			&& addr < symbol_table[k+1].addr) {

		if(offset)
			*offset = addr - symbol_table[k].addr;

		if(symbol_table[k].type[0]=='T' ||
				symbol_table[k].type[0]=='t')
			return symbol_table[k].symbol;
		}
	}
	return NULL;
}

unsigned int rev_lookup(const char *symname)
{
	if(symbol_table.empty())
		return 0;

	if(symname == NULL)
		return 0;

	for(unsigned int k = 0; k < symbol_table.size()-1; k++) {
		if(!strncmp(symbol_table[k].symbol, symname, 256))
			return symbol_table[k].addr;
	}
	return 0;
}

#define MAX_STACK_READ 256

void dump_single_stack(unsigned int spaddr, FILE *fp = NULL)
{
	int i, offset;
	fstream *ebifile = open_ebi(spaddr);

	if(!ebifile) return;

	unsigned int stack[MAX_STACK_READ] = {0};

	read_struct(&stack, MAX_STACK_READ, ebifile, spaddr);

	for(i = 0; i < MAX_STACK_WALKBACK; i++) {
		offset = 0;
		if(lookup(stack[i], &offset)) {
			if(offset) {
				if(fp)
				fprintf(fp, "[%08X] %08X -- %s+0x%x\n", VIRT(spaddr) + (4*i), stack[i], lookup(stack[i], &offset), offset);
				else printf("[%08X] %08X -- %s+0x%x\n", VIRT(spaddr) + (4*i), stack[i], lookup(stack[i], &offset), offset);
			}

		} //else printf("[%08X] %08X\n", VIRT(spaddr) + (4*i), stack[i]);

	}
}

void get_offsets()
{
	char gdbline[256], *off;
	unsigned int init_task, init_task_tasks, init_task_comm, init_task_stack, init_task_thread_group, init_task_pid,
		init_task_exit_state, init_task_state;

	fstream gdbf("offsets.1234", ios::in);

	gdbf.getline(gdbline, 256);
	off = strtok(gdbline, " ");
	off = strtok(NULL, " ");
	off = strtok(NULL, " ");

	init_task = strtoul(off, NULL, 16);

	gdbf.getline(gdbline, 256);
	off = strtok(gdbline, " ");
	off = strtok(NULL, " ");
	off = strtok(NULL, " ");

	init_task_tasks = strtoul(off, NULL, 16);

	gdbf.getline(gdbline, 256);
	off = strtok(gdbline, " ");
	off = strtok(NULL, " ");
	off = strtok(NULL, " ");

	init_task_comm = strtoul(off, NULL, 16);

	gdbf.getline(gdbline, 256);
	off = strtok(gdbline, " ");
	off = strtok(NULL, " ");
	off = strtok(NULL, " ");

	init_task_stack = strtoul(off, NULL, 16);

	gdbf.getline(gdbline, 256);
	off = strtok(gdbline, " ");
	off = strtok(NULL, " ");
	off = strtok(NULL, " ");

	init_task_thread_group = strtoul(off, NULL, 16);

	gdbf.getline(gdbline, 256);
	off = strtok(gdbline, " ");
	off = strtok(NULL, " ");
	off = strtok(NULL, " ");

	init_task_pid = strtoul(off, NULL, 16);

	gdbf.getline(gdbline, 256);
	off = strtok(gdbline, " ");
	off = strtok(NULL, " ");
	off = strtok(NULL, " ");

	init_task_state = strtoul(off, NULL, 16);

	gdbf.getline(gdbline, 256);
	off = strtok(gdbline, " ");
	off = strtok(NULL, " ");
	off = strtok(NULL, " ");

	init_task_exit_state = strtoul(off, NULL, 16);

	offset_tasks = init_task_tasks - init_task;
	offset_comm = init_task_comm - init_task;
	offset_stack = init_task_stack - init_task;
	offset_thread_group = init_task_thread_group - init_task;
	offset_pid = init_task_pid - init_task;
	offset_state = init_task_state - init_task;
	offset_exit_state = init_task_exit_state - init_task;

	printf("\nOffset of tasks: %x, offset_comm: %x, offset_stack: %x, offset_thread_group: %x", offset_tasks, offset_comm, offset_stack,
		offset_thread_group);

	unlink("offsets.1234");
}

void dump_thread_group(unsigned int init_thread_group)
{
	char thread_task_name[16];
	unsigned int orig_thread_group, next_thread_start, next_thread_comm, next_thread_pid, next_thread_stack;
	unsigned int thread_task_pid, addr_stack;
	unsigned int next_thread_state, next_thread_exit_state;
	unsigned int task_state, task_exit_state;
	struct thread_info threadinfo;
	static int tgindex = 1;
	int i = 0;

	orig_thread_group = init_thread_group;

	do {

		FILE *f = fopen("raw_stack_dumps.txt", "a");
		next_thread_start = init_thread_group - offset_thread_group;
		next_thread_comm = PHY(next_thread_start + offset_comm);
		next_thread_pid = PHY(next_thread_start + offset_pid);
		next_thread_stack = PHY(next_thread_start + offset_stack);
		next_thread_state = PHY(next_thread_start + offset_state);
		next_thread_exit_state = PHY(next_thread_start + offset_exit_state);

		read_struct(thread_task_name, 16, open_ebi(next_thread_comm), next_thread_comm);
		read_struct((char *)&thread_task_pid, 4, open_ebi(next_thread_pid), next_thread_pid);
		read_struct((char *)&task_state, 4, open_ebi(next_thread_state), next_thread_state);
		read_struct((char *)&task_exit_state, 4, open_ebi(next_thread_exit_state), next_thread_exit_state);
		read_struct((char *)&addr_stack, 4, open_ebi(next_thread_stack), next_thread_stack);
		read_struct(&threadinfo, sizeof(struct thread_info), open_ebi(PHY(addr_stack)), PHY(addr_stack));

		if(i++==0) printf("\n%d. Process: %s, cpu: %d, pid: %d\n=============================\n", tgindex++,
		thread_task_name, threadinfo.cpu, thread_task_pid);

		printf("	Task name: %s, pid: %d, cpu: %d, \n	state: 0x%x, exit_state: 0x%x, stack_base: 0x%x\n", thread_task_name, thread_task_pid,
		threadinfo.cpu, task_state, task_exit_state, addr_stack);
		printf("	Stack: \n");
		arm_unwind_backtrace((threadinfo.cpu_context.sp), (threadinfo.cpu_context.fp), (threadinfo.cpu_context.pc));
		printf("-----------------------------\n");


		fprintf(f, "--------------------------\n");
		fprintf(f, "	Task name: %s, pid: %d, cpu: %d, \n	state: 0x%x, exit_state: 0x%x, stack_base: 0x%x\n", thread_task_name, thread_task_pid,
		threadinfo.cpu, task_state, task_exit_state, addr_stack);
		fprintf(f, "	Stack (sp = %x): \n", threadinfo.cpu_context.sp);
		dump_single_stack(PHY(threadinfo.cpu_context.sp), f);

		unsigned int stack_value;
		int p=0;

		fprintf(f, "\nSP: 0x%08x", threadinfo.cpu_context.sp);

		for(int k = threadinfo.cpu_context.sp; k < threadinfo.cpu_context.sp+256; k+=4) {
		//if(p>=256) break;
		if(p % 8 == 0)
			fprintf(f, "\n[%08x]: ", k);
		p++;
		read_struct(&stack_value, 4, open_ebi(PHY(k)), PHY(k));
		fprintf(f, " %08x", stack_value);
		if(p>=256) break;
		}

		fprintf(f, "\n--------------------------\n");
		fclose(f);

		read_struct((char *)&init_thread_group, 4, open_ebi(PHY(next_thread_start)), PHY(next_thread_start + offset_thread_group));

	}while(init_thread_group != orig_thread_group);

	//fclose(f);
}

void do_dump_stacks()
{
	unsigned int init_addr = rev_lookup("init_task");
	char init_task_name[16];
	char gdb_cmd[1024];
	unsigned int init_comm, init_pid, init_next_task, orig_init_next_task, cur_task, init_thread_group;
	int offset = 0;
	fstream *ebifile;
	unsigned int addr_stack, init_stack;
	unsigned int threadstack[256];
	struct thread_info threadinfo;
	char *lookupsym;
	int ret;

	struct stat stFileInfo;
	snprintf(gdb_cmd, 1024, "%s -x %s --batch %s > offsets.1234",
			 gdbpath, gdbcmds, vmlinuxpath);

	printf("\nPRINTING STACKS.. THIS MAY TAKE SOME TIME.");

	if(ret = system(gdb_cmd)) {
		printf("Error executing gdb. No stacks for you! (%d) \n", ret);
		return;
	}

	int statRet = stat("offsets.1234", &stFileInfo);
	if (statRet != 0 || stFileInfo.st_size == 0) {
		printf("Error executing gdb. No stacks for you!\n");
		return;
	}
	get_offsets();
	cout << endl << endl;
	printf(" INIT TASK is at %x\n", init_addr);

	init_comm = PHY(init_addr) + offset_comm;
	init_stack = PHY(init_addr) + offset_stack;
	init_next_task = PHY(init_addr) + offset_tasks;
	init_pid = PHY(init_addr) + offset_pid;
	init_thread_group = PHY(init_addr) + offset_thread_group;
	orig_init_next_task = VIRT(init_next_task);

	ebifile = open_ebi(init_comm);

	if(!ebifile || !ebifile->is_open()) {
		return;
	}

	int x = 0;
	do {
		read_struct((char *)&init_next_task, 4, open_ebi(init_next_task), init_next_task);

		dump_thread_group(VIRT(init_thread_group));

		init_thread_group = (PHY(init_next_task) - offset_tasks) + offset_thread_group;
		init_next_task = PHY(init_next_task);

		//printf("init_next_task = %x\n", VIRT(init_next_task));
		//printf("orig_next_task = %x\n", orig_init_next_task);
		//if(x++==1) orig_init_next_task = VIRT(init_next_task);
		if(x++ > MAX_PROCESSES) {
			printf("Way too many processes.. aborting!\n");
			break;
		}
	}  while(VIRT(init_next_task) != orig_init_next_task);
}

void dump_logbuf()
{
	unsigned int logbuf_addr = rev_lookup("__log_buf");
	fstream *ebifile;
	unsigned int cnt = 0;
	char ch = 30;

	printf("\n\nLOGBUF (ADDRESS: %x):\n", logbuf_addr);

	ebifile = open_ebi(PHY(logbuf_addr));

	if(!ebifile || !ebifile->is_open())
		return;

	read_struct(&ch, 1, ebifile, PHY(logbuf_addr));
	cout << ch;
	while(cnt++<131072 && ch != 0) {
		ebifile->read(&ch, 1);
		cout << ch;
	}
}

void get_current_info()
{
	fstream *ebifile = open_ebi(current_c0);
	struct thread_info ti0;
	struct thread_info ti1;

	if(ebifile==NULL) {
		printf("Couldn't get _current_ info on core 0.\n");
		return;
	}
	read_struct(&ti0, sizeof(struct thread_info), ebifile, current_c0);

	ebifile = open_ebi(current_c1);

	if(!ebifile) {
		printf("Couldn't get _current_ info on core 1.\n");
		return;
	}

	read_struct(&ti1, sizeof(struct thread_info), ebifile, current_c1);

	current_c0 = PHY((unsigned int)ti0.task) + 0xb8;
	current_c1 = PHY((unsigned int)ti1.task) + 0xb8;
}

void do_TZ_dump()
{
	unsigned int core0_sp;
	unsigned int core1_sp;
	unsigned int core0_irq_sp;
	unsigned int core0_stack[256];
	unsigned int core1_stack[256];
	unsigned int ebi_address;
	int offset;
	fstream *ebifile;
	imem_file.seekg(IMEM_DEBUG_LOC, ios_base::beg);

	if(!imem_file.eof()) {
		imem_file.read((char *)&ebi_address, 4);
	} else return;

	printf("\n\nEBI Address found at 0x2a05f658: 0x%08X\n", ebi_address);

	ebifile = open_ebi(ebi_address);

	if(!ebifile || !ebifile->is_open())
		return;

	read_struct(&reg_dump, sizeof(reg_dump), ebifile, ebi_address);

	if(reg_dump.sc_status[0] & TZBSP_SC_STATUS_NS)
		printf("CORE 0 was in non-secure world.\n");

	if(reg_dump.sc_status[0] & TZBSP_SC_STATUS_WDT)
		printf("CORE 0 got the WDT\n");

	if(reg_dump.sc_status[0] & TZBSP_SC_STATUS_SGI)
		printf("CORE 0 did not get the WDT but some other core did.\n");

	if(reg_dump.sc_status[1] & TZBSP_SC_STATUS_NS)
		printf("CORE 1 was in non-secure world.\n");

	if(reg_dump.sc_status[1] & TZBSP_SC_STATUS_WDT)
		printf("CORE 1 got the WDT\n");

	if(reg_dump.sc_status[1] & TZBSP_SC_STATUS_SGI)
		printf("CORE 1 did not get the WDT but some other core did.\n");

	char *core0_sym = lookup(reg_dump.sc_ns[0].mon_lr, &offset);

	if(core0_sym)
		printf("\nCORE 0 PC: %s <0x%08x+0x%02x>\n", core0_sym, reg_dump.sc_ns[0].mon_lr, offset);
	else printf("\nCORE 0 PC: %s <0x%08x>\n", core0_sym, reg_dump.sc_ns[0].mon_lr);

	offset = 0;
	core0_sym = lookup(reg_dump.sc_ns[0].svc_r14, &offset);
	if(core0_sym)
		printf("CORE 0 LR: %s <0x%08x+0x%02x>\n", core0_sym, reg_dump.sc_ns[0].svc_r14, offset);
	else
		printf("CORE 0 LR: %s <0x%08x>\n", core0_sym, reg_dump.sc_ns[0].svc_r14);

	offset = 0;
	char *core1_sym = lookup(reg_dump.sc_ns[1].mon_lr, &offset);
	if(core1_sym)
		printf("\nCORE 1 PC: %s <0x%08x+0x%02x>\n", core1_sym, reg_dump.sc_ns[1].mon_lr, offset);
	else
		printf("\nCORE 1 PC: %s <0x%08x>\n", core1_sym, reg_dump.sc_ns[1].mon_lr);

	offset = 0;
	core1_sym = lookup(reg_dump.sc_ns[1].svc_r14, &offset);
	if(core1_sym)
		printf("CORE 1 LR: %s <0x%08x+0x%02x>\n", core1_sym, reg_dump.sc_ns[1].svc_r14, offset);
	else
		printf("CORE 1 LR: %s <0x%08x>\n", core1_sym, reg_dump.sc_ns[1].svc_r14);

	if(reg_dump.sc_ns[0].mon_lr == 0 && reg_dump.sc_ns[1].mon_lr == 0)
		printf("\n*** SORRY, THIS LOOKS LIKE A BAD DUMP. CONTINUING ANYWAY... ***\n");

	core0_sp = PHY(reg_dump.sc_ns[0].svc_r13);
	core1_sp = PHY(reg_dump.sc_ns[1].svc_r13);
	core0_irq_sp = PHY(reg_dump.sc_ns[1].irq_r13);

	current_c0 = PHY(get_current(reg_dump.sc_ns[0].svc_r13));
	current_c1 = PHY(get_current(reg_dump.sc_ns[1].svc_r13));

	printf("CORE 0 current task: %08X\n", VIRT(current_c0));
	printf("CORE 1 current task: %08X\n", VIRT(current_c1));

	get_current_info();

	printf("\nCORE 0 raw stack dump (starting at %08X): \n", VIRT(core0_sp));
	dump_single_stack(core0_sp);
	printf("Arm unwind stack:\n");
	arm_unwind_backtrace(reg_dump.sc_ns[0].svc_r13, 0, reg_dump.sc_ns[0].mon_lr);

	printf("\nCORE 0 raw IRQ stack dump (starting at %08X): \n", reg_dump.sc_ns[0].irq_r13);
	dump_single_stack(PHY(reg_dump.sc_ns[0].irq_r13));
	printf("Arm unwind stack:\n");
	arm_unwind_backtrace(reg_dump.sc_ns[0].svc_r13, 0, reg_dump.sc_ns[0].irq_r14);

	printf("\nCORE 1 raw stack dump (starting at %08X): \n", VIRT(core1_sp));
	dump_single_stack(core1_sp);
	printf("Arm unwind stack:\n");
	arm_unwind_backtrace(reg_dump.sc_ns[1].svc_r13, 0, reg_dump.sc_ns[1].mon_lr);

	printf("\nCORE 1 raw IRQ stack dump (starting at %08X): \n", reg_dump.sc_ns[1].irq_r13);
	dump_single_stack(PHY(reg_dump.sc_ns[1].irq_r13));
	printf("Arm unwind stack:\n");
	arm_unwind_backtrace(reg_dump.sc_ns[1].svc_r13, 0, reg_dump.sc_ns[1].irq_r14);

	offset = 0;
	printf("\n***** REGISTER DUMP FOLLOWS ***** \n");
	printf("======== CORE 0 ==========\n");
	core0_sym = lookup(reg_dump.sc_ns[0].mon_lr, &offset);
	printf(" sc_ns[0].mon_lr = 0x%08X [%s+0x%04x]\n", reg_dump.sc_ns[0].mon_lr, core0_sym, core0_sym ? offset : 0);
	printf(" sc_ns[0].mon_spsr = 0x%08X\n", reg_dump.sc_ns[0].mon_spsr);
	printf(" sc_ns[0].usr_r0 = 0x%08X\n", reg_dump.sc_ns[0].usr_r0);
	printf(" sc_ns[0].usr_r1 = 0x%08X\n", reg_dump.sc_ns[0].usr_r1);
	printf(" sc_ns[0].usr_r2 = 0x%08X\n", reg_dump.sc_ns[0].usr_r2);
	printf(" sc_ns[0].usr_r3 = 0x%08X\n", reg_dump.sc_ns[0].usr_r3);
	printf(" sc_ns[0].usr_r4 = 0x%08X\n", reg_dump.sc_ns[0].usr_r4);
	printf(" sc_ns[0].usr_r5 = 0x%08X\n", reg_dump.sc_ns[0].usr_r5);
	printf(" sc_ns[0].usr_r6 = 0x%08X\n", reg_dump.sc_ns[0].usr_r6);
	printf(" sc_ns[0].usr_r7 = 0x%08X\n", reg_dump.sc_ns[0].usr_r7);
	printf(" sc_ns[0].usr_r8 = 0x%08X\n", reg_dump.sc_ns[0].usr_r8);
	printf(" sc_ns[0].usr_r9 = 0x%08X\n", reg_dump.sc_ns[0].usr_r9);
	printf(" sc_ns[0].usr_r10 = 0x%08X\n", reg_dump.sc_ns[0].usr_r10);
	printf(" sc_ns[0].usr_r11 = 0x%08X\n", reg_dump.sc_ns[0].usr_r11);
	printf(" sc_ns[0].usr_r12 = 0x%08X\n", reg_dump.sc_ns[0].usr_r12);
	printf(" sc_ns[0].usr_r13 = 0x%08X\n", reg_dump.sc_ns[0].usr_r13);
	printf(" sc_ns[0].usr_r14 = 0x%08X\n", reg_dump.sc_ns[0].usr_r14);
	printf(" sc_ns[0].irq_spsr = 0x%08X\n", reg_dump.sc_ns[0].irq_spsr);
	printf(" sc_ns[0].irq_r13 = 0x%08X\n", reg_dump.sc_ns[0].irq_r13);

	offset = 0;
	core0_sym = lookup(reg_dump.sc_ns[0].irq_r14, &offset);
	printf(" sc_ns[0].irq_r14 = 0x%08X [%s+0x%04x]\n", reg_dump.sc_ns[0].irq_r14, core0_sym, core0_sym ? offset : 0);
	printf(" sc_ns[0].svc_spsr = 0x%08X\n", reg_dump.sc_ns[0].svc_spsr);
	printf(" sc_ns[0].svc_r13 = 0x%08X\n", reg_dump.sc_ns[0].svc_r13);

	offset = 0;
	core0_sym = lookup(reg_dump.sc_ns[0].svc_r14, &offset);
	printf(" sc_ns[0].svc_r14 = 0x%08X [%s+0x%04x]\n", reg_dump.sc_ns[0].svc_r14, core0_sym, core0_sym ? offset : 0);
	printf(" sc_ns[0].abt_spsr = 0x%08X\n", reg_dump.sc_ns[0].abt_spsr);
	printf(" sc_ns[0].abt_r13 = 0x%08X\n", reg_dump.sc_ns[0].abt_r13);

	offset = 0;
	core0_sym = lookup(reg_dump.sc_ns[0].abt_r14, &offset);
	printf(" sc_ns[0].abt_r14 = 0x%08X [%s+0x%04x]\n", reg_dump.sc_ns[0].abt_r14, core0_sym, core0_sym ? offset : 0);
	printf(" sc_ns[0].und_spsr = 0x%08X\n", reg_dump.sc_ns[0].und_spsr);
	printf(" sc_ns[0].und_r13 = 0x%08X\n", reg_dump.sc_ns[0].und_r13);

	offset = 0;
	core0_sym = lookup(reg_dump.sc_ns[0].und_r14, &offset);
	printf(" sc_ns[0].und_r14 = 0x%08X [%s+0x%04x]\n", reg_dump.sc_ns[0].und_r14, core0_sym, core0_sym ? offset : 0);
	printf(" sc_ns[0].fiq_spsr = 0x%08X\n", reg_dump.sc_ns[0].fiq_spsr);
	printf(" sc_ns[0].fiq_r8 = 0x%08X\n", reg_dump.sc_ns[0].fiq_r8);
	printf(" sc_ns[0].fiq_r9 = 0x%08X\n", reg_dump.sc_ns[0].fiq_r9);
	printf(" sc_ns[0].fiq_r10 = 0x%08X\n", reg_dump.sc_ns[0].fiq_r10);
	printf(" sc_ns[0].fiq_r11 = 0x%08X\n", reg_dump.sc_ns[0].fiq_r11);
	printf(" sc_ns[0].fiq_r12 = 0x%08X\n", reg_dump.sc_ns[0].fiq_r12);
	printf(" sc_ns[0].fiq_r13 = 0x%08X\n", reg_dump.sc_ns[0].fiq_r13);
	printf(" sc_ns[0].fiq_r14 = 0x%08X\n", reg_dump.sc_ns[0].fiq_r14);

	offset = 0;
	printf("\n======== CORE 1 ==========\n");
	core1_sym = lookup(reg_dump.sc_ns[1].mon_lr, &offset);
	printf(" sc_ns[1].mon_lr = 0x%08X [%s+0x%04x]\n", reg_dump.sc_ns[1].mon_lr, core1_sym, core1_sym ? offset : 0);

	printf(" sc_ns[1].mon_spsr = 0x%08X\n", reg_dump.sc_ns[1].mon_spsr);
	printf(" sc_ns[1].usr_r0 = 0x%08X\n", reg_dump.sc_ns[1].usr_r0);
	printf(" sc_ns[1].usr_r1 = 0x%08X\n", reg_dump.sc_ns[1].usr_r1);
	printf(" sc_ns[1].usr_r2 = 0x%08X\n", reg_dump.sc_ns[1].usr_r2);
	printf(" sc_ns[1].usr_r3 = 0x%08X\n", reg_dump.sc_ns[1].usr_r3);
	printf(" sc_ns[1].usr_r4 = 0x%08X\n", reg_dump.sc_ns[1].usr_r4);
	printf(" sc_ns[1].usr_r5 = 0x%08X\n", reg_dump.sc_ns[1].usr_r5);
	printf(" sc_ns[1].usr_r6 = 0x%08X\n", reg_dump.sc_ns[1].usr_r6);
	printf(" sc_ns[1].usr_r7 = 0x%08X\n", reg_dump.sc_ns[1].usr_r7);
	printf(" sc_ns[1].usr_r8 = 0x%08X\n", reg_dump.sc_ns[1].usr_r8);
	printf(" sc_ns[1].usr_r9 = 0x%08X\n", reg_dump.sc_ns[1].usr_r9);
	printf(" sc_ns[1].usr_r10 = 0x%08X\n", reg_dump.sc_ns[1].usr_r10);
	printf(" sc_ns[1].usr_r11 = 0x%08X\n", reg_dump.sc_ns[1].usr_r11);
	printf(" sc_ns[1].usr_r12 = 0x%08X\n", reg_dump.sc_ns[1].usr_r12);
	printf(" sc_ns[1].usr_r13 = 0x%08X\n", reg_dump.sc_ns[1].usr_r13);
	printf(" sc_ns[1].usr_r14 = 0x%08X\n", reg_dump.sc_ns[1].usr_r14);
	printf(" sc_ns[1].irq_spsr = 0x%08X\n", reg_dump.sc_ns[1].irq_spsr);
	printf(" sc_ns[1].irq_r13 = 0x%08X\n", reg_dump.sc_ns[1].irq_r13);

	offset = 0;
	core1_sym = lookup(reg_dump.sc_ns[1].irq_r14, &offset);
	printf(" sc_ns[0].irq_r14 = 0x%08X [%s+0x%04x]\n", reg_dump.sc_ns[1].irq_r14, core1_sym, core1_sym ? offset : 0);
	printf(" sc_ns[1].svc_spsr = 0x%08X\n", reg_dump.sc_ns[1].svc_spsr);
	printf(" sc_ns[1].svc_r13 = 0x%08X\n", reg_dump.sc_ns[1].svc_r13);

	offset = 0;
	core1_sym = lookup(reg_dump.sc_ns[1].svc_r14, &offset);
	printf(" sc_ns[0].svc_r14 = 0x%08X [%s+0x%04x]\n", reg_dump.sc_ns[1].svc_r14, core1_sym, core1_sym ? offset : 0);
	printf(" sc_ns[1].abt_spsr = 0x%08X\n", reg_dump.sc_ns[1].abt_spsr);
	printf(" sc_ns[1].abt_r13 = 0x%08X\n", reg_dump.sc_ns[1].abt_r13);

	offset = 0;
	core1_sym = lookup(reg_dump.sc_ns[1].abt_r14, &offset);
	printf(" sc_ns[0].abt_r14 = 0x%08X [%s+0x%04x]\n", reg_dump.sc_ns[1].abt_r14, core1_sym, core1_sym ? offset : 0);
	printf(" sc_ns[1].und_spsr = 0x%08X\n", reg_dump.sc_ns[1].und_spsr);
	printf(" sc_ns[1].und_r13 = 0x%08X\n", reg_dump.sc_ns[1].und_r13);

	offset = 0;
	core1_sym = lookup(reg_dump.sc_ns[1].und_r14, &offset);
	printf(" sc_ns[0].und_r14 = 0x%08X [%s+0x%04x]\n", reg_dump.sc_ns[1].und_r14, core1_sym, core1_sym ? offset : 0);
	printf(" sc_ns[1].fiq_spsr = 0x%08X\n", reg_dump.sc_ns[1].fiq_spsr);
	printf(" sc_ns[1].fiq_r8 = 0x%08X\n", reg_dump.sc_ns[1].fiq_r8);
	printf(" sc_ns[1].fiq_r9 = 0x%08X\n", reg_dump.sc_ns[1].fiq_r9);
	printf(" sc_ns[1].fiq_r10 = 0x%08X\n", reg_dump.sc_ns[1].fiq_r10);
	printf(" sc_ns[1].fiq_r11 = 0x%08X\n", reg_dump.sc_ns[1].fiq_r11);
	printf(" sc_ns[1].fiq_r12 = 0x%08X\n", reg_dump.sc_ns[1].fiq_r12);
	printf(" sc_ns[1].fiq_r13 = 0x%08X\n", reg_dump.sc_ns[1].fiq_r13);
	printf(" sc_ns[1].fiq_r14 = 0x%08X\n", reg_dump.sc_ns[1].fiq_r14);
}

void load_symbols()
{
	int ret = system(vmlinux_cmd);
	char sysmapline[256];

	if(ret) {
		printf("\n\n**** UNABLE TO CONSTRUCT SYMBOL TABLE. NO SYMBOLS FOR YOU.\n\n");
		return;
	}

	fstream sysmap;
	sysmap.open("System.map.x1234", ios::in);

	while(!sysmap.eof() && !sysmap.bad() && !sysmap.fail()) {

		sysmap.getline(sysmapline, 256);
		if(sysmapline[0] == ' ') continue;

		char *address = strtok(sysmapline, " ");
		if(address == NULL) break;
		sysmap_entry *entry = new sysmap_entry;
		entry->addr = strtoul(address, NULL, 16);
		strcpy(entry->type, strtok(NULL, " "));
		strcpy(entry->symbol, strtok(NULL, " "));
		symbol_table.push_back(*entry);
	}
	sysmap.close();

	if(symbol_table.empty()) {
		printf("\n\n**** UNABLE TO CONSTRUCT SYMBOL TABLE. NO SYMBOLS FOR YOU.\n\n");
	}

	unlink("System.map.x1234");
}

void load_main_unwind_table()
{
	unsigned int start = rev_lookup("__start_unwind_idx");
	unsigned int end = rev_lookup("__stop_unwind_idx");
	unsigned int i;

	printf("\nInit'ing unwind table... start = %x, end = %x\n", start, end);

	unwind_table = new unwind_idx[(end-start)/sizeof(unwind_table)];

	end_unwind_table = &unwind_table[(end-start)/sizeof(unwind_table)-1];

	fstream *ebifile = open_ebi(PHY(start));

	for(i = 0; i < ((end-start)/sizeof(unwind_table)); i++) {
		read_struct(&unwind_table[i], sizeof(struct unwind_idx), ebifile, PHY((start + i*sizeof(struct unwind_idx))));
		if((unwind_table[i].addr & page_offset) != page_offset) {i--; break;}
		//printf("Address: %x, Insn: %x\n", unwind_table[i].addr, unwind_table[i].insn);
	}

	end_unwind_table = unwind_table + (i-1);
}

int main(int argc, char* argv[])
{
	unsigned int ebi_address = 0;
	unsigned int pc_value = 0;
	size_t szconv;
	char gdb_cmd[1024];
	fstream cf;
	int count = 0, no_tz;
	struct stat stFileInfo;

	FILE *f = fopen("raw_stack_dumps.txt", "w");
		fclose(f);

	if(argc < 4) {
		cout << "Usage: wdog-get-regs <vmlinux path> <IMEM_C.BIN path> <EBICS0 DUMP path> <EBICS1 DUMP path>\n";
		cout << "	   wdog-get-regs NOTZ <vmlinux path> <EBICS0 DUMP path> <EBICS1 DUMP path>\n";
		return -1;
	}

	no_tz = !strncmp(argv[1], "NOTZ", 4);

	if(no_tz && (argc < 5)) {
		cout << "Usage: wdog-get-regs <vmlinux path> <IMEM_C.BIN path> <EBICS0 DUMP path> <EBICS1 DUMP path>\n";
		return -1;
	}

	if(no_tz)
		strncpy(vmlinuxpath, argv[2], 512);
	else
		strncpy(vmlinuxpath, argv[1], 512);

	snprintf(vmlinux_cmd, 512,
			 "%s --numeric-sort %s > System.map.x1234",
			 nmpath, vmlinuxpath);
	imem_c = argv[2];
	ebics0 = argv[3];
	ebi1cs1 = argv[4];

	if(argc > 5)
		if(argv[5]) {
			printf("\nFound a fifth argument, will assume it is (in hex) PHYS_OFFSET.\n");
			phys_offset = lw_strtoul(argv[5], 0, 16);
		}

	if(argc > 6)
		if(argv[6]) {
			printf("\nFound a sixth argument %s, will assume it is (in hex) PAGE_OFFSET.\n", argv[6]);
			page_offset = lw_strtoul(argv[6], 0, 16);
		}


	printf("Physical Offset: 0x%x\n", phys_offset);
	printf("Page Offset: 0x%x\n", page_offset);

	int statRet = stat(argv[3], &stFileInfo);
	if (statRet != 0)
		printf("\nError opening file %s\n", argv[3]);

	if((stFileInfo.st_size/(1024*1024)) > 256) {
		more_than_512mb_ram = 1;
		printf("\nEBICS0 is more than 256 MB. Assuming 0x40000000 to 0x5ffffff is in EBICS0\nand the rest is in EBI1CS1\n");
	}

	imem_file.open(imem_c, ios::in|ios::binary);

	if(imem_file.fail() || imem_file.bad() || !imem_file.is_open()) {
		printf("Failed to open IMEM file\n");
		return -1;
	}

	ebics1_file.open(ebi1cs1, ios::in|ios::binary);

	if(ebics1_file.fail() || ebics1_file.bad() || !ebics1_file.is_open()) {
		printf("Failed to open ebi1cs1 file\n");
		return -1;
	}

	ebics0_file.open(ebics0, ios::in|ios::binary);

	if(ebics0_file.fail() || ebics0_file.bad() || !ebics0_file.is_open()) {
		printf("Failed to open ebics0 file\n");
		return -1;
	}

	load_symbols();
	load_main_unwind_table();

	if(!no_tz)
		do_TZ_dump();

	do_dump_stacks();

	printf("\nNow printing out logbuf...\n");

	dump_logbuf();

	return 0;
}
