#
# Copyright (c) 2009 QUALCOMM Incorporated.
#
LOCAL_PATH:= $(call my-dir)

ifeq ($(TARGET_BOARD_PLATFORM_GPU),qcom-adreno200)

GSL_KERNEL_DRIVER = 1

# binary firmware bits
include $(CLEAR_VARS)
LOCAL_MODULE := yamato_pfp.fw
LOCAL_MODULE_TAGS := user
LOCAL_MODULE_CLASS := ETC
LOCAL_MODULE_PATH := $(TARGET_OUT_ETC)/firmware
LOCAL_SRC_FILES := firmware/yamato_pfp.fw
include $(BUILD_PREBUILT)

include $(CLEAR_VARS)
LOCAL_MODULE := yamato_pm4.fw
LOCAL_MODULE_TAGS := user
LOCAL_MODULE_CLASS := ETC
LOCAL_MODULE_PATH := $(TARGET_OUT_ETC)/firmware
LOCAL_SRC_FILES := firmware/yamato_pm4.fw
include $(BUILD_PREBUILT)

ifneq ($(HAVE_ADRENO200_SOURCE),true)

# Shader Compiler (static)
include $(CLEAR_VARS)
LOCAL_PREBUILT_LIBS := libsc-adreno200.a
include $(BUILD_MULTI_PREBUILT)

# GSL (shared lib)
include $(CLEAR_VARS)
LOCAL_PREBUILT_OBJ_FILES := $(wildcard $(LOCAL_PATH)/libgsl_objs/*.o)
LOCAL_PREBUILT_OBJ_FILES := $(patsubst $(LOCAL_PATH)/%,%,$(LOCAL_PREBUILT_OBJ_FILES))
LOCAL_MODULE := libgsl
LOCAL_SHARED_LIBRARIES := liblog libdl
LOCAL_STATIC_LIBRARIES := libsc-adreno200
LOCAL_PRELINK_MODULE := false
include $(BUILD_SHARED_LIBRARY)

# EGL 1.3
include $(CLEAR_VARS)
LOCAL_PREBUILT_OBJ_FILES := $(wildcard $(LOCAL_PATH)/libEGL_objs/*.o)
LOCAL_PREBUILT_OBJ_FILES := $(patsubst $(LOCAL_PATH)/%,%,$(LOCAL_PREBUILT_OBJ_FILES))
LOCAL_MODULE_PATH := $(TARGET_OUT)/lib/egl
LOCAL_MODULE := libEGL_adreno200
LOCAL_LDLIBS := -lpthread
LOCAL_SHARED_LIBRARIES := liblog libdl libgsl libhardware
LOCAL_PRELINK_MODULE := false
include $(BUILD_SHARED_LIBRARY)

# GLES 2.0
include $(CLEAR_VARS)
LOCAL_PREBUILT_OBJ_FILES := $(wildcard $(LOCAL_PATH)/libGLESv2_objs/*.o)
LOCAL_PREBUILT_OBJ_FILES := $(patsubst $(LOCAL_PATH)/%,%,$(LOCAL_PREBUILT_OBJ_FILES))
LOCAL_MODULE_PATH := $(TARGET_OUT)/lib/egl
LOCAL_MODULE := libGLESv2_adreno200
LOCAL_SHARED_LIBRARIES := liblog libdl libgsl
LOCAL_STATIC_LIBRARIES := libsc-adreno200
LOCAL_PRELINK_MODULE := false
include $(BUILD_SHARED_LIBRARY)

# GLES 1.1
include $(CLEAR_VARS)
LOCAL_PREBUILT_OBJ_FILES := $(wildcard $(LOCAL_PATH)/libGLESv1_CM_objs/*.o)
LOCAL_PREBUILT_OBJ_FILES := $(patsubst $(LOCAL_PATH)/%,%,$(LOCAL_PREBUILT_OBJ_FILES))
LOCAL_MODULE_PATH := $(TARGET_OUT)/lib/egl
LOCAL_MODULE := libGLESv1_CM_adreno200
LOCAL_SHARED_LIBRARIES := liblog libdl libgsl
LOCAL_STATIC_LIBRARIES := libsc-adreno200
LOCAL_PRELINK_MODULE := false
include $(BUILD_SHARED_LIBRARY)

endif # $(HAVE_ADRENO200_SOURCE) != true
endif # $(TARGET_BOARD_PLATFORM_GPU) == qcom-adreno200
