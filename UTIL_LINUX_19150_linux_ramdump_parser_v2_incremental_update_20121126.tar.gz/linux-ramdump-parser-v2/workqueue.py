# Copyright (c) 2012, The Linux Foundation. All rights reserved.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 and
# only version 2 as published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

import sys
import re
import os
import struct
import datetime
import array
import string
import bisect
import traceback
from subprocess import *
from optparse import OptionParser
from optparse import OptionGroup
from struct import unpack
from ctypes import *
from tempfile import *
from print_out import *

def print_workqueue_state_3_0(ram_dump) :
    print_out_str ("======================= WORKQUEUE STATE ============================")
    per_cpu_offset_addr = ram_dump.addr_lookup("__per_cpu_offset")
    global_cwq_sym_addr = ram_dump.addr_lookup("global_cwq")
    system_wq_addr = ram_dump.addr_lookup("system_long_wq")

    idle_list_offset = ram_dump.get_offset_struct("((struct global_cwq *)0x0)", "idle_list")
    worklist_offset = ram_dump.get_offset_struct("((struct global_cwq *)0x0)", "worklist")
    busy_hash_offset = ram_dump.get_offset_struct("((struct global_cwq *)0x0)", "busy_hash")
    scheduled_offset = ram_dump.get_offset_struct("((struct worker *)0x0)", "scheduled")
    worker_task_offset = ram_dump.get_offset_struct("((struct worker *)0x0)", "task")
    worker_entry_offset = ram_dump.get_offset_struct("((struct worker *)0x0)", "entry")
    offset_comm = ram_dump.get_offset_struct("((struct task_struct *)0x0)", "comm")
    work_entry_offset = ram_dump.get_offset_struct("((struct work_struct *)0x0)", "entry")
    work_hentry_offset = ram_dump.get_offset_struct("((struct worker *)0x0)", "hentry")
    work_func_offset = ram_dump.get_offset_struct("((struct work_struct *)0x0)", "func")
    current_work_offset = ram_dump.get_offset_struct("((struct worker *)0x0)", "current_work")
    cpu_wq_offset = ram_dump.get_offset_struct("((struct workqueue_struct *)0x0)", "cpu_wq")
    unbound_gcwq_addr = ram_dump.addr_lookup("unbound_global_cwq")

    if per_cpu_offset_addr is None :
        per_cpu_offset0 = 0
        per_cpu_offset1 = 0
    else :
        per_cpu_offset0 = ram_dump.read_word(per_cpu_offset_addr)
        per_cpu_offset1 = ram_dump.read_word(per_cpu_offset_addr+4)

    global_cwq_cpu0_addr = global_cwq_sym_addr + per_cpu_offset0

    idle_list_addr0 = ram_dump.read_word(global_cwq_cpu0_addr + idle_list_offset)
    idle_list_addr1 = ram_dump.read_word(unbound_gcwq_addr + idle_list_offset)

    worklist_addr0 = ram_dump.read_word(global_cwq_cpu0_addr + worklist_offset)
    worklist_addr1 = ram_dump.read_word(unbound_gcwq_addr + worklist_offset)

    s = "<"
    for a in range(0,64) :
        s = s + "I"

    busy_hash0 = ram_dump.read_string(global_cwq_cpu0_addr + busy_hash_offset,s)
    busy_hash1 = ram_dump.read_string(unbound_gcwq_addr + busy_hash_offset,s)
    busy_hash = []
    for a in busy_hash0 :
        busy_hash.append(a)

    for a in busy_hash1 :
        busy_hash.append(a)


    for k in range(0,128) :
        next_busy_worker = busy_hash[k]
        if busy_hash[k] != 0 :
            cnt = 0
            while True :
                worker_addr = next_busy_worker - work_hentry_offset
                worker_task_addr = ram_dump.read_word(worker_addr + worker_task_offset)
                if worker_task_addr is None or worker_task_addr == 0 :
                    break
                taskname = ram_dump.read_cstring(worker_task_addr + offset_comm, 16)
                scheduled_addr = ram_dump.read_word(worker_addr + scheduled_offset)
                current_work_addr = ram_dump.read_word(worker_addr + current_work_offset)
                current_work_func = ram_dump.read_word(current_work_addr + work_func_offset)
                worker_name, a = ram_dump.unwind_lookup(current_work_func)
                print_out_str ("BUSY Workqueue worker : {0} current_work: {1}".format(taskname, worker_name))
                if cnt > 200 :
                    break
                cnt += 1
                next_busy_worker = ram_dump.read_word(worker_addr + work_hentry_offset)
                if next_busy_worker == 0 :
                    break

    for i in (0, 1) :
        if i == 0:
            idle_list_addr = idle_list_addr0
        else :
            idle_list_addr = idle_list_addr1
        next_entry = idle_list_addr
        while True :
            worker_addr = next_entry - worker_entry_offset
            worker_task_addr = ram_dump.read_word(next_entry - worker_entry_offset + worker_task_offset)
            if worker_task_addr is None or worker_task_addr == 0 :
                break

            taskname = ram_dump.read_cstring((worker_task_addr + offset_comm), 16)
            scheduled_addr = ram_dump.read_word(worker_addr + scheduled_offset)
            current_work_addr = ram_dump.read_word(worker_addr + current_work_offset)
            next_entry = ram_dump.read_word(next_entry)
            if current_work_addr != 0 :
                current_work_func = ram_dump.read_word(current_work_addr + work_func_offset)
                current_work_name, foo = ram_dump.unwind_lookup(current_work_func)
            else :
                current_work_func = 0
                current_work_name = "(null)"

            if next_entry == idle_list_addr :
                break


            print_out_str ("IDLE Workqueue worker: {0} current_work: {1}".format(taskname, current_work_name))
            if scheduled_addr == (worker_addr + scheduled_offset) :
                continue

            if (next_entry == idle_list_addr) :
                break

    print_out_str ("Pending workqueue info")
    for i in (0, 1) :
        if i == 0 :
            worklist_addr = worklist_addr0
        else :
            worklist_addr = worklist_addr1
        next_work_entry = worklist_addr
        while True :
            work_func_addr = ram_dump.read_word(next_work_entry - work_entry_offset + work_func_offset)
            next_work_entry = ram_dump.read_word(next_work_entry)

            if ram_dump.virt_to_phys(work_func_addr) != 0:
                work_func_name, foo = ram_dump.unwind_lookup(work_func_addr)
                if i == 0 :
                    print_out_str ("Pending unbound entry: {0}".format(work_func_name))
                else :
                    print_out_str ("Pending bound entry: {0}".format(work_func_name))
            if next_work_entry == worklist_addr :
                break


def print_workqueue_state(ram_dump) :
        ver = ram_dump.version
        if re.search('3.0.\d',ver) is not None :
                print_workqueue_state_3_0(ram_dump)
        if re.search('3.4.\d',ver) is not None :
                print_workqueue_state_3_0(ram_dump)
