# Copyright (c) 2012, The Linux Foundation. All rights reserved.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 and
# only version 2 as published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

import sys
import re
import os
import struct
import datetime
import array
import string
import bisect
import traceback
from subprocess import *
from optparse import OptionParser
from optparse import OptionGroup
from struct import unpack
from ctypes import *
from tempfile import *
from print_out import *

def page_zonenum(page_flags) :
    # save this in a variable somewhere...
    return (page_flags >> 26) & 3

def page_to_nid(page_flags) :
    return 0

def page_zone(ramdump, page) :
    contig_page_data = ramdump.addr_lookup("contig_page_data")
    node_zones_offset = ramdump.get_offset_struct("((struct pglist_data *)0x0)", "node_zones")
    page_flags_offset = ramdump.get_offset_struct("((struct page *)0x0)", "flags")
    zone_size = ramdump.get_offset_struct("sizeof(struct zone)","")
    page_flags = ramdump.read_word(page + page_flags_offset)
    if page_flags is None :
        return None
    zone = contig_page_data + node_zones_offset + (page_zonenum(page_flags)*zone_size)
    return zone

def zone_is_highmem(ramdump, zone) :
    if zone is None :
        return False
    # not at all how linux does it but it works for our purposes...
    zone_name_offset = ramdump.get_offset_struct("((struct zone *)0x0)","name")
    zone_name_addr = ramdump.read_word(zone + zone_name_offset)
    if zone_name_addr is None :
        return False
    zone_name = ramdump.read_cstring(zone_name_addr, 48)
    if zone_name is None :
        # XXX do something?
        return False
    if zone_name == "HighMem" :
        return True
    else :
        return False

def hash32(val, bits) :
    chash = c_uint(val * 0x9e370001).value
    return chash >> (32 - bits)

def page_slot(ramdump, page) :
    hashed = hash32(page, 7)
    htable = ramdump.addr_lookup("page_address_htable")
    htable_size = ramdump.get_offset_struct("sizeof(page_address_htable[0])","")
    return htable + htable_size * hashed

def page_to_section(page_flags) :
    # again savefn8n variable
    return (page_flags >> 28) & 0xF

def nr_to_section(ramdump, sec_num) :
    memsection_struct_size = ramdump.get_offset_struct("sizeof(struct mem_section)","")
    sections_per_root = 4096 / memsection_struct_size
    sect_nr_to_root = sec_num / sections_per_root
    masked = sec_num & (sections_per_root - 1)
    mem_section_addr = ramdump.addr_lookup("mem_section")
    mem_section = ramdump.read_word(mem_section_addr)
    if mem_section is None :
        return None
    return mem_section + memsection_struct_size *(sect_nr_to_root * sections_per_root + masked)

def section_mem_map_addr(ramdump, section) :
    map_offset = ramdump.get_offset_struct("((struct mem_section *)0x0)","section_mem_map")
    result = ramdump.read_word(section + map_offset)
    return result & ~((1<<2)-1)

def pfn_to_section_nr(pfn) :
    return pfn >> (28-12)

def pfn_to_section(ramdump, pfn) :
    return nr_to_section(ramdump, pfn_to_section_nr(pfn))

def pfn_to_page(ramdump, pfn) :
    sec = pfn_to_section(ramdump, pfn)
    return section_mem_map_addr(ramdump, sec) + pfn * 0x24

def page_to_pfn(ramdump, page) :
    page_flags_offset = ramdump.get_offset_struct("((struct page *)0x0)", "flags")
    flags = ramdump.read_word(page + page_flags_offset)
    if flags is None :
        return 0
    section = page_to_section(flags)
    nr = nr_to_section(ramdump, section)
    addr = section_mem_map_addr(ramdump, nr)
    # divide by struct page size for division fun
    return (page - addr) / 0x24

def lowmem_page_address(ramdump, page) :
    membank1_start = ramdump.read_word(ramdump.addr_lookup("membank1_start"))
    membank0_size = ramdump.read_word(ramdump.addr_lookup("membank0_size"))
    # XXX currently magic
    membank0_phys_offset = 0x80200000
    membank0_page_offset = 0xc0000000
    membank1_phys_offset = membank1_start
    membank1_page_offset = membank0_page_offset + membank0_size
    phys = page_to_pfn(ramdump, page) << 12
    if phys >= membank1_start :
        return phys - membank1_phys_offset + membank1_page_offset
    else :
        return phys - membank0_phys_offset + membank0_page_offset

def page_address(ramdump, page) :
    if not zone_is_highmem(ramdump, page_zone(ramdump, page)) :
        return lowmem_page_address(ramdump, page)

    pas = page_slot(ramdump, page)
    lh_offset = ramdump.get_offset_struct("((struct page_address_slot *)0x0)","lh")
    start = pas + lh_offset
    pam = start
    while True :
        pam = pam - lh_offset
        pam_page_offset = ramdump.get_offset_struct("((struct page_address_map *)0x0)","page")
        pam_virtual_offset = ramdump.get_offset_struct("((struct page_address_map *)0x0)","virtual")
        pam_page = ramdump.read_word(pam + pam_page_offset)
        if pam_page == page :
            ret = ramdump.read_word(pam + pam_virtual_offset)
            return ret
        pam = ramdump.read_word(pam + lh_offset)
        if pam == start :
            return None

def get_free_pointer(ramdump, s, obj) :
    # just like validate_slab_slab!
    slab_offset_offset = ramdump.get_offset_struct("((struct kmem_cache *)0x0)", "offset")
    slab_offset = ramdump.read_word(s + slab_offset_offset)
    return ramdump.read_word(obj + slab_offset)

def slab_index(ramdump, p, addr, slab) :
    slab_size_offset = ramdump.get_offset_struct("((struct kmem_cache *)0x0)", "size")
    slab_size = ramdump.read_word(slab + slab_size_offset)
    if slab_size is None :
        return -1
    return (p - addr) / slab_size

def get_map(ramdump, slab, page, bitarray) :
    freelist_offset = ramdump.get_offset_struct("((struct page *)0x0)", "freelist")
    freelist = ramdump.read_word(page + freelist_offset)
    p = freelist
    addr = page_address(ramdump, page)
    if addr is None :
        return
    while p != 0 and p is not None:
        idx = slab_index(ramdump, p, addr, slab)
        if idx >= len(bitarray)  or idx < 0:
            return
        bitarray[idx] = 1
        p = get_free_pointer(ramdump, slab, p)

def get_track(ramdump, slab, obj, track_type) :
    track_size = ramdump.get_offset_struct("sizeof(struct track)","")
    slab_offset_offset = ramdump.get_offset_struct("((struct kmem_cache *)0x0)", "offset")
    slab_inuse_offset = ramdump.get_offset_struct("((struct kmem_cache *)0x0)", "inuse")
    slab_offset = ramdump.read_word(slab + slab_offset_offset)
    slab_inuse = ramdump.read_word(slab + slab_inuse_offset)
    if slab_offset != 0 :
        p = obj + slab_offset + 4
    else :
        p = obj + slab_inuse
    return p + track_type*track_size

def print_track(ramdump, slab, obj, track_type) :
    p = get_track(ramdump, slab, obj, track_type)
    track_addrs_offset = ramdump.get_offset_struct("((struct track *)0x0)","addrs")
    start = p + track_addrs_offset
    if track_type == 0 :
        print_out_str ("   ALLOC STACK")
    else :
        print_out_str ("   FREE STACK")
    for i in range(0, 16) :
        a = ramdump.read_word(start + 4*i)
        if a == 0 :
            break
        look = ramdump.unwind_lookup(a)
        if look is None :
            return
        symname, offset = look
        print_out_str ("      [<{0:x}>] {1}+0x{2:x}".format(a, symname, offset))
    print_out_str ("")

def get_nobjects(ramdump, page) :
    if re.search('3\.0\.\d',ramdump.version) is not None :
        n_objects_offset = ramdump.get_offset_struct("((struct page *)0x0)", "objects")
        n_objects = ramdump.read_halfword(page + n_objects_offset)
        return n_objects
    if re.search('3\.4\.\d',ramdump.version) is not None :
        # The objects field is now a bit field. This confuses GDB as it thinks the
        # offset is always 0. Work around this for now
        map_count_offset = ramdump.get_offset_struct("((struct page *)0x0)", "_mapcount")
        count = ramdump.read_word(page + map_count_offset)
        if count is None :
            return None
        n_objects = (count >> 16) & 0xFFFF
        return n_objects

def print_slab(ramdump, slab_start, slab, page) :
    p = slab_start
    if page is None :
        return
    n_objects = get_nobjects(ramdump, page)
    if n_objects is None :
        return
    slab_size_offset = ramdump.get_offset_struct("((struct kmem_cache *)0x0)", "size")
    slab_size = ramdump.read_word(slab + slab_size_offset)
    if slab_size is None :
        return
    slab_max_offset = ramdump.get_offset_struct("((struct kmem_cache *)0x0)", "max")
    slab_max = ramdump.read_word(slab + slab_max_offset)
    if slab_max is None :
        return
    bitarray = [0] * slab_max
    addr = page_address(ramdump, page)
    get_map(ramdump, slab, page, bitarray)
    while p < slab_start +  n_objects*slab_size :
        idx = slab_index(ramdump, p, addr, slab)
        bitidx = slab_index(ramdump, p, addr, slab)
        if bitidx >= len(bitarray) or bitidx < 0:
            return
        if bitarray[bitidx] == 1 :
            print_out_str ("   Object {0:x}-{1:x} FREE".format(p, p+slab_size))
        else :
            print_out_str ("   Object {0:x}-{1:x} ALLOCATED".format(p, p+slab_size))
        if ramdump.is_config_defined("CONFIG_SLUB_DEBUG_ON") :
            print_track(ramdump, slab, p, 0)
            print_track(ramdump, slab, p, 1)
        p = p + slab_size

def print_slab_page_info(ramdump, slab, slab_node, start) :
    page = ramdump.read_word(start)
    if page == 0 :
        return
    slab_lru_offset = ramdump.get_offset_struct("((struct page *)0x0)", "lru")
    page_flags_offset = ramdump.get_offset_struct("((struct page *)0x0)", "flags")
    slab_node_offset = ramdump.get_offset_struct("((struct kmem_cache *)0x0)", "size")
    while page != start:
        if page is None :
            return
        page = page - slab_lru_offset
        page_flags = ramdump.read_word(page + page_flags_offset)
        page_addr = page_address(ramdump, page)
        print_slab(ramdump, page_addr, slab, page)
        page = ramdump.read_word(page + slab_lru_offset)

def print_per_cpu_slab_info(ramdump, slab, slab_node, start) :
    page = ramdump.read_word(start)
    if page == 0 :
        return
    page_flags_offset = ramdump.get_offset_struct("((struct page *)0x0)", "flags")
    if page is None :
        return
    page_flags = ramdump.read_word(page + page_flags_offset)
    page_addr = page_address(ramdump, page)
    print_slab(ramdump, page_addr, slab, page)

slab_offsets_common = [
        ("((struct kmem_cache *)0x0)", "list", 0, 0),
        ("((struct kmem_cache *)0x0)", "name", 0, 0),
        ("((struct kmem_cache *)0x0)", "node", 0, 0),
        ("((struct kmem_cache *)0x0)", "size", 0, 0),
        ("((struct kmem_cache *)0x0)", "offset", 0, 0),
        ("((struct kmem_cache *)0x0)", "max", 0, 0),
        ("((struct kmem_cache *)0x0)", "inuse", 0, 0),
        ("((struct kmem_cache *)0x0)", "cpu_slab", 0, 0),
        ("((struct kmem_cache_cpu *)0x0)", "page", 0, 0),
        ("((struct kmem_cache_node *)0x0)", "partial", 0, 0),
        ("((struct kmem_cache_node *)0x0)", "full", 0, 0),
        ("((struct page *)0x0)", "lru", 0, 0),
        ("((struct page *)0x0)", "flags", 0, 0),
        ("((struct page *)0x0)", "objects", 0, 0),
        ("((struct page *)0x0)", "freelist", 0, 0),
        ("((struct pglist_data *)0x0)", "node_zones", 0, 0),
        ("sizeof(struct zone)","",0, 1),
        ("sizeof(struct mem_section)","",0, 1),
        ("sizeof(struct page)","",0, 1),
        ("((struct zone *)0x0)","name",0, 0),
        ("sizeof(page_address_htable[0])","",0,1),
        ("((struct page_address_slot *)0x0)","lh",0, 0),
        ("((struct page_address_map *)0x0)","page",0, 0),
        ("((struct page_address_map *)0x0)","virtual",0, 0),
        ("((struct mem_section *)0x0)","section_mem_map",0, 0),
        ("((struct track *)0x0)","addrs",0,0),
        ("sizeof(struct track)","",0, 1),
]

slab_offsets_3_4 = [
        ("((struct page *)0x0)", "_mapcount", 0, 0),
]

# based on validate_slab_cache. Currently assuming there is only one numa node
# in the system because the code to do that correctly is a big pain. This will
# need to be changed if we ever do NUMA properly.
def print_slab_info(ramdump) :
    if re.search('3\.0\.\d',ramdump.version) is not None :
        ramdump.setup_offset_table(slab_offsets_common)
    if re.search('3\.4\.\d',ramdump.version) is not None :
        ramdump.setup_offset_table(slab_offsets_common + slab_offsets_3_4)
    original_slab = ramdump.addr_lookup("slab_caches")
    per_cpu_offset = ramdump.addr_lookup("__per_cpu_offset")
    cpu_present_bits_addr = ramdump.addr_lookup("cpu_present_bits");
    cpu_present_bits = ramdump.read_word(cpu_present_bits_addr)
    cpus = bin(cpu_present_bits).count('1')
    slab_list_offset = ramdump.get_offset_struct("((struct kmem_cache *)0x0)", "list")
    slab_name_offset = ramdump.get_offset_struct("((struct kmem_cache *)0x0)", "name")
    slab_node_offset = ramdump.get_offset_struct("((struct kmem_cache *)0x0)", "node")
    cpu_cache_page_offset = ramdump.get_offset_struct("((struct kmem_cache_cpu *)0x0)", "page")
    cpu_slab_offset = ramdump.get_offset_struct("((struct kmem_cache *)0x0)", "cpu_slab")
    slab_partial_offset = ramdump.get_offset_struct("((struct kmem_cache_node *)0x0)", "partial")
    slab_full_offset = ramdump.get_offset_struct("((struct kmem_cache_node *)0x0)", "full")
    slab = ramdump.read_word(original_slab)
    while slab != original_slab :
        slab = slab - slab_list_offset
        slab_name_addr = ramdump.read_word(slab + slab_name_offset)
        # actually an array but again, no numa
        slab_node_addr = ramdump.read_word(slab + slab_node_offset)
        slab_node = ramdump.read_word(slab_node_addr)
        slab_name = ramdump.read_cstring(slab_name_addr, 48)
        cpu_slab_addr = ramdump.read_word(slab + cpu_slab_offset)
        print_out_str ("{0:x} slab {1}".format(slab, slab_name, slab_node_addr))
        print_slab_page_info(ramdump, slab, slab_node, slab_node_addr + slab_partial_offset)
        print_slab_page_info(ramdump, slab, slab_node, slab_node_addr + slab_full_offset)

        for i in range(0,cpus) :
            cpu_slabn_addr = cpu_slab_addr + ramdump.read_word(per_cpu_offset + 4*i)
            print_per_cpu_slab_info(ramdump, slab, slab_node, cpu_slabn_addr + cpu_cache_page_offset)

        slab = ramdump.read_word(slab + slab_list_offset)
