Steps to apply the patch
========================
1) unzip the lpatest zip file
2) copy the files to vendor/qcom-opensource/kernel-tests/mm-audio/audio-native/qdsp5 folder



