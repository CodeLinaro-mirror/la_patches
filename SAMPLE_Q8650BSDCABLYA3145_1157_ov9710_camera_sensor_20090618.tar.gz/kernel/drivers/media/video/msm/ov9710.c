/* Copyright (c) 2008-2009, Code Aurora Forum. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of Code Aurora Forum nor
 *       the names of its contributors may be used to endorse or promote
 *       products derived from this software without specific prior written
 *       permission.
 *
 * Alternatively, provided that this notice is retained in full, this software
 * may be relicensed by the recipient under the terms of the GNU General Public
 * License version 2 ("GPL") and only version 2, in which case the provisions of
 * the GPL apply INSTEAD OF those given above.  If the recipient relicenses the
 * software under the GPL, then the identification text in the MODULE_LICENSE
 * macro must be changed to reflect "GPLv2" instead of "Dual BSD/GPL".  Once a
 * recipient changes the license terms to the GPL, subsequent recipients shall
 * not relicense under alternate licensing terms, including the BSD or dual
 * BSD/GPL terms.  In addition, the following license statement immediately
 * below and between the words START and END shall also then apply when this
 * software is relicensed under the GPL:
 *
 * START
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 2 and only version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
 * END
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include <linux/delay.h>
#include <linux/types.h>
#include <linux/i2c.h>
#include <linux/uaccess.h>
#include <linux/miscdevice.h>
#include <media/msm_camera.h>
#include <mach/gpio.h>
#include <mach/camera.h>
#include "ov9710.h"

/*=============================================================
	SENSOR REGISTER DEFINES
==============================================================*/

/* Register defines */
/* Core Settings */
#define REG_0x1e 0x1e 
#define REG_0x5f  0x5f 
#define REG_0x69  0x69 
#define REG_0x65  0x65 
#define REG_0x68  0x68 
#define REG_0x39  0x39 
#define REG_0x4d  0x4d 
#define REG_0xc1  0xc1 
/* DSP */
#define REG_0x96  0x96
#define REG_0xbc  0xbc
/* Resolution and Format */
#define REG_0x12 0x12
#define REG_0x3b 0x3b
#define REG_0x97 0x97

/* ---- Place generated settings here ---- */
#define REG_0x17 0x17	
#define REG_0x18 0x18	
#define REG_0x19 0x19	
#define REG_0x1a 0x1a	
#define REG_0x03 0x03	
#define REG_0x32 0x32	
#define REG_0x98 0x98
#define REG_0x99 0x99 
#define REG_0x9a 0x9a                       
#define REG_0x57 0x57 
#define REG_0x58 0x58 
#define REG_0x59 0x59                        
#define REG_0x4b 0x4b 
#define REG_0x4c 0x4c 
#define REG_0x3d 0x3d 
#define REG_0x3e 0x3e                        
#define REG_0xbd 0xbd 
#define REG_0xbe 0xbe                        
#define REG_0x2c 0x2c
#define REG_0x23 0x23
  
/* AWB */
#define REG_0x96 0x96

/* YAVG */
#define REG_0x4e  0x4e    /* AVERAGE */
#define REG_0x4f  0x4f    		
#define REG_0x50  0x50    
#define REG_0x51  0x51    
                         
#define REG_0x24  0x24    /* Exposure windows */
#define REG_0x25  0x25    
#define REG_0x26  0x26    

/* Clock */
#define REG_0x5c  0x5c
#define REG_0x5d  0x5d
#define REG_0x11  0x11
#define REG_0x2a  0x2a
#define REG_0x2b  0x2b
#define REG_0x2d  0x2d
#define REG_0x2e  0x2e

/* General */
#define REG_0x13  0x13
#define REG_0x14  0x14	//Gain Ceiling 8X

/* Omnivision5630 product ID register address */
#define OV9710_PIDH_REG                0x0A
#define OV9710_PIDL_REG                0x0B
#define OV9710_PID                     0x97 /* Omnivision5630 product ID */
#define OV9710_VER                     0x11 /* Omnivision5630 version */
#define REG_OV9710_GAIN                0x00 /* Gain and line count */
#define REG_OV9710_AEC_MSB             0x16
#define REG_OV9710_AEC_LSB             0x10
#define REG_COLOR_BAR_PATTERN_SEL_REG  0x97 /* Test Pattern */
#define REG_COLOR_BAR_ENABLE_REG       0x12

enum ov9710_test_mode_t {
	TEST_OFF,
	TEST_1,
	TEST_2,
	TEST_3
};

enum ov9710_resolution_t {
	QTR_SIZE,
	FULL_SIZE,
	INVALID_SIZE
};

enum ov9710_reg_update_t {
  /* Sensor egisters that need to be updated during initialization */
  REG_INIT,
  /* Sensor egisters that needs periodic I2C writes */
  UPDATE_PERIODIC,
  /* All the sensor Registers will be updated */
  UPDATE_ALL,
  /* Not valid update */
  UPDATE_INVALID
};

enum ov9710_setting_t {
	RES_PREVIEW,
	RES_CAPTURE
};

/*
 * Time in milisecs for waiting for the sensor to reset.
 */
#define OV9710_RESET_DELAY_MSECS   66

/* for 30 fps preview */
#define OV9710_DEFAULT_CLOCK_RATE  24000000

#define OV9710_FULL_SIZE_WIDTH       1280     
#define OV9710_FULL_SIZE_HEIGHT       800     
#define OV9710_SNAPSHOT_DUMMY_PIXELS    0 
#define OV9710_SNAPSHOT_DUMMY_LINES     0

#define OV9710_QTR_SIZE_WIDTH          640 
#define OV9710_QTR_SIZE_HEIGHT         400   
#define OV9710_PREVIEW_DUMMY_PIXELS     0 
#define OV9710_PREVIEW_DUMMY_LINES      0

#define OV9710_HRZ_FULL_BLK_PIXELS    408 
#define OV9710_VER_FULL_BLK_LINES      28
#define OV9710_HRZ_QTR_BLK_PIXELS    1048
#define OV9710_VER_QTR_BLK_LINES       14

#define OV9710_DEFAULT_MAX_FPS     60

/* FIXME: Changes from here */
struct ov9710_work_t {
	struct work_struct work;
};

static struct  ov9710_work_t *ov9710_sensorw;
static struct  i2c_client *ov9710_client;

struct ov9710_ctrl_t {
	struct  msm_camera_sensor_info *sensordata;

	enum sensor_mode_t sensormode;
	uint32_t fps_divider; 		/* init to 1 * 0x00000400 */
	uint32_t pict_fps_divider; 	/* init to 1 * 0x00000400 */

	uint16_t my_reg_gain;
    uint32_t my_reg_line_count;
	uint16_t total_lines_per_frame;

	enum ov9710_resolution_t prev_res;
	enum ov9710_resolution_t pict_res;
	enum ov9710_resolution_t curr_res;
	enum ov9710_test_mode_t  set_test;

	unsigned short imgaddr;
};


static struct ov9710_ctrl_t *ov9710_ctrl;
static DECLARE_WAIT_QUEUE_HEAD(ov9710_wait_queue);
DECLARE_MUTEX(ov9710_sem);

/*=============================================================*/

static int ov9710_i2c_rxdata(unsigned short saddr,
	unsigned char *rxdata, int length)
{
	struct i2c_msg msgs[] = {
	{
		.addr   = saddr,
		.flags = 0,
		.len   = 2,
		.buf   = rxdata,
	},
	{
		.addr  = saddr,
		.flags = I2C_M_RD,
		.len   = length,
		.buf   = rxdata,
	},
	};

	if (i2c_transfer(ov9710_client->adapter, msgs, 2) < 0) {
		CDBG("ov9710_i2c_rxdata failed!\n");
		return -EIO;
	}

	return 0;
}

static int32_t ov9710_i2c_read_b(unsigned short saddr, unsigned char 
raddr, unsigned short *rdata)
{
	int32_t rc = 0;
	if (!rdata)
		return -EIO;
	rc = ov9710_i2c_rxdata(saddr, &raddr, 1);
	if (rc < 0)
		return rc;
	*rdata = raddr;
	if (rc < 0)
		CDBG("ov9710_i2c_read_b failed!\n");
	return rc;
}

static int32_t ov9710_i2c_txdata(unsigned short saddr,
	unsigned char *txdata, int length)
{
	struct i2c_msg msg[] = {
	{
		.addr = saddr,
		.flags = 0,
		.len = length,
		.buf = txdata,
	},
	};

	if (i2c_transfer(ov9710_client->adapter, msg, 1) < 0) {
		CDBG("ov9710_i2c_txdata faild\n");
		return -EIO;
	}

	return 0;
}

static int32_t ov9710_i2c_write_b(unsigned short saddr,
	unsigned short waddr, unsigned short wdata)
{
	int32_t rc = -EFAULT;
	unsigned char buf[2];

	memset(buf, 0, sizeof(buf));
	buf[0] = waddr;
	buf[1] = wdata;
	rc = ov9710_i2c_txdata(saddr, buf, 2);

	if (rc < 0)
		CDBG("i2c_write failed, addr = 0x%x, val = 0x%x!\n",
		waddr, wdata);

	return rc;
}

static int32_t ov9710_test(enum ov9710_test_mode_t mo)
{
	int32_t rc = 0;

	if (mo == TEST_OFF)
		return 0;
	else {
		if (ov9710_i2c_write_b(ov9710_client->addr,
			REG_COLOR_BAR_PATTERN_SEL_REG, 0x88) < 0)
			return rc;
	}
	return rc;
}

static int32_t ov9710_set_default_focus(uint8_t af_step)
{
	return 0;
}

static void ov9710_get_pict_fps(uint16_t fps, uint16_t *pfps)
{
	/* input fps is preview fps in Q8 format */
	uint32_t divider;   /*Q10 */
	uint16_t preview_frame_length_lines, snapshot_frame_length_lines;
	uint16_t preview_line_length_pck, snapshot_line_length_pck;


	if (ov9710_ctrl->prev_res == QTR_SIZE) {
	  preview_frame_length_lines = OV9710_QTR_SIZE_HEIGHT + OV9710_VER_QTR_BLK_LINES;
	  preview_line_length_pck =  OV9710_QTR_SIZE_WIDTH + OV9710_HRZ_QTR_BLK_PIXELS;
	  snapshot_frame_length_lines = OV9710_QTR_SIZE_HEIGHT + OV9710_VER_QTR_BLK_LINES;
	  snapshot_line_length_pck = OV9710_QTR_SIZE_WIDTH + OV9710_HRZ_QTR_BLK_PIXELS;

	} else {
		/* full size resolution used for preview. */
	  preview_frame_length_lines = OV9710_FULL_SIZE_HEIGHT + OV9710_VER_FULL_BLK_LINES;
	  preview_line_length_pck =  OV9710_FULL_SIZE_WIDTH + OV9710_HRZ_FULL_BLK_PIXELS;
	  snapshot_frame_length_lines = OV9710_FULL_SIZE_HEIGHT + OV9710_VER_FULL_BLK_LINES;
	  snapshot_line_length_pck = OV9710_FULL_SIZE_WIDTH + OV9710_HRZ_FULL_BLK_PIXELS;
	}

	divider = (preview_frame_length_lines * preview_line_length_pck)
            / (snapshot_frame_length_lines * snapshot_line_length_pck);

	/* Verify PCLK settings and frame sizes. */
	*pfps = (uint16_t) (fps * divider);
}

static uint16_t ov9710_get_prev_lines_pf(void)
{
  if (ov9710_ctrl->pict_res == QTR_SIZE) {
	  return (OV9710_QTR_SIZE_HEIGHT + OV9710_VER_QTR_BLK_LINES);
  } else  {
	  return (OV9710_FULL_SIZE_HEIGHT + OV9710_VER_FULL_BLK_LINES);
  }
}

static uint16_t ov9710_get_prev_pixels_pl(void)
{
  if (ov9710_ctrl->pict_res == QTR_SIZE) {
	  return (OV9710_QTR_SIZE_WIDTH + OV9710_HRZ_QTR_BLK_PIXELS);
  } else  {
	  return (OV9710_FULL_SIZE_WIDTH + OV9710_HRZ_FULL_BLK_PIXELS);
  }
}

static uint16_t ov9710_get_pict_lines_pf(void)
{
  if (ov9710_ctrl->pict_res == QTR_SIZE) {
	  return (OV9710_QTR_SIZE_HEIGHT + OV9710_VER_QTR_BLK_LINES);
  } else  {
	  return (OV9710_FULL_SIZE_HEIGHT + OV9710_VER_FULL_BLK_LINES);
  }
}

static uint16_t ov9710_get_pict_pixels_pl(void)
{
  if (ov9710_ctrl->pict_res == QTR_SIZE) {
	  return (OV9710_QTR_SIZE_WIDTH + OV9710_HRZ_QTR_BLK_PIXELS);
  } else  {
	  return (OV9710_FULL_SIZE_WIDTH + OV9710_HRZ_FULL_BLK_PIXELS);
  }
}

static uint32_t ov9710_get_pict_max_exp_lc(void)
{
	if (ov9710_ctrl->pict_res == QTR_SIZE) {
		return (OV9710_QTR_SIZE_HEIGHT + OV9710_VER_QTR_BLK_LINES);
	} else  {
		return (OV9710_FULL_SIZE_HEIGHT + OV9710_VER_FULL_BLK_LINES);
	}
}

static int32_t ov9710_set_fps(struct fps_cfg	*fps)
{
	/* input is new fps in Q8 format */
	int32_t rc = 0;

	ov9710_ctrl->fps_divider = fps->fps_div;
	ov9710_ctrl->pict_fps_divider = fps->pict_fps_div;

    ov9710_ctrl->total_lines_per_frame = (uint16_t)
	  ((ov9710_regs.reg_pat[RES_PREVIEW].reg_0x3e << 8) & 0xFF00) +
	  (ov9710_regs.reg_pat[RES_PREVIEW].reg_0x3d & 0x00FF);

	ov9710_ctrl->total_lines_per_frame = 
	  ov9710_ctrl->total_lines_per_frame * fps->fps_div / 0x400;

	 if (ov9710_i2c_write_b(ov9710_client->addr, REG_0x1a,
		(ov9710_ctrl->total_lines_per_frame & 0xFF00) >> 8) < 0)
		  return rc;

	 if (ov9710_i2c_write_b(ov9710_client->addr, REG_0x03, 
         (ov9710_ctrl->total_lines_per_frame & 0x00FF)) < 0)
	      return rc;

	 CDBG("ov9710_set_fps: fps_div is %d, frame_rate is %d\n",
		  fps->fps_div, ov9710_ctrl->total_lines_per_frame);

	return rc;
}

static int32_t ov9710_write_exp_gain(uint16_t gain, uint32_t line)
{
	int32_t rc = 0;
	uint16_t elc;
	uint16_t aec_msb;
	uint16_t aec_lsb;
	uint8_t ov9710_offset = 2;

    if (ov9710_ctrl->prev_res == QTR_SIZE) {
		ov9710_ctrl->total_lines_per_frame = 
		  (OV9710_QTR_SIZE_HEIGHT + OV9710_VER_QTR_BLK_LINES)
		   * ov9710_ctrl->fps_divider;
		/* check if linecount is within range */
	    elc = (uint16_t)line * ov9710_ctrl->fps_divider / 0x00000400;
	} else {
	  ov9710_ctrl->total_lines_per_frame = 
		  (OV9710_FULL_SIZE_HEIGHT + OV9710_VER_FULL_BLK_LINES)
	      * ov9710_ctrl->pict_fps_divider;
	  /* check if linecount is within range */
	  elc = (uint16_t)line * ov9710_ctrl->pict_fps_divider / 0x00000400;
	}

	if (elc > ov9710_ctrl->total_lines_per_frame - ov9710_offset)
      elc = ov9710_ctrl->total_lines_per_frame - ov9710_offset;

    aec_msb = (elc & 0xFF00) >> 8;
    aec_lsb = elc & 0x00FF;

	if (ov9710_i2c_write_b(ov9710_client->addr,
			0x04, 0x09) < 0)
		return rc;
	if (ov9710_i2c_write_b(ov9710_client->addr,
			REG_OV9710_GAIN, (uint8_t)gain) < 0)
		return rc;
	if (ov9710_i2c_write_b(ov9710_client->addr,
			REG_OV9710_AEC_MSB, aec_msb) < 0)
		return rc;
	if (ov9710_i2c_write_b(ov9710_client->addr,
			REG_OV9710_AEC_LSB, aec_lsb) < 0)
		return rc;
	if (ov9710_i2c_write_b(ov9710_client->addr,
			0x04, 0x00) < 0)
		return rc;
	if (ov9710_i2c_write_b(ov9710_client->addr,
			0xFF, 0xff) < 0)
		return rc;
	return rc;
}

static int32_t ov9710_set_pict_exp_gain(uint16_t gain, uint32_t line)
{
	int32_t rc = 0;
	rc = ov9710_write_exp_gain(gain, line);
	return rc;
}

static int32_t ov9710_setting(enum ov9710_reg_update_t rupdate,
	enum ov9710_setting_t rt)
{
	int32_t rc = 0;

	switch (rupdate) {
	case UPDATE_PERIODIC:{

	if (rt == RES_PREVIEW ||
			rt == RES_CAPTURE) {
	    /* Reset register */
		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_COLOR_BAR_ENABLE_REG, 0x80) < 0)
			return rc;
		mdelay(5);
        /* Core Settings */
		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0x1e, 0x07) < 0)
			return rc;

		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0x5f, 0x18) < 0)
			return rc;

		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0x69, 0x04) < 0)
			return rc;

		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0x65, 0x2a) < 0)
			return rc;

		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0x68, 0x0a) < 0)
			return rc;

		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0x39, 0x28) < 0)
			return rc;

		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0x4d, 0x90) < 0)
			return rc;

		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0xc1, 0x80) < 0)
			return rc;
        /* DSP */
		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0x96, 0xc1) < 0)
			return rc;

		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0xbc, 0x68) < 0)
			return rc;

		/* Resolution and Format */
		if (rt == RES_PREVIEW) {
		  if (ov9710_i2c_write_b(ov9710_client->addr,
				  REG_0x12, 0x40) < 0)
			  return rc;
		} else if (rt == RES_CAPTURE) {
		  if (ov9710_i2c_write_b(ov9710_client->addr,
					REG_0x12, 0x00) < 0)
				return rc;
		}

		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0x3b, ov9710_regs.reg_pat[rt].reg_0x3b) < 0)
			return rc;
		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0x97, 0x80) < 0)
			return rc;

		/* ---- Place generated settingre ---- */
		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0x17, 0x25) < 0)
			return rc;
		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0x18, 0xA2) < 0)
			return rc;
		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0x19, 0x01) < 0)
			return rc;
		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0x1a, ov9710_regs.reg_pat[rt].reg_0x1a) < 0)
			return rc;
		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0x03, ov9710_regs.reg_pat[rt].reg_0x03) < 0)
			return rc;
		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0x32, 0x07) < 0)
			return rc;
		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0x98, 0x00) < 0)
			return rc;
		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0x99, 0x00) < 0)
			return rc;
		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0x9a, 0x00) < 0)
			return rc;
		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0x57, 0x00) < 0)
			return rc;
		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0x58, ov9710_regs.reg_pat[rt].reg_0x58) < 0)
			return rc;
		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0x59, ov9710_regs.reg_pat[rt].reg_0x59) < 0)
			return rc;
		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0x4b, ov9710_regs.reg_pat[rt].reg_0x4b) < 0)
			return rc;
		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0x4c, ov9710_regs.reg_pat[rt].reg_0x4c) < 0)
			return rc;
		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0x3d, ov9710_regs.reg_pat[rt].reg_0x3d) < 0)
			return rc;
		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0x3e, ov9710_regs.reg_pat[rt].reg_0x3e) < 0)
			return rc;
		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0xbd, ov9710_regs.reg_pat[rt].reg_0xbd) < 0)
			return rc;
		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0xbe, ov9710_regs.reg_pat[rt].reg_0xbe) < 0)
			return rc;
		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0x2c, ov9710_regs.reg_pat[rt].reg_0x2c) < 0)
			return rc;
		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0x23, ov9710_regs.reg_pat[rt].reg_0x23) < 0)
			return rc;
		/* YAVG */
		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0x4e, 0x55) < 0)
			return rc;
		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0x4f, 0x55) < 0)
			return rc;
		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0x50, 0x55) < 0)
			return rc;
		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0x51, 0x55) < 0)
			return rc;
		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0x24, 0x55) < 0)
			return rc;
		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0x25, 0x40) < 0)
			return rc;
		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0x26, 0xa1) < 0)
			return rc;
		/* General */
		/* This register  REG_0x13 enables 
		 * AEC and AWB of the sensor, hence disable */
		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0x13, 0x00) < 0)
			return rc;
		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0x14, 0x40) < 0)
			return rc;

		if (ov9710_test(TEST_OFF) < 0)
			return rc;

		mdelay(5);

		return rc;
	}
	}
		break;

	/*CAMSENSOR_REG_UPDATE_PERIODIC */
	case REG_INIT: {
	if (rt == RES_PREVIEW ||
			rt == RES_CAPTURE) {
	  ov9710_ctrl->fps_divider = 1 * 0x00000400;

	  /* Reset register */
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_COLOR_BAR_ENABLE_REG, 0x80) < 0)
		  return rc;
       mdelay(5);
	  /* Core Settings */
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x1e, 0x07) < 0)
		  return rc;

	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x5f, 0x18) < 0)
		  return rc;

	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x69, 0x04) < 0)
		  return rc;

	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x65, 0x2a) < 0)
		  return rc;

	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x68, 0x0a) < 0)
		  return rc;

	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x39, 0x28) < 0)
		  return rc;

	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x4d, 0x90) < 0)
		  return rc;

	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0xc1, 0x80) < 0)
		  return rc;
	  /* DSP */
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x96, 0xc1) < 0)
		  return rc;

	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0xbc, 0x68) < 0)
		  return rc;
	  /* Resolution and Format */
	  if (rt == RES_PREVIEW) {
		if (ov9710_i2c_write_b(ov9710_client->addr,
				REG_0x12, 0x40) < 0)
			return rc;
	  } else if (rt == RES_CAPTURE) {
		if (ov9710_i2c_write_b(ov9710_client->addr,
				  REG_0x12, 0x00) < 0)
			  return rc;
	  }
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x3b, ov9710_regs.reg_pat[rt].reg_0x3b) < 0)
		  return rc;
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x97, 0x80) < 0)
		  return rc;

	  /* ---- Place generated settingre ---- */
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x17, 0x25) < 0)
		  return rc;
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x18, 0xA2) < 0)
		  return rc;
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x19, 0x01) < 0)
		  return rc;
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x1a, ov9710_regs.reg_pat[rt].reg_0x1a) < 0)
		  return rc;
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x03, ov9710_regs.reg_pat[rt].reg_0x03) < 0)
		  return rc;
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x32, 0x07) < 0)
		  return rc;
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x98, 0x00) < 0)
		  return rc;
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x99, 0x00) < 0)
		  return rc;
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x9a, 0x00) < 0)
		  return rc;
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x57, 0x00) < 0)
		  return rc;
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x58, ov9710_regs.reg_pat[rt].reg_0x58) < 0)
		  return rc;
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x59, ov9710_regs.reg_pat[rt].reg_0x59) < 0)
		  return rc;
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x4b, ov9710_regs.reg_pat[rt].reg_0x4b) < 0)
		  return rc;
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x4c, ov9710_regs.reg_pat[rt].reg_0x4c) < 0)
		  return rc;
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x3d, ov9710_regs.reg_pat[rt].reg_0x3d) < 0)
		  return rc;
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x3e, ov9710_regs.reg_pat[rt].reg_0x3e) < 0)
		  return rc;
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0xbd, ov9710_regs.reg_pat[rt].reg_0xbd) < 0)
		  return rc;
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0xbe, ov9710_regs.reg_pat[rt].reg_0xbe) < 0)
		  return rc;
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x2c, ov9710_regs.reg_pat[rt].reg_0x2c) < 0)
		  return rc;
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x23, ov9710_regs.reg_pat[rt].reg_0x23) < 0)
		  return rc;
	  /* disable sensor AWB */
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  0x38, 0x00) < 0)
		  return rc;
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  0xb6, 0x08) < 0)
	  /* YAVG */
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x4e, 0x55) < 0)
		  return rc;
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x4f, 0x55) < 0)
		  return rc;
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x50, 0x55) < 0)
		  return rc;
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x51, 0x55) < 0)
		  return rc;
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x24, 0x55) < 0)
		  return rc;
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x25, 0x40) < 0)
		  return rc;
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x26, 0xa1) < 0)
		  return rc;

	  /* Clock */
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x5c, 0x59) < 0)
		  return rc;
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x5d, 0x00) < 0)
		  return rc;
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x11, 0x00) < 0)
		  return rc;
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x2a, 0x98) < 0)
		  return rc;
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x2b, 0x06) < 0)
		  return rc;
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x2d, 0x00) < 0)
		  return rc;
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x2e, 0x00) < 0)
		  return rc;

	  /* General */
	  /* This register  REG_0x13 enables 
	   * AEC and AWB of the sensor, hence disable */
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x13, 0x00) < 0)
		  return rc;
	  if (ov9710_i2c_write_b(ov9710_client->addr,
			  REG_0x14, 0x40) < 0)
		  return rc;

      CDBG("!!! ov9710 !!! PowerOn is done! rc %d\n", rc);
	  mdelay(5);
	  return rc;
	}
    } /* case CAMSENSOR_REG_INIT: */
	break;

	/*CAMSENSOR_REG_INIT */
	default:
		rc = -EFAULT;
		break;
	} /* switch (rupdate) */

	return rc;
}

static int32_t ov9710_video_config(enum sensor_mode_t mode,
	enum sensor_resolution_t res)
{
	int32_t rc;

	switch (res) {
	case QTR_SIZE:
		rc = ov9710_setting(UPDATE_PERIODIC, RES_PREVIEW);
		if (rc < 0)
			return rc;

			CDBG("sensor configuration done!\n");
		break;

	case FULL_SIZE:
		rc = ov9710_setting(UPDATE_PERIODIC, RES_CAPTURE);
		if (rc < 0)
			return rc;
		break;

	default:
		return 0;
	} /* switch */

	ov9710_ctrl->prev_res = res;
	ov9710_ctrl->curr_res = res;
	ov9710_ctrl->sensormode = mode;

	rc =
		ov9710_write_exp_gain(ov9710_ctrl->my_reg_gain,
			ov9710_ctrl->my_reg_line_count);

	return rc;
}

static int32_t ov9710_snapshot_config(enum sensor_mode_t mode)
{
	int32_t rc = 0;

	rc =
		ov9710_setting(UPDATE_PERIODIC, RES_CAPTURE);
	if (rc < 0)
		return rc;

	ov9710_ctrl->curr_res = ov9710_ctrl->pict_res;

	ov9710_ctrl->sensormode = mode;

	return rc;
}

static int32_t ov9710_raw_snapshot_config(enum sensor_mode_t mode)
{
	int32_t rc = 0;

	rc = ov9710_setting(UPDATE_PERIODIC, RES_CAPTURE);
	if (rc < 0)
		return rc;

	ov9710_ctrl->curr_res = ov9710_ctrl->pict_res;

	ov9710_ctrl->sensormode = mode;

	return rc;
}

static int32_t ov9710_power_down(void)
{
	return 0;
}

static int32_t ov9710_move_focus(enum sensor_move_focus_t direction,
	int32_t num_steps)
{
	return 0;
}

static int ov9710_sensor_init_done(struct msm_camera_sensor_info *data)
{
	gpio_direction_output(data->sensor_reset, 0);
	gpio_free(data->sensor_reset);
	return 0;
}

static int ov9710_probe_init_sensor(struct msm_camera_sensor_info *data)
{
	int rc;
	unsigned short chipidl, chipidh;

	rc = gpio_request(data->sensor_reset, "ov9710");
	if (!rc)
		gpio_direction_output(data->sensor_reset, 1);
	else
		goto init_probe_done;

	mdelay(20);

	/* 3. Read sensor Model ID: */
	if (ov9710_i2c_read_b(ov9710_client->addr,
		OV9710_PIDH_REG, &chipidh) < 0)
		goto init_probe_fail;

    if (ov9710_i2c_read_b(ov9710_client->addr,
		OV9710_PIDL_REG, &chipidl) < 0)
		goto init_probe_fail;

	CDBG("ov9710 model_id = 0x%x  0x%x\n", chipidh, chipidl);

	/* 4. Compare sensor ID to OV9710 ID: */
	if (chipidh != OV9710_PID || chipidl < OV9710_VER) {
		rc = -ENODEV;
		goto init_probe_fail;
	}

	mdelay(OV9710_RESET_DELAY_MSECS);

  goto init_probe_done;

init_probe_fail:
	gpio_direction_output(data->sensor_reset, 0);
	gpio_free(data->sensor_reset);
init_probe_done:
	return rc;
}

int ov9710_sensor_open_init(struct msm_camera_sensor_info *data)
{
	int32_t  rc;

	ov9710_ctrl = kzalloc(sizeof(struct ov9710_ctrl_t), GFP_KERNEL);
	if (!ov9710_ctrl) {
		CDBG("ov9710_init failed!\n");
		rc = -ENOMEM;
		goto init_done;
	}

	ov9710_ctrl->fps_divider = 1 * 0x00000400;
	ov9710_ctrl->pict_fps_divider = 1 * 0x00000400;
	ov9710_ctrl->set_test = TEST_OFF;
	ov9710_ctrl->prev_res = QTR_SIZE;
	ov9710_ctrl->pict_res = FULL_SIZE;

	if (data)
		ov9710_ctrl->sensordata = data;

	/* enable mclk first */
	msm_camio_clk_rate_set(OV9710_DEFAULT_CLOCK_RATE);
	mdelay(20);

	msm_camio_camif_pad_reg_reset();
	mdelay(20);

  rc = ov9710_probe_init_sensor(data);
	if (rc < 0)
		goto init_fail;
    
	if (ov9710_ctrl->prev_res == QTR_SIZE)
		rc = ov9710_setting(REG_INIT, RES_PREVIEW);
	else
		rc = ov9710_setting(REG_INIT, RES_CAPTURE);

	if (rc < 0)
		goto init_fail;
	else
		goto init_done;

init_fail:
	kfree(ov9710_ctrl);
init_done:
    CDBG("Here2\n");
	return rc;
}

static int ov9710_init_client(struct i2c_client *client)
{
	/* Initialize the MSM_CAMI2C Chip */
	init_waitqueue_head(&ov9710_wait_queue);
	return 0;
}


static int32_t ov9710_set_sensor_mode(enum sensor_mode_t mode,
	enum sensor_resolution_t res)
{
	int32_t rc = 0;

	switch (mode) {
	case SENSOR_PREVIEW_MODE:
		rc = ov9710_video_config(mode, res);
		break;

	case SENSOR_SNAPSHOT_MODE:
		rc = ov9710_snapshot_config(mode);
		break;

	case SENSOR_RAW_SNAPSHOT_MODE:
		rc = ov9710_raw_snapshot_config(mode);
		break;
	default:
		rc = -EINVAL;
		break;
	}
	return rc;
}

int ov9710_sensor_config(void __user *argp)
{
	struct sensor_cfg_data_t cdata;
	long   rc = 0;

	if (copy_from_user(&cdata,
				(void *)argp,
				sizeof(struct sensor_cfg_data_t)))
		return -EFAULT;

	down(&ov9710_sem);

  CDBG("ov9710_sensor_config: cfgtype = %d\n",
	  cdata.cfgtype);
		switch (cdata.cfgtype) {
		case CFG_GET_PICT_FPS:
				ov9710_get_pict_fps(
				cdata.cfg.gfps.prevfps,
				&(cdata.cfg.gfps.pictfps));

			if (copy_to_user((void *)argp,
				&cdata,
				sizeof(struct sensor_cfg_data_t)))
				rc = -EFAULT;
			break;

		case CFG_GET_PREV_L_PF:
			cdata.cfg.prevl_pf =
			ov9710_get_prev_lines_pf();

			if (copy_to_user((void *)argp,
				&cdata,
				sizeof(struct sensor_cfg_data_t)))
				rc = -EFAULT;
			break;

		case CFG_GET_PREV_P_PL:
			cdata.cfg.prevp_pl =
				ov9710_get_prev_pixels_pl();

			if (copy_to_user((void *)argp,
				&cdata,
				sizeof(struct sensor_cfg_data_t)))
				rc = -EFAULT;
			break;

		case CFG_GET_PICT_L_PF:
			cdata.cfg.pictl_pf =
				ov9710_get_pict_lines_pf();

			if (copy_to_user((void *)argp,
				&cdata,
				sizeof(struct sensor_cfg_data_t)))
				rc = -EFAULT;
			break;

		case CFG_GET_PICT_P_PL:
			cdata.cfg.pictp_pl =
				ov9710_get_pict_pixels_pl();

			if (copy_to_user((void *)argp,
				&cdata,
				sizeof(struct sensor_cfg_data_t)))
				rc = -EFAULT;
			break;

		case CFG_GET_PICT_MAX_EXP_LC:
			cdata.cfg.pict_max_exp_lc =
				ov9710_get_pict_max_exp_lc();

			if (copy_to_user((void *)argp,
				&cdata,
				sizeof(struct sensor_cfg_data_t)))
				rc = -EFAULT;
			break;

		case CFG_SET_FPS:
		case CFG_SET_PICT_FPS:
			rc = ov9710_set_fps(&(cdata.cfg.fps));
			break;

		case CFG_SET_EXP_GAIN:
			rc =
				ov9710_write_exp_gain(
					cdata.cfg.exp_gain.gain,
					cdata.cfg.exp_gain.line);
			break;

		case CFG_SET_PICT_EXP_GAIN:
			rc =
				ov9710_set_pict_exp_gain(
					cdata.cfg.exp_gain.gain,
					cdata.cfg.exp_gain.line);
			break;

		case CFG_SET_MODE:
			rc = ov9710_set_sensor_mode(cdata.mode,
						cdata.rs);
			break;

		case CFG_PWR_DOWN:
			rc = ov9710_power_down();
			break;

		case CFG_MOVE_FOCUS:
			rc =
				ov9710_move_focus(
					cdata.cfg.focus.dir,
					cdata.cfg.focus.steps);
			break;

		case CFG_SET_DEFAULT_FOCUS:
			rc =
				ov9710_set_default_focus(
					cdata.cfg.focus.steps);
			break;

		case CFG_SET_EFFECT:
			rc = ov9710_set_default_focus(
						cdata.cfg.effect);
			break;

		default:
			rc = -EFAULT;
			break;
		}

	up(&ov9710_sem);

	return rc;
}

int ov9710_sensor_release(void)
{
	int rc = -EBADF;

	down(&ov9710_sem);

	ov9710_power_down();

	gpio_direction_output(ov9710_ctrl->sensordata->sensor_reset,
			0);
	gpio_free(ov9710_ctrl->sensordata->sensor_reset);

	kfree(ov9710_ctrl);

	up(&ov9710_sem);
	CDBG("ov9710_release completed!\n");
	return rc;
}

static int ov9710_probe(struct i2c_client *client,
	const struct i2c_device_id *id)
{
	int rc = 0;
	if (!i2c_check_functionality(client->adapter, I2C_FUNC_I2C)) {
		rc = -ENOTSUPP;
		goto probe_failure;
	}

	ov9710_sensorw =
		kzalloc(sizeof(struct ov9710_work_t), GFP_KERNEL);

	if (!ov9710_sensorw) {
		rc = -ENOMEM;
		goto probe_failure;
	}

	i2c_set_clientdata(client, ov9710_sensorw);
	ov9710_init_client(client);
	ov9710_client = client;
	ov9710_client->addr = ov9710_client->addr >> 1;
	mdelay(50);

	return 0;

probe_failure:
	kfree(ov9710_sensorw);
	ov9710_sensorw = NULL;
	return rc;
}

static int __exit ov9710_remove(struct i2c_client *client)
{
	struct ov9710_work_t *sensorw = i2c_get_clientdata(client);
	free_irq(client->irq, sensorw);
	ov9710_client = NULL;
	kfree(sensorw);
	return 0;
}

static const struct i2c_device_id ov9710_id[] = {
	{ "ov9710", 0},
	{ }
};

static struct i2c_driver ov9710_driver = {
	.id_table = ov9710_id,
	.probe  = ov9710_probe,
	.remove = __exit_p(ov9710_remove),
	.driver = {
		.name = "ov9710",
	},
};

static int32_t ov9710_init(void)
{
	int32_t rc = 0;

	rc = i2c_add_driver(&ov9710_driver);
	if (IS_ERR_VALUE(rc))
		goto init_failure;
	return rc;

init_failure:
	CDBG("ov9710_init failed\n");
	return rc;
}

void ov9710_exit(void)
{
	i2c_del_driver(&ov9710_driver);
}

int ov9710_probe_init(void *dev, void *ctrl)
{
	int rc = 0;
	struct msm_camera_sensor_info *info =
		(struct msm_camera_sensor_info *)dev;

	struct msm_sensor_ctrl_t *s = (struct msm_sensor_ctrl_t *)ctrl;
	rc = ov9710_init();
	if (rc < 0)
		goto probe_done;

	/* enable mclk first */
	msm_camio_clk_rate_set(OV9710_DEFAULT_CLOCK_RATE);
	mdelay(20);

	rc = ov9710_probe_init_sensor(info);
	if (rc < 0)
		goto probe_done;

	s->s_init = ov9710_sensor_open_init;
	s->s_release = ov9710_sensor_release;
	s->s_config  = ov9710_sensor_config;
	ov9710_sensor_init_done(info);

probe_done:
	return rc;
}
